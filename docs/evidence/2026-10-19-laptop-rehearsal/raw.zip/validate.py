"""Check retained rehearsal facts, hashes, syntax and changed documentation links."""

import ast
import hashlib
import json
import re
from pathlib import Path
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[2]
DEST = ROOT / "docs/evidence/2026-10-19-laptop-rehearsal"
summary = json.loads((DEST / "results.json").read_text(encoding="utf-8"))
assert summary["raw_archive_sha256"] == hashlib.sha256((DEST / "raw.zip").read_bytes()).hexdigest()
with ZipFile(DEST / "raw.zip") as archive:
    assert archive.testzip() is None
    manifest = json.loads(archive.read("manifest.json"))
    assert len(manifest) == 22
    for name, digest in manifest.items():
        content = archive.read(name)
        assert hashlib.sha256(content).hexdigest() == digest, name
        if name.endswith(".json"):
            json.loads(content)
        if name.endswith(".py"):
            ast.parse(content, filename=name)
    pre = json.loads(archive.read("preflight.json"))
    for name, digest in pre["source_sha256"].items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, name
    for name in ("warmup-execution.json", "walkthrough-execution.json", "independent-diagnosis.json", "independent-draft.json"):
        value = json.loads(archive.read(name))
        for key in ("power_before", "power_after"):
            assert value[key]["read_ok"] and value[key]["ac_line_status"] == 1
    assert pre["power"]["ac_line_status"] == summary["power_end"]["ac_line_status"] == 1
    assert pre["working_tree"] == ""
    for deployed in pre["deployed"].values():
        expected = {Path(name).name: digest for name, digest in pre["source_sha256"].items() if name.startswith("src/ml_pipeline_pro/")}
        assert deployed["modules"] == expected
    api_log = archive.read("model-api-run.log").decode()
    for duration, status in ((87884.69, 504), (92736.05, 409)):
        assert any(json.loads(line).get("duration_ms") == duration and json.loads(line).get("status_code") == status for line in api_log.splitlines() if line.startswith("{"))
    runner = archive.read("ollama-stderr-filtered.log").decode()
    assert "task.n_tokens = 1145" in runner and "cached n_tokens = 0" in runner
    assert runner.strip().endswith("all slots are idle")
    assert summary["independent_diagnosis"]["response"]["error"]["code"] == "chat_timeout"
    assert summary["independent_draft"]["exception"] == "ReadTimeout"
    for name in ("public-history.json", "independent-draft-history.json"):
        turn = json.loads(archive.read(name))["turns"][0]
        assert turn["status"] == "interrupted" and not turn["tool_results"]
        assert turn["pending_action"] is None and turn["snippet"] is None

paths = [ROOT / name for name in (
    "PLAN.md", "docs/project/project-status.md", "docs/memory/cpu-inference-timeout-overrun.md",
    "docs/guides/midterm-walkthrough.md", "docs/evidence/2026-10-19-laptop-rehearsal/README.md",
)]
checked = 0
for path in paths:
    text = path.read_text(encoding="utf-8")
    for target in re.findall(r"\[[^\]]*\]\(([^)]+)\)", text):
        if "://" in target or target.startswith("mailto:"):
            continue
        filename, _, anchor = target.partition("#")
        dest = (path.parent / filename).resolve() if filename else path
        assert dest.exists(), (path, target)
        if anchor and dest.suffix == ".md":
            headings = re.findall(r"^#{1,6}\s+(.+)$", dest.read_text(encoding="utf-8"), re.M)
            anchors = [re.sub(r"[^\w\- ]", "", heading.lower()).replace(" ", "-") for heading in headings]
            assert anchor in anchors, (path, target)
        checked += 1
verification = {"status": "passed", "markdown_files": len(paths), "local_links_and_anchors": checked, "archive_payload_files": len(manifest), "source_hashes": len(pre["source_sha256"]), "archive_crc_manifest_json_python_syntax": "passed", "saved_facts_power_source_and_failures": "passed", "review": "self-review; independent boundary review remains outstanding"}
(DEST / "verification.json").write_text(json.dumps(verification, indent=2) + "\n", encoding="utf-8")
print(json.dumps(verification))
