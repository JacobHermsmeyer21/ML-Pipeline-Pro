"""Record the existing laptop walkthrough without changing its limits or assertions."""

import ctypes
import hashlib
import json
import os
import subprocess
import sys
import time
from ctypes import wintypes
from datetime import UTC, datetime
from pathlib import Path

import httpx

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
STACK = "mlpp-post-reboot-validation"


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def power():
    class Power(ctypes.Structure):
        _fields_ = [
            ("ac", wintypes.BYTE), ("flag", wintypes.BYTE),
            ("percent", wintypes.BYTE), ("reserved", wintypes.BYTE),
            ("remaining", wintypes.DWORD), ("full", wintypes.DWORD),
        ]
    value = Power()
    ok = ctypes.windll.kernel32.GetSystemPowerStatus(ctypes.byref(value))
    return {"read_ok": bool(ok), "ac_line_status": value.ac, "battery_percent": value.percent}


def command(argv, timeout=30):
    result = subprocess.run(argv, cwd=ROOT, capture_output=True, text=True, timeout=timeout)
    if result.returncode:
        raise RuntimeError(result.stderr or result.stdout)
    return result.stdout


def preflight():
    values = {
        "utc": datetime.now(UTC).isoformat(),
        "revision": command(["git", "rev-parse", "HEAD"]).strip(),
        "working_tree": command(["git", "status", "--short"]),
        "python": sys.version,
        "power": power(),
        "scope": "Existing unchanged deployed Compose walkthrough; not the pending five-minute profile",
        "commands": {
            "warmup": [sys.executable, "examples/warm_local_model.py", "--model", "mlpp-qwen2.5:7b-instruct-q4_K_M-json-tools-v1"],
            "walkthrough": [sys.executable, "examples/midterm_walkthrough.py", "--confirm-demo-proposal", "--output", str(OUT / "walkthrough")],
        },
        "outer_safety_timeout_seconds": {"warmup": 180, "walkthrough": 1200},
        "application_defaults_seconds": {"model_call": 20, "complete_turn": 60},
        "walkthrough_http_timeout_seconds": 90,
        "retries": 0,
        "generated_code_execution": False,
    }
    import winreg
    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"HARDWARE\DESCRIPTION\System\CentralProcessor\0") as key:
        values["cpu"] = winreg.QueryValueEx(key, "ProcessorNameString")[0].strip()
    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"HARDWARE\DESCRIPTION\System\BIOS") as key:
        values["manufacturer"] = winreg.QueryValueEx(key, "SystemManufacturer")[0]
        values["machine"] = winreg.QueryValueEx(key, "SystemProductName")[0]
    values["compose"] = json.loads(command(["docker", "compose", "ls", "--format", "json"]))
    values["containers"] = command(["docker", "ps", "--format", "{{.Names}}|{{.Image}}|{{.Status}}|{{.Ports}}"])
    headers = {"X-Project-ID": "demo"}
    if key := os.getenv("MLPP_API_KEY"):
        headers["X-API-Key"] = key
    with httpx.Client(timeout=15, trust_env=False, follow_redirects=False) as client:
        for name, url in {
            "ready": "http://127.0.0.1:8000/api/v1/health/ready",
            "ollama_version": "http://127.0.0.1:11434/api/version",
            "ollama_models": "http://127.0.0.1:11434/api/tags",
            "ollama_residency": "http://127.0.0.1:11434/api/ps",
            "grafana_health": "http://127.0.0.1:3000/api/health",
            "grafana_dashboard": "http://127.0.0.1:3000/api/dashboards/uid/mlpp-midterm",
            "prometheus_ready": "http://127.0.0.1:9090/-/ready",
        }.items():
            response = client.get(url, headers=headers if name == "ready" else {})
            response.raise_for_status()
            values[name] = response.json() if "json" in response.headers.get("content-type", "") else response.text
    files = [*sorted((ROOT / "src/ml_pipeline_pro").glob("*.py")), ROOT / "uv.lock"]
    files += [ROOT / name for name in ("examples/midterm_walkthrough.py", "examples/warm_local_model.py", "examples/monitor_workload.py", "scripts/deployment_smoke.py", "compose.yaml", "compose.services.yaml", "compose.monitoring.yaml", "compose.ai.yaml", "deploy/gateway.conf", "deploy/monitoring/prometheus.yaml", "deploy/monitoring/alerts.yaml", ".tools/local-model-setup/tokenizer.json")]
    values["source_sha256"] = {str(path.relative_to(ROOT)).replace("\\", "/"): hashlib.sha256(path.read_bytes()).hexdigest() for path in files}
    probe = "import hashlib,json,pathlib; import ml_pipeline_pro; from ml_pipeline_pro.config import Settings; p=pathlib.Path(ml_pipeline_pro.__file__).parent; s=Settings(); print(json.dumps({'modules':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(p.glob('*.py'))},'settings':{k:getattr(s,k) for k in ('chat_enabled','chat_protocol','chat_model','chat_timeout_seconds','chat_model_timeout_seconds','chat_max_model_calls','chat_max_output_tokens','chat_context_tokens')}}))"
    values["deployed"] = {}
    for service in ("model-api", "tuning-api", "monitoring-api"):
        container = STACK + "-" + service + "-1"
        deployed = json.loads(command(["docker", "exec", container, "python", "-c", probe]))
        deployed["image_id"] = command(["docker", "inspect", "--format", "{{.Image}}", container]).strip()
        deployed["source_matches"] = all(hashlib.sha256((ROOT / "src/ml_pipeline_pro" / name).read_bytes()).hexdigest() == digest for name, digest in deployed["modules"].items())
        assert deployed["source_matches"], service + " deployed source differs from checkout"
        values["deployed"][service] = deployed
    save("preflight.json", values)
    print(json.dumps({"cpu": values["cpu"], "machine": values["machine"], "power": values["power"], "source_matches": {k: v["source_matches"] for k, v in values["deployed"].items()}, "ready": values["ready"]}), flush=True)


def job(name):
    pre = json.loads((OUT / "preflight.json").read_text(encoding="utf-8"))
    argv = pre["commands"][name]
    value = {"argv": argv, "started_utc": datetime.now(UTC).isoformat(), "power_before": power()}
    started = time.monotonic()
    with (OUT / (name + ".log")).open("w", encoding="utf-8") as log:
        try:
            completed = subprocess.run(argv, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, timeout=pre["outer_safety_timeout_seconds"][name])
            value["exit_code"] = completed.returncode
        except subprocess.TimeoutExpired:
            value["exit_code"] = None
            value["outer_timeout"] = True
    value["elapsed_seconds"] = time.monotonic() - started
    value["ended_utc"] = datetime.now(UTC).isoformat()
    value["power_after"] = power()
    save(name + "-execution.json", value)
    print(json.dumps(value), flush=True)
    raise SystemExit(0 if value["exit_code"] == 0 else 1)


def inspect_failure():
    backend = json.loads((OUT / "walkthrough/backend.json").read_text(encoding="utf-8"))
    request_id = backend["training"]["id"] + "-inspect"
    probe = "from pymongo import MongoClient; from ml_pipeline_pro.config import Settings; import json; s=Settings(); c=MongoClient(s.mongodb_uri.get_secret_value(),serverSelectionTimeoutMS=5000); d=c[s.mongodb_database].conversation_turns.find_one({'project_id':'demo','request_id':" + repr(request_id) + "},{'_id':0,'conversation_id':1,'status':1,'request_id':1}); print(json.dumps(d))"
    identity = json.loads(command(["docker", "exec", STACK + "-model-api-1", "python", "-c", probe]))
    save("turn-identity.json", identity)
    headers = {"X-Project-ID": "demo"}
    if key := os.getenv("MLPP_API_KEY"):
        headers["X-API-Key"] = key
    with httpx.Client(timeout=20, trust_env=False) as client:
        response = client.get("http://127.0.0.1:8000/api/v1/conversations/" + identity["conversation_id"], headers=headers)
        response.raise_for_status()
        save("public-history.json", response.json())
        response = client.get("http://127.0.0.1:11434/api/ps")
        response.raise_for_status()
        save("model-residency-after-failure.json", response.json())
    pre = json.loads((OUT / "preflight.json").read_text(encoding="utf-8"))
    started = json.loads((OUT / "walkthrough-execution.json").read_text(encoding="utf-8"))["started_utc"]
    for service in ("model-api", "monitoring-api", "api"):
        result = subprocess.run(["docker", "logs", "--since", started, "--tail", "150", STACK + "-" + service + "-1"], cwd=ROOT, capture_output=True, text=True, timeout=30)
        (OUT / (service + "-run.log")).write_text(result.stdout + result.stderr, encoding="utf-8")
    print(json.dumps(identity), flush=True)


def monitoring_workload():
    backend = json.loads((OUT / "walkthrough/backend.json").read_text(encoding="utf-8"))
    argv = [sys.executable, "examples/monitor_workload.py", "--model-id", backend["model"]["id"], "--version-id", backend["version"]["id"], "--output", str(OUT / "independent-workload.json")]
    start = time.monotonic()
    with (OUT / "independent-workload.log").open("w", encoding="utf-8") as log:
        result = subprocess.run(argv, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, timeout=180)
    value = {"exit_code": result.returncode, "elapsed_seconds": time.monotonic() - start, "argv": argv, "scope": "Independent monitoring after failed AI walkthrough; not complete workflow acceptance"}
    save("independent-workload-execution.json", value)
    print(json.dumps(value), flush=True)
    raise SystemExit(result.returncode)


def independent_ai(kind):
    backend = json.loads((OUT / "walkthrough/backend.json").read_text(encoding="utf-8"))
    headers = {"X-Project-ID": "demo"}
    if key := os.getenv("MLPP_API_KEY"):
        headers["X-API-Key"] = key
    value = {"scope": "One independent component attempt after failed walkthrough; no generation retry", "started_utc": datetime.now(UTC).isoformat(), "power_before": power()}
    if kind == "diagnosis":
        path = "/api/v1/monitoring/model-versions/" + backend["version"]["id"] + "/diagnosis"
        body = None
    else:
        path = "/api/v1/chat"
        body = {"request_id": backend["training"]["id"] + "-independent-python", "message": "Generate Python listing experiments, limit 50, offset 0. Do not execute.", "expected_revision": 0}
    value["path"] = path
    value["request"] = body
    started = time.monotonic()
    with httpx.Client(base_url="http://127.0.0.1:8000", headers=headers, timeout=90, trust_env=False, follow_redirects=False) as client:
        try:
            response = client.post(path, json=body) if body else client.post(path)
            value["elapsed_seconds"] = time.monotonic() - started
            value["status_code"] = response.status_code
            value["correlation_id"] = response.headers.get("x-correlation-id")
            value["response"] = response.json()
            if response.is_success:
                if kind == "diagnosis":
                    assert "inspect_seeded_delay" in value["response"]["generated_advice"]["proposed_checks"]
                else:
                    snippet = value["response"]["snippet"]
                    assert snippet["status"] == "validated" and snippet["review_required"]
                    replay = client.post(path, json=body)
                    replay.raise_for_status()
                    assert replay.json() == value["response"]
                    value["saved_draft_replay_equal"] = True
                value["passed"] = True
            else:
                value["passed"] = False
        except (httpx.HTTPError, AssertionError, ValueError, KeyError, TypeError) as error:
            value.setdefault("elapsed_seconds", time.monotonic() - started)
            value["passed"] = False
            value["exception"] = type(error).__name__
            value["exception_message"] = str(error)
    value["ended_utc"] = datetime.now(UTC).isoformat()
    value["power_after"] = power()
    save("independent-" + kind + ".json", value)
    print(json.dumps({key: value.get(key) for key in ("passed", "elapsed_seconds", "status_code", "exception", "correlation_id")}), flush=True)


def finish():
    backend = json.loads((OUT / "walkthrough/backend.json").read_text(encoding="utf-8"))
    headers = {"X-Project-ID": "demo"}
    if key := os.getenv("MLPP_API_KEY"):
        headers["X-API-Key"] = key
    value = {"utc": datetime.now(UTC).isoformat(), "power": power()}
    with httpx.Client(timeout=30, trust_env=False, follow_redirects=False) as client:
        paths = {
            "ready": "http://127.0.0.1:8000/api/v1/health/ready",
            "summary": "http://127.0.0.1:8000/api/v1/monitoring/model-versions/" + backend["version"]["id"] + "/summary",
            "metrics": "http://127.0.0.1:8000/api/v1/monitoring/metrics",
            "grafana_dashboard": "http://127.0.0.1:3000/api/dashboards/uid/mlpp-midterm",
            "prometheus_rules": "http://127.0.0.1:9090/api/v1/rules",
            "model_residency": "http://127.0.0.1:11434/api/ps",
        }
        for name, url in paths.items():
            response = client.get(url, headers=headers if name in ("ready", "summary", "metrics") else {})
            value[name] = {"status_code": response.status_code, "body": response.json() if "json" in response.headers.get("content-type", "") else response.text}
        expression = 'mlpp_workload_latency_issue{model_version_id="' + backend["version"]["id"] + '"}'
        for name, expression in (("prometheus_current", expression), ("prometheus_retained_scrapes", expression + "[15m]")):
            response = client.get("http://127.0.0.1:9090/api/v1/query", params={"query": expression})
            response.raise_for_status()
            value[name] = response.json()
        request_id = backend["training"]["id"] + "-independent-python"
        probe = "from pymongo import MongoClient; from ml_pipeline_pro.config import Settings; import json; s=Settings(); c=MongoClient(s.mongodb_uri.get_secret_value(),serverSelectionTimeoutMS=5000); d=c[s.mongodb_database].conversation_turns.find_one({'project_id':'demo','request_id':" + repr(request_id) + "},{'_id':0,'conversation_id':1,'request_id':1}); print(json.dumps(d))"
        identity = json.loads(command(["docker", "exec", STACK + "-model-api-1", "python", "-c", probe]))
        if identity:
            response = client.get("http://127.0.0.1:8000/api/v1/conversations/" + identity["conversation_id"], headers=headers)
            response.raise_for_status()
            save("independent-draft-history.json", response.json())
    for name in ("ollama-stdout", "ollama-stderr"):
        path = ROOT / ".tools/test-prerequisites" / (name + ".log")
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        if name.endswith("stdout"):
            lines = [line for line in lines if "[GIN] 2026/10/19 - 11:" in line]
        else:
            lines = [line for line in lines[-160:] if line.startswith(("slot ", "srv ", "prompt eval", "eval time", "total time"))]
        (OUT / (name + "-filtered.log")).write_text("\n".join(lines) + "\n", encoding="utf-8")
    value["containers"] = command(["docker", "ps", "--format", "{{.Names}}|{{.Status}}"])
    save("final-observations.json", value)
    started = json.loads((OUT / "walkthrough-execution.json").read_text(encoding="utf-8"))["started_utc"]
    for service in ("model-api", "monitoring-api", "api"):
        result = subprocess.run(["docker", "logs", "--since", started, "--tail", "200", STACK + "-" + service + "-1"], cwd=ROOT, capture_output=True, text=True, timeout=30)
        (OUT / (service + "-run.log")).write_text(result.stdout + result.stderr, encoding="utf-8")
    print(json.dumps({"ready": value["ready"]["status_code"], "dashboard": value["grafana_dashboard"]["status_code"], "summary": value["summary"]["body"], "retained_scrape_series": len(value["prometheus_retained_scrapes"]["data"]["result"])}), flush=True)


if __name__ == "__main__":
    if sys.argv[1] == "preflight":
        preflight()
    elif sys.argv[1] == "inspect-failure":
        inspect_failure()
    elif sys.argv[1] == "monitoring-workload":
        monitoring_workload()
    elif sys.argv[1] in ("diagnosis", "draft"):
        independent_ai(sys.argv[1])
    elif sys.argv[1] == "finish":
        finish()
    else:
        job(sys.argv[1])
