"""Package only the synthetic rehearsal outputs and public service provenance."""

import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
DEST = ROOT / "docs/evidence/2026-10-19-laptop-rehearsal"


def read(name):
    return json.loads((OUT / name).read_text(encoding="utf-8"))


pre = read("preflight.json")
backend = read("walkthrough/backend.json")
workload = read("independent-workload.json")
final = read("final-observations.json")
series = final["prometheus_retained_scrapes"]["data"]["result"]
samples = [item for result in series for item in result["values"]]
issues = [sample for sample in samples if sample[1] == "1"]
rules = [rule for group in final["prometheus_rules"]["body"]["data"]["groups"] for rule in group["rules"] if rule.get("name") == "MLPPWorkloadLatencyHigh"]
own_alerts = [alert for rule in rules for alert in rule.get("alerts", []) if alert["labels"].get("model_version_id") == backend["version"]["id"]]
result = {
    "date": "2026-10-19",
    "source_revision": pre["revision"],
    "source_working_tree_at_start": pre["working_tree"],
    "machine": {key: pre[key] for key in ("cpu", "manufacturer", "machine")},
    "power_start": pre["power"],
    "power_end": final["power"],
    "deployed_source_matches": {name: value["source_matches"] for name, value in pre["deployed"].items()},
    "deployed_image_ids": {name: value["image_id"] for name, value in pre["deployed"].items()},
    "deployed_chat_settings": pre["deployed"]["model-api"]["settings"],
    "model_tag": "mlpp-qwen2.5:7b-instruct-q4_K_M-json-tools-v1",
    "model_digest": next(model["digest"] for model in pre["ollama_models"]["models"] if model["name"] == "mlpp-qwen2.5:7b-instruct-q4_K_M-json-tools-v1"),
    "ollama_version": pre["ollama_version"],
    "warmup": read("warmup-execution.json"),
    "walkthrough": read("walkthrough-execution.json"),
    "complete_workflow_passed": False,
    "first_ai_inspection": {
        "status_code": 504,
        "server_duration_ms": 87884.69,
        "public_saved_status": read("public-history.json")["turns"][0]["status"],
        "saved_tool_result_count": len(read("public-history.json")["turns"][0]["tool_results"]),
        "pending_action": read("public-history.json")["turns"][0]["pending_action"],
    },
    "backend": {
        "training_status": backend["training"]["status"],
        "training_id": backend["training"]["id"],
        "tuning_status": backend["tuning"]["status"],
        "completed_trials": backend["tuning"]["completed_trials"],
        "submission_replays": backend["submission_replays"],
        "changed_submission_status": backend["changed_submission_status"],
        "foreign_project_status": backend["foreign_status"],
        "model_version_id": backend["version"]["id"],
        "artifact_verified_by_monitoring_producer": True,
    },
    "independent_monitoring": {
        "execution": read("independent-workload-execution.json"),
        "inferences": len(workload["observations"]),
        "declared_delays": sum(row["fault"] == "seeded_latency" for row in workload["observations"]),
        "sample_replay_equal": workload["same_sample_replay_equal"],
        "checkpoint_sha256": workload["artifact_sha256"],
        "checkpoint_size_bytes": workload["artifact_size_bytes"],
        "current_summary_samples": final["summary"]["body"]["sample_count"],
        "current_summary_issue": final["summary"]["body"]["issue"],
        "prometheus_samples_retained": len(samples),
        "prometheus_issue_samples": len(issues),
        "first_retained_issue_utc": datetime.fromtimestamp(float(issues[0][0]), UTC).isoformat() if issues else None,
        "own_current_alerts": own_alerts,
        "grafana_dashboard_http_status": final["grafana_dashboard"]["status_code"],
        "grafana_refresh": final["grafana_dashboard"]["body"]["dashboard"]["refresh"],
        "visual_browser_review": False,
    },
    "independent_diagnosis": read("independent-diagnosis.json"),
    "independent_draft": read("independent-draft.json"),
    "independent_draft_saved_status": read("independent-draft-history.json")["turns"][0]["status"],
    "independent_draft_eventual_server_response": {"status_code": 409, "duration_ms": 92736.05},
    "model_runner_final_log_all_slots_idle": (OUT / "ollama-stderr-filtered.log").read_text(encoding="utf-8").strip().endswith("all slots are idle"),
    "final_readiness_http_status": final["ready"]["status_code"],
    "not_reached_in_walkthrough": ["comparison/history-guided AI proposal", "exact proposal approval and resulting tuning", "validated draft and draft replay", "AI monitoring diagnosis"],
    "not_run": ["original ten-dialogue/seven-snippet gates", "ordinary integration suite", "isolated recovery suite", "Kubernetes rollout/restart/replica checks"],
    "changes": "Documentation/evidence only; no application, configuration, timeout, model, assertion or generated output changed",
    "orchestration_provenance": "Untracked helper edited between phases; final helper retained. Executed committed walkthrough/producer scripts match recorded clean revision hashes.",
    "limits": "One plugged-in laptop rehearsal, no correctness or timing pass for full AI; no timeout-root-cause attribution, performance-generalization or independent-review claim",
}
assert result["first_ai_inspection"]["public_saved_status"] == "interrupted"
assert result["backend"]["training_status"] == result["backend"]["tuning_status"] == "succeeded"
assert result["independent_monitoring"]["inferences"] == 20
assert result["independent_monitoring"]["declared_delays"] == 5
assert result["model_runner_final_log_all_slots_idle"]
assert issues and any(alert["state"] == "firing" for alert in own_alerts)
DEST.mkdir(parents=True, exist_ok=True)
include = [
    "preflight.json", "warmup-execution.json", "warmup.log",
    "walkthrough-execution.json", "walkthrough.log", "walkthrough/backend.json",
    "public-history.json", "independent-workload.json", "independent-workload.log",
    "independent-workload-execution.json", "independent-diagnosis.json",
    "independent-draft.json", "independent-draft-history.json", "final-observations.json",
    "model-api-run.log", "monitoring-api-run.log", "api-run.log",
    "ollama-stdout-filtered.log", "ollama-stderr-filtered.log", "rehearse.py", "summarize.py", "validate.py",
]
manifest = {name: hashlib.sha256((OUT / name).read_bytes()).hexdigest() for name in include}
with ZipFile(DEST / "raw.zip", "w", compression=ZIP_DEFLATED) as archive:
    for name in include:
        archive.write(OUT / name, name)
    archive.writestr("manifest.json", json.dumps(manifest, indent=2) + "\n")
result["raw_archive_sha256"] = hashlib.sha256((DEST / "raw.zip").read_bytes()).hexdigest()
(DEST / "results.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"archive_files": len(include), "complete_workflow_passed": result["complete_workflow_passed"], "independent_monitoring": result["independent_monitoring"], "runner_idle": result["model_runner_final_log_all_slots_idle"]}, indent=2))
