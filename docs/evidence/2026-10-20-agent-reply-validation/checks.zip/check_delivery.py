import hashlib
import json
import subprocess
from pathlib import Path

import httpx

root=Path('artifacts/agent-reply-validation')
source=Path('src/ml_pipeline_pro/conversation_openai.py')
command="import hashlib; from pathlib import Path; import ml_pipeline_pro; print(hashlib.sha256(Path(ml_pipeline_pro.__file__).with_name('conversation_openai.py').read_bytes()).hexdigest())"
actual=subprocess.check_output(['docker','exec','mlpp-rx9070-walkthrough-20261014-model-api-1','python','-c',command],text=True).strip()
assert actual==hashlib.sha256(source.read_bytes()).hexdigest()
with httpx.Client(base_url='http://127.0.0.1:8000',headers={'X-Project-ID':'demo'},trust_env=False,timeout=20) as client:
    old=client.get('/api/v1/conversations/7d497f4b-76eb-419e-9ce7-ecad87535392');old.raise_for_status()
    turn=old.json()['turns'][0]
    assert turn['status']=='failed' and 'details' not in turn['error']
    new=client.get('/api/v1/conversations/3a92c251-1403-42aa-b332-b143c3c4eec0');new.raise_for_status()
    completed=new.json()['turns'][0]
    assert completed['status']=='completed' and len(completed['facts'])==13
    config=client.get('/dashboard/config.json');config.raise_for_status()
    assert config.json()['chat_model']=='gpt-5.4-mini' and config.json()['chat_enabled'] is True
    asset=client.get('/dashboard/reply-errors.js');asset.raise_for_status()
    assert asset.content==(Path('src/ml_pipeline_pro/dashboard/reply-errors.js')).read_bytes()
report={'status':'passed','provider_source_hash':actual,'configured_model':'gpt-5.4-mini','original_failed_turn_unchanged':True,'accepted_turn_readable':True,'accepted_facts':13,'dashboard_module_matches_source':True,'paid_calls':0}
(root/'delivery.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))
