import hashlib
import json
import sys
from pathlib import Path

sys.path.insert(0, ".tools/column-browser")
from playwright.sync_api import expect, sync_playwright

source_assets = "--source-assets" in sys.argv
root = Path("artifacts/agent-reply-validation")
report = {"source_assets": source_assets, "paid_calls": 0, "checks": []}
base = {
    "user_message": "Inspect a saved experiment",
    "status": "failed",
    "message": "Conversation could not be completed. Inspect its saved error and evidence.",
    "correlation_id": "browser-rejection-reference",
    "facts": [], "required_inputs": [], "pending_action": None, "snippet": None,
}
generic_error = {"code": "model_invalid_response", "http_status": 422, "message": "Conversation request failed safely"}
with sync_playwright() as p:
    browser = p.chromium.launch(executable_path="C:/Program Files/Google/Chrome/Application/chrome.exe", headless=True)
    page = browser.new_page(viewport={"width": 1440, "height": 1000})
    def block_writes(route):
        if route.request.method != "GET":
            raise AssertionError("Unexpected mutation or inference request")
        route.continue_()
    page.route("**/api/v1/**", block_writes)
    if source_assets:
        def serve_source(route):
            name = route.request.url.rsplit("/", 1)[-1]
            route.fulfill(path=str(Path("src/ml_pipeline_pro/dashboard") / name), content_type="text/javascript")
        page.route("**/dashboard/*.js", serve_source)
    page.goto("http://127.0.0.1:8000/dashboard/")
    page.wait_for_function("document.getElementById('agent-model').textContent.includes('gpt-5.4-mini')")
    def render(error, correlation=None):
        turn = {**base, "error": error}
        if correlation:
            turn["correlation_id"] = correlation
        page.evaluate("""async (turn) => {
            const {state} = await import('/dashboard/core.js');
            const {renderChat} = await import('/dashboard/agent.js');
            state.turns=[turn]; state.pendingChat=null; renderChat();
        }""", turn)
    known = {**generic_error, "details": {"validation_stage": "evidence_resolution", "validation_reason": "unsupported_fact_field"}}
    render(known)
    expect(page.locator("#chat-messages")).to_contain_text("The reply requested a fact field this agent does not support.")
    expect(page.locator("#chat-messages")).to_contain_text("Reference: browser-rejection-reference")
    report["checks"].append("fixed readable category and correlation reference")
    page.screenshot(path=str(root / ("source-error.png" if source_assets else "deployed-error.png")))
    render(generic_error)
    expect(page.locator("#chat-messages .error-text")).to_have_count(1)
    report["checks"].append("legacy generic error has no invented detail")
    malicious = "<img src=x onerror=alert(1)>"
    render({**generic_error, "details": {"validation_stage": "evidence_resolution", "validation_reason": malicious, "input": malicious}}, correlation=malicious)
    expect(page.locator("#chat-messages .error-text")).to_have_count(1)
    expect(page.locator("#chat-messages img")).to_have_count(0)
    expect(page.locator("#chat-messages")).to_contain_text("Reference: " + malicious)
    report["checks"].append("unrecognized metadata ignored; hostile correlation rendered as text")
    result = page.evaluate("""async () => {
        const {validationExplanation} = await import('/dashboard/reply-errors.js');
        return validationExplanation({code:'model_invalid_response',details:{validation_stage:'host_step', validation_reason:'unsupported_fact_field'}});
    }""")
    assert result == ""
    report["checks"].append("invalid stage/reason pair falls back")
    report["browser"] = browser.version
    browser.close()
report["source_hashes"] = {name: hashlib.sha256((Path("src/ml_pipeline_pro/dashboard") / name).read_bytes()).hexdigest() for name in ("agent.js", "reply-errors.js")}
report["status"] = "passed"
output = root / ("browser-source.json" if source_assets else "browser-deployed.json")
output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps(report, indent=2))
