﻿import hashlib, json, platform, socket, subprocess, tarfile, zipfile
from pathlib import Path
root = Path.cwd()
output = root / 'docs/evidence/2026-10-14-requested-inspection-facts'
output.mkdir(parents=True, exist_ok=True)
files = ['src/ml_pipeline_pro/conversation_guidance.py', 'src/ml_pipeline_pro/conversation_ollama.py', 'tests/test_conversation_guidance.py', 'examples/midterm_walkthrough.py', 'uv.lock']
metadata = {
    'date': '2026-10-14',
    'baseline': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'platform': platform.platform(), 'python': platform.python_version(),
    'source_sha256': {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in files},
    'ports': {}, 'packages': {},
    'pending': ['nine affected real-service cases', 'rebuilt-image failed-record inspection', 'fresh complete walkthrough', 'ten dialogue and seven snippet local-model cases', 'separate boundary review'],
}
for port in (8000, 11434, 27017, 6379):
    with socket.socket() as connection:
        connection.settimeout(0.5)
        metadata['ports'][str(port)] = connection.connect_ex(('127.0.0.1', port)) == 0
for path in sorted((root / 'dist').glob('ml_pipeline_pro-*')):
    names = zipfile.ZipFile(path).namelist() if path.suffix == '.whl' else tarfile.open(path).getnames()
    assert not [name for name in names if any(part in name.split('/') for part in ('artifacts', '.venv', '.git', '__pycache__'))]
    metadata['packages'][path.name] = {'entries': len(names), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'excluded_private_caches': True}
(output / 'results.json').write_text(json.dumps(metadata, indent=2) + '\n', encoding='utf-8')
with zipfile.ZipFile(output / 'raw.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in sorted((root / 'artifacts/requested-inspection-facts').iterdir()):
        if path.is_file():
            archive.write(path, path.name)
print('Saved source/package provenance, service probes and raw verification evidence')
