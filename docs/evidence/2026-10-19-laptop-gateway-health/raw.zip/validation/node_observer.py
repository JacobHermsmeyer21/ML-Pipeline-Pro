"""Low-frequency payload-free node/cgroup, probe and DNS observations; no mutations."""
import argparse
import json
import shlex
import subprocess
import time
from datetime import UTC,datetime
from pathlib import Path

import httpx

from deploy_health import CMD

NODE='mlpp-laptop-five-minute-control-plane'


def observe(output,stop,origin):
    output.mkdir(parents=True,exist_ok=True)
    def call(parts,timeout=8):
        started=time.monotonic()
        item={'started_utc':datetime.now(UTC).isoformat()}
        try:
            result=subprocess.run(parts,capture_output=True,text=True,timeout=timeout,creationflags=subprocess.CREATE_NO_WINDOW)
            item.update(exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr)
        except (subprocess.TimeoutExpired,OSError) as exc:item['unavailable']=type(exc).__name__
        item['duration_seconds']=time.monotonic()-started
        return item
    initial=call([*CMD,'get','pods','-o','json'])
    mapping={}
    if initial.get('exit_code')==0:
        for pod in json.loads(initial['stdout'])['items']:
            for container in pod['status'].get('containerStatuses',[]):
                cid=container.get('containerID','').removeprefix('containerd://')
                if cid:mapping[cid]={'pod':pod['metadata']['name'],'app':pod['metadata']['labels'].get('app')}
    discovered=call(['docker','exec',NODE,'find','/sys/fs/cgroup','-name','cpu.stat'])
    selected={path:mapping[cid] for path in discovered.get('stdout','').splitlines() for cid in mapping if cid in path}
    (output/'cgroup-map.json').write_text(json.dumps({'paths':selected,'discovery_status':{k:v for k,v in discovered.items() if k!='stdout'},'limits':'Initial container IDs only; restarted containers may become unobserved. Such old cgroup paths report unavailable.'},indent=2)+'\n')
    paths=['/proc/meminfo','/proc/stat','/proc/loadavg','/proc/pressure/cpu','/proc/pressure/memory','/proc/pressure/io','/sys/fs/cgroup/cpu.stat','/sys/fs/cgroup/cpu.max','/sys/fs/cgroup/memory.current','/sys/fs/cgroup/memory.max',*selected]
    script="for p in "+' '.join(shlex.quote(p) for p in paths)+"; do printf '\\nFILE=%s\\n' \"$p\"; if [ -r \"$p\" ]; then cat \"$p\"; else printf 'unavailable\\n'; fi; done"
    started=time.monotonic();previous=None;index=0
    with httpx.Client(base_url=origin,timeout=3,trust_env=False,follow_redirects=False) as client:
        while time.monotonic()-started<2100 and not stop.exists():
            tick=time.monotonic()
            row={'utc':datetime.now(UTC).isoformat(),'monotonic_seconds':tick,'target_interval_seconds':30,'gap_seconds':None if previous is None else tick-previous,'index':index}
            previous=tick
            pod_result=call([*CMD,'--request-timeout=5s','get','pods','-o','json'])
            if pod_result.get('exit_code')==0:
                row['pods']=[{'name':p['metadata']['name'],'app':p['metadata']['labels'].get('app'),'phase':p['status']['phase'],'conditions':p['status'].get('conditions'),'containers':[{k:c.get(k) for k in ['name','ready','restartCount','containerID','state','lastState']} for c in p['status'].get('containerStatuses',[])]} for p in json.loads(pod_result['stdout'])['items']]
            row['pod_observation']={k:v for k,v in pod_result.items() if k!='stdout'}
            row['node_cgroup']=call(['docker','exec',NODE,'sh','-c',script])
            row['probes']=[]
            for path in ['/gateway-live','/api/v1/health/ready']:
                before=time.monotonic();probe={'path':path,'utc':datetime.now(UTC).isoformat()}
                try:probe['status_code']=client.get(path).status_code
                except httpx.TransportError as exc:probe['unavailable']=type(exc).__name__
                probe['elapsed_seconds']=time.monotonic()-before;row['probes'].append(probe)
            if index%2==0:
                row['dns_exec']=call([*CMD,'--request-timeout=5s','exec','deployment/gateway','--','nslookup','-timeout=1','-retry=1','model-api.mlpp-demo.svc.cluster.local'])
                row['dns_exec']['limits']='Duration includes Kubernetes exec/control-plane overhead, not raw DNS latency.'
            row['duration_seconds']=time.monotonic()-tick
            with (output/'samples.jsonl').open('a',encoding='utf-8') as stream:stream.write(json.dumps(row)+'\n')
            index+=1
            while not stop.exists() and time.monotonic()-tick<30:time.sleep(0.5)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--stop',type=Path,required=True);p.add_argument('--origin',default='http://127.0.0.1:18000');args=p.parse_args();observe(args.output,args.stop,args.origin)
