"""Request temporary system wakefulness for this rehearsal; leave power policy untouched."""
import ctypes
import json
import time
from datetime import UTC,datetime
from pathlib import Path

out=Path('artifacts/laptop-health-validation')
stop=out/'keep-awake-stop.txt'
assert not stop.exists(),'Use a fresh task stop marker'
api=ctypes.windll.kernel32.SetThreadExecutionState
api.argtypes=[ctypes.c_uint]
api.restype=ctypes.c_uint
previous=api(0x80000001)
assert previous,'Temporary system-required request failed'
result={'started_utc':datetime.now(UTC).isoformat(),'previous_state':previous,'requested_flags':0x80000001,'power_policy_modified':False,'scope':'Temporary request for the approved rehearsal; released on stop, process exit or two-hour bound.'}
(out/'keep-awake.json').write_text(json.dumps(result,indent=2)+'\n')
started=time.monotonic()
try:
    while not stop.exists() and time.monotonic()-started<7200:time.sleep(1)
finally:
    result.update(released_state=api(0x80000000),ended_utc=datetime.now(UTC).isoformat())
    (out/'keep-awake.json').write_text(json.dumps(result,indent=2)+'\n')
