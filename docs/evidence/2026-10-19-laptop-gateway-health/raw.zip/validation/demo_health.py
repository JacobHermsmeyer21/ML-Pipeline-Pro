"""One original deployed walkthrough with bounded, payload-free resource observers."""
import hashlib
import json
import os
import re
import subprocess
import sys
import time
from datetime import UTC,datetime
from pathlib import Path

import httpx

from deploy_health import CMD,OUT,ROOT

MODEL='mlpp-qwen2.5:7b-instruct-q4_K_M-json-tools-v1'
RUNTIME=ROOT/'.tools/test-prerequisites'
DEMO=ROOT/'artifacts/laptop-health-demo'
OBS=OUT/'live-resources'


def write(name,data):(OUT/name).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')


def power():
    import runpy
    return runpy.run_path(str(ROOT/'artifacts/laptop-five-minute-validation/run_command.py'))['power']()


def state(lines):
    selected=[line for line in lines if re.search('all slots are idle|new prompt|cancel task|stop processing',line)]
    return selected[-1] if selected else None


def collect_ids(value):
    result=set()
    if isinstance(value,dict):
        if isinstance(value.get('conversation_id'),str):result.add(value['conversation_id'])
        for item in value.values():result.update(collect_ids(item))
    elif isinstance(value,list):
        for item in value:result.update(collect_ids(item))
    return result


def main():
    assert not (OUT/'live-demo-summary.json').exists(),'Do not overwrite or retry generation automatically'
    assert power()['ac_line_status']==1,'Connect AC before inference'
    assert 'all slots are idle' in (state((RUNTIME/'ollama-stderr.log').read_text(errors='replace').splitlines()) or '')
    report={'started_utc':datetime.now(UTC).isoformat(),'source_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'working_tree':subprocess.check_output(['git','status','--porcelain'],text=True),'power_before':power(),'complete_workflow_passed':False,'automatic_retries':0,'generated_code_execution':False,'source_sha256':{p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in [*Path('src/ml_pipeline_pro').glob('*.py'),Path('examples/midterm_walkthrough.py'),Path(__file__)]}}
    offsets={name:(RUNTIME/name).stat().st_size for name in ['ollama-stderr.log','ollama-stdout.log']}
    with httpx.Client(base_url='http://127.0.0.1:11434',timeout=8,trust_env=False,follow_redirects=False) as client:
        version=client.get('/api/version');version.raise_for_status()
        tags=client.get('/api/tags');tags.raise_for_status()
        model=next(item for item in tags.json()['models'] if item['name']==MODEL)
        assert version.json()['version']=='0.40.2'
        assert model['digest'].removeprefix('sha256:')=='abadc4bf8517d77dcc8db312ca98cd7cb43488243048c41f1b5746e031427779'
        report.update(runtime_version=version.json(),model={'name':MODEL,'digest':model['digest']})
    forwarded=None;forward_log=None;observers=[]
    try:
        forward_log=(OUT/'live-demo-forward.log').open('wb')
        forwarded=subprocess.Popen([*CMD,'port-forward','service/gateway','18000:8000','--address','127.0.0.1'],stdout=forward_log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
        headers={'X-Project-ID':'demo'}
        if key:=os.getenv('MLPP_API_KEY'):headers['X-API-Key']=key
        with httpx.Client(base_url='http://127.0.0.1:18000',headers=headers,timeout=5,trust_env=False,follow_redirects=False) as client:
            for _ in range(30):
                assert forwarded.poll() is None
                try:
                    if client.get('/api/v1/health/ready').status_code==200:break
                except httpx.TransportError:pass
                time.sleep(1)
            else:raise TimeoutError('Gateway not ready before warmup')
            for kind in ['pods','events']:
                initial=json.loads(subprocess.check_output([*CMD,'get',kind,'-o','json'],text=True,timeout=15))['items']
                if kind=='pods':initial=[{'name':p['metadata']['name'],'app':p['metadata']['labels'].get('app'),'status':p['status']} for p in initial]
                write('live-initial-'+kind+'.json',initial)
            subprocess.run([sys.executable,'artifacts/laptop-five-minute-validation/run_command.py','--phase','health-warmup','--timeout','150','--output',str(OUT),'--',sys.executable,'examples/warm_local_model.py','--model',MODEL],check=True,creationflags=subprocess.CREATE_NO_WINDOW)
            OBS.mkdir(parents=True,exist_ok=True)
            selection="@(Get-Process | Where-Object {$_.ProcessName -match '^(ollama|vmmem|com\\.docker\\.backend)'} | ForEach-Object { [PSCustomObject]@{pid=$_.Id;name=$_.ProcessName} }) | ConvertTo-Json -Depth 3"
            pids=json.loads(subprocess.check_output(['powershell.exe','-NoProfile','-NonInteractive','-Command',selection],text=True))
            (OBS/'pids.json').write_text(json.dumps(pids,indent=2)+'\n')
            (OBS/'phase.txt').write_text('pre-inference')
            for name,parts in [
                ('host',['powershell.exe','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',str(OUT/'observe_resources.ps1'),'-OutputPath',str(OBS/'host.jsonl'),'-PhasePath',str(OBS/'phase.txt'),'-StopPath',str(OBS/'stop.txt'),'-PidPath',str(OBS/'pids.json'),'-MaxSeconds','2100']),
                ('node',[sys.executable,str(OUT/'node_observer.py'),'--output',str(OBS/'node'),'--stop',str(OBS/'stop.txt')]),
            ]:
                log=(OBS/(name+'-observer.log')).open('wb')
                process=subprocess.Popen(parts,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
                observers.append((name,process,log))
            for _ in range(30):
                assert all(p.poll() is None for _,p,_ in observers),'Observer exited before inference'
                if (OBS/'host.jsonl').exists() and (OBS/'host.jsonl').stat().st_size:break
                time.sleep(1)
            else:raise TimeoutError('Host observer unavailable before inference')
            time.sleep(12)
            (OBS/'phase.txt').write_text('complete-walkthrough')
            result=subprocess.run([sys.executable,'artifacts/laptop-five-minute-validation/run_command.py','--phase','live-demo','--timeout','1800','--output',str(OUT),'--',sys.executable,'examples/midterm_walkthrough.py','--origin','http://127.0.0.1:18000','--timing-profile','laptop-five-minute','--confirm-demo-proposal','--output',str(DEMO)],creationflags=subprocess.CREATE_NO_WINDOW)
            report['demo_exit_code']=result.returncode
            report['complete_workflow_passed']=result.returncode==0
            (OBS/'phase.txt').write_text('after-walkthrough')
            path=DEMO/'results.json'
            if path.exists():
                public=json.loads(path.read_text());histories={}
                for cid in collect_ids(public):
                    for attempt in range(12):
                        try:
                            response=client.get('/api/v1/conversations/'+cid)
                            if response.status_code==200:
                                histories[cid]=response.json();break
                            histories[cid]={'history_http_status':response.status_code}
                        except httpx.TransportError as exc:histories[cid]={'unavailable':type(exc).__name__}
                        time.sleep(5)
                write('live-public-histories.json',histories)
    finally:
        if observers:
            (OBS/'stop.txt').touch()
            for name,process,log in observers:
                forced=False
                try:process.wait(timeout=40)
                except subprocess.TimeoutExpired:
                    forced=True;process.terminate();process.wait(timeout=10)
                log.close();report.setdefault('observers',{})[name]={'exit_code':process.returncode,'forced_stop':forced}
        if forwarded is not None:
            forwarded.terminate();forwarded.wait(timeout=10);forward_log.close()
        for name,offset in offsets.items():
            with (RUNTIME/name).open('rb') as stream:stream.seek(offset);raw=stream.read()
            lines=raw.decode('utf-8',errors='replace').splitlines()
            filtered=[line for line in lines if re.search(r'all slots are idle|prompt eval time|eval time|total time|cached n_tokens|cancel task|stop processing|new prompt|/api/chat',line,re.I)]
            (OUT/('live-'+name.replace('.log','-filtered.log'))).write_text('\n'.join(filtered)+'\n')
            report.setdefault('runtime_slices',{})[name]={'offset_bytes':offset,'size_bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
            if name=='ollama-stderr.log':
                report['runner_final_state']=state(lines)
                report['runner_idle_after']=bool(report['runner_final_state'] and 'all slots are idle' in report['runner_final_state'])
        for kind in ['pods','events']:
            try:
                result=subprocess.run([*CMD,'get',kind,'-o','json'],capture_output=True,text=True,timeout=15,creationflags=subprocess.CREATE_NO_WINDOW)
            except (subprocess.TimeoutExpired,OSError) as exc:
                report.setdefault('collection_gaps',[]).append({'kind':kind,'error_type':type(exc).__name__})
                continue
            if result.returncode==0:
                data=json.loads(result.stdout)['items']
                if kind=='pods':data=[{'name':p['metadata']['name'],'app':p['metadata']['labels'].get('app'),'status':p['status']} for p in data]
                write('live-final-'+kind+'.json',data)
                if kind=='pods':
                    for pod in data:
                        if pod['app'] not in ['model-api','gateway','monitoring-api']:continue
                        for previous in [False,True]:
                            parts=[*CMD,'logs',pod['name']]
                            if previous:parts.append('--previous')
                            try:
                                logs=subprocess.run(parts,capture_output=True,timeout=15,creationflags=subprocess.CREATE_NO_WINDOW)
                                (OUT/(pod['name']+('-previous' if previous else '-current')+'.log')).write_bytes(logs.stdout+logs.stderr)
                            except (subprocess.TimeoutExpired,OSError) as exc:
                                report.setdefault('collection_gaps',[]).append({'pod':pod['name'],'previous':previous,'error_type':type(exc).__name__})
        report.update(ended_utc=datetime.now(UTC).isoformat(),power_after=power())
        write('live-demo-summary.json',report)
    print(json.dumps({k:report[k] for k in ['complete_workflow_passed','runner_idle_after','power_before','power_after']}))
    raise SystemExit(report.get('demo_exit_code',1))


if __name__=='__main__':main()
