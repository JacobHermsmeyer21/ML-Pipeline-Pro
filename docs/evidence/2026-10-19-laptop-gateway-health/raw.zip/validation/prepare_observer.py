"""Derive a lower-frequency fixed-PID observer without changing historical trials."""
from pathlib import Path

source=Path('evaluations/laptop_resource_observer.ps1').read_text()
source=source.replace('[int]$MaxSeconds = 3600','[int]$MaxSeconds = 3600,\n    [Parameter(Mandatory=$true)][string]$PidPath')
source=source.replace('Processes() {','Processes(int[] ids) {')
source=source.replace('foreach (var process in System.Diagnostics.Process.GetProcesses()) {', '''foreach (int pid in ids) {
            System.Diagnostics.Process process;
            try { process = System.Diagnostics.Process.GetProcessById(pid); }
            catch { result.Add(new Dictionary<string,object> {{"pid",pid},{"unavailable",true}}); continue; }''')
source=source.replace('target_interval_seconds = 2','target_interval_seconds = 10')
source=source.replace('[LaptopCounters]::Processes()','[LaptopCounters]::Processes($TrackedPids)')
source=source.replace('[LaptopCounters]::Init()', '[int[]]$TrackedPids = @((Get-Content -LiteralPath $PidPath -Raw | ConvertFrom-Json) | ForEach-Object { $_.pid })\n[LaptopCounters]::Init()')
source=source.replace('2000 - (','10000 - (')
Path('artifacts/laptop-health-validation/observe_resources.ps1').write_text(source,encoding='utf-8')
print('Prepared ten-second, fixed-PID observer; no repeated full process enumeration.')
