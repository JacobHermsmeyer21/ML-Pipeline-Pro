"""Read current implementation CI with the existing Git credential kept only in memory."""
import json
import os
import subprocess
from pathlib import Path

import httpx

root=Path.cwd()
revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
credential=subprocess.run(['git','credential','fill'],input='protocol=https\nhost=github.com\npath=JacobHermsmeyer21/ML-Pipeline-Pro\n\n',capture_output=True,text=True,timeout=20,env={**os.environ,'GIT_TERMINAL_PROMPT':'0','GCM_INTERACTIVE':'never'})
if credential.returncode:raise SystemExit('Existing repository credential unavailable; no credential output retained')
fields=dict(line.split('=',1) for line in credential.stdout.splitlines() if '=' in line)
token=fields.get('password')
if not token:raise SystemExit('Existing repository credential unavailable')
with httpx.Client(base_url='https://api.github.com',headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json'},timeout=15,trust_env=False,follow_redirects=False) as client:
    response=client.get('/repos/JacobHermsmeyer21/ML-Pipeline-Pro/actions/runs',params={'head_sha':revision,'per_page':10});response.raise_for_status()
    matching=[run for run in response.json()['workflow_runs'] if run['head_sha']==revision]
    if not matching:raise SystemExit('No implementation CI run found yet')
    run=matching[0]
    result={k:run[k] for k in ['id','head_sha','status','conclusion','html_url','created_at','updated_at']}
    jobs=client.get('/repos/JacobHermsmeyer21/ML-Pipeline-Pro/actions/runs/'+str(run['id'])+'/jobs',params={'per_page':100});jobs.raise_for_status()
    result['jobs']=[{k:job[k] for k in ['id','name','status','conclusion','started_at','completed_at','html_url']} for job in jobs.json()['jobs']]
(root/'artifacts/laptop-health-validation/ci-current.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
