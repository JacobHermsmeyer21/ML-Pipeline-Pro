"""Read saved turn/history/deadlines and post-run status; never generate or confirm."""
import json
import subprocess
import time
from datetime import UTC,datetime
from pathlib import Path

import httpx
from pymongo import MongoClient

from deploy_health import CMD,OUT,forward,close,ready

backend=json.loads(Path('artifacts/laptop-health-demo/results.json').read_text())['backend']
request_id=backend['training']['id']+'-inspect'
processes=[]
try:
    processes.append(forward('mongo',27017,27017))
    time.sleep(2)
    with MongoClient('mongodb://127.0.0.1:27017/?directConnection=true',serverSelectionTimeoutMS=5000) as client:
        turns=list(client.ml_pipeline_pro.conversation_turns.find({'project_id':'demo','request_id':request_id},{'_id':1,'conversation_id':1,'request_id':1,'created_at':1,'deadline':1,'state':1,'public.conversation_id':1,'public.status':1,'public.error':1,'public.pending_action':1}))
    from bson.json_util import dumps
    (OUT/'post-failure-deadlines.json').write_text(dumps(turns,indent=2)+'\n')
    identities={row.get('conversation_id') or row.get('public',{}).get('conversation_id') for row in turns}
    identities.discard(None)
    processes.append(forward('gateway',18000,8000));ready(processes)
    with httpx.Client(base_url='http://127.0.0.1:18000',headers={'X-Project-ID':'demo'},trust_env=False,follow_redirects=False,timeout=10) as client:
        histories={}
        for identity in identities:
            response=client.get('/api/v1/conversations/'+identity);response.raise_for_status();histories[identity]=response.json()
        (OUT/'post-failure-histories.json').write_text(json.dumps(histories,indent=2)+'\n')
finally:close(processes)
pods=json.loads(subprocess.check_output([*CMD,'get','pods','-o','json'],text=True))['items']
(OUT/'post-failure-pods.json').write_text(json.dumps([{'name':p['metadata']['name'],'app':p['metadata']['labels'].get('app'),'status':p['status']} for p in pods],indent=2)+'\n')
events=json.loads(subprocess.check_output([*CMD,'get','events','-o','json'],text=True))['items']
(OUT/'post-failure-events.json').write_text(json.dumps(events,indent=2)+'\n')
for pod in pods:
    if pod['metadata']['labels'].get('app') not in ['gateway','model-api']:continue
    logs=subprocess.run([*CMD,'logs',pod['metadata']['name']],capture_output=True,timeout=15)
    (OUT/(pod['metadata']['name']+'-post-failure.log')).write_bytes(logs.stdout+logs.stderr)
lines=Path('.tools/test-prerequisites/ollama-stderr.log').read_text(errors='replace').splitlines()
states=[line for line in lines if any(s in line for s in ['all slots are idle','new prompt','cancel task','stop processing'])]
observation={'collected_utc':datetime.now(UTC).isoformat(),'runner_final_state':states[-1],'runner_idle': 'all slots are idle' in states[-1],'original_summary_idle_false_preserved':True,'history_collection':'Pure MongoDB reads and history GETs; no generation, action confirmation or replay POST.'}
(OUT/'post-failure-idle.json').write_text(json.dumps(observation,indent=2)+'\n')
print(json.dumps(observation,indent=2))
