"""Verify imported installed modules, selected settings and actual deployed health paths."""
import hashlib
import json
import subprocess
from pathlib import Path

from deploy_health import CMD,OUT

pods=json.loads(subprocess.check_output([*CMD,'get','pods','-o','json'],text=True))['items']
pods=[p for p in pods if p['status']['phase']=='Running' and not p['metadata'].get('deletionTimestamp')]
expected={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('src/ml_pipeline_pro').glob('*.py')}
code="""import json,hashlib,pathlib,ml_pipeline_pro
from ml_pipeline_pro.config import Settings
p=pathlib.Path(ml_pipeline_pro.__file__).parent
s=Settings(_env_file=None)
print(json.dumps({'module_path':str(p),'sha256':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in p.glob('*.py')},'settings':{'chat_enabled':s.chat_enabled,'protocol':s.chat_protocol,'model':s.chat_model,'model_seconds':s.chat_model_timeout_seconds,'turn_seconds':s.chat_timeout_seconds}}))
"""
observed=[]
for pod in pods:
    app=pod['metadata']['labels'].get('app')
    if app not in ['model-api','monitoring-api','tuning-api']:continue
    assert all(c['ready'] for c in pod['status']['containerStatuses'])
    item=json.loads(subprocess.check_output([*CMD,'exec',pod['metadata']['name'],'--','python','-c',code],text=True))
    assert item['sha256']==expected
    if app in ['model-api','monitoring-api']:
        assert item['settings']['chat_enabled'] and item['settings']['protocol']=='guided'
        assert item['settings']['model_seconds']==240 and item['settings']['turn_seconds']==270
    item.update(pod=pod['metadata']['name'],app=app,images=[{'image':c['image'],'imageID':c['imageID']} for c in pod['status']['containerStatuses']])
    observed.append(item)
assert len(observed)==4
deployment=json.loads(subprocess.check_output([*CMD,'get','deployment/gateway','-o','json'],text=True))
container=deployment['spec']['template']['spec']['containers'][0]
assert container['livenessProbe']['httpGet']['path']=='/gateway-live'
assert container['readinessProbe']['httpGet']['path']=='/api/v1/health/ready'
assert container['startupProbe']['httpGet']['path']=='/api/v1/health/live'
config=subprocess.check_output([*CMD,'exec','deployment/gateway','--','cat','/etc/nginx/nginx.conf'],text=True)
assert 'location = /gateway-live {' in config and 'proxy_next_upstream off;' in config
(OUT/'active-nginx.conf').write_text(config,encoding='utf-8')
(OUT/'active-installation.json').write_text(json.dumps({'pods':observed,'gateway_probes':{key:container[key] for key in ['livenessProbe','readinessProbe','startupProbe']},'gateway_resources':container['resources']},indent=2)+'\n')
print('All four imported API installations match checkout; actual gateway liveness is local, readiness/startup remain upstream.')
