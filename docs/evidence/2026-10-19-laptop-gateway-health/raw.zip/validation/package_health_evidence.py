"""Package allowlisted public test evidence; no services, credentials or inference."""
import ast
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from datetime import UTC, datetime
from pathlib import Path

root = Path.cwd()
base = root/'artifacts/laptop-health-validation'
dest = root/'docs/evidence/2026-10-19-laptop-gateway-health'
dest.mkdir(exist_ok=True)
revision = subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert revision == 'bf07213ed2564cfc9c97efb35504c22f2d9cf9c7'

def read(name):
    return json.loads((base/name).read_text(encoding='utf-8-sig'))

def write(path, value):
    path.write_text(json.dumps(value, indent=2)+'\n',encoding='utf-8')

def digest(data):
    return hashlib.sha256(data).hexdigest()

def junit(name):
    suite = ET.parse(base/name).getroot()
    suites = list(suite.iter('testsuite'))
    counts = {k:sum(int(s.get(k,0)) for s in suites) for k in ['tests','failures','errors','skipped']}
    assert counts['failures'] == counts['errors'] == counts['skipped'] == 0, counts
    return counts

assert junit('fast.xml')['tests'] == 647
assert junit('focused.xml')['tests'] == 18
assert junit('ordinary.xml')['tests'] == 63
for phase in ['sync','ruff','format','fast','dependencies','build','focused','nginx-final','ordinary','active-installation','kubernetes-smoke','node-restart']:
    assert read(phase+'-execution.json')['exit_code'] == 0, phase
assert read('live-demo-execution.json')['exit_code'] == 1
assert read('rehearsal-execution.json')['exit_code'] == 1
assert read('ci-current.json')['conclusion'] == 'success'
assert len(read('ci-current.json')['jobs']) == 5
assert all(j['conclusion']=='success' for j in read('ci-current.json')['jobs'])
assert read('preserved-before-rollout.json') == read('preserved-after-rollout.json')
assert read('keep-awake.json')['released_state']
assert read('post-failure-idle.json')['runner_idle'] is True
assert read('live-demo-summary.json')['runner_idle_after'] is False
for name, expected in read('live-demo-summary.json')['source_sha256'].items():
    assert digest((root/name).read_bytes())==expected, name
for folder in ['2026-10-19-laptop-five-minute','2026-10-19-laptop-awake-gates']:
    for name in ['raw.zip','results.json','verification.json','human-review-decision.json']:
        path=Path('docs/evidence')/folder/name
        if path.exists():
            assert subprocess.check_output(['git','show','HEAD:'+path.as_posix()])==path.read_bytes(),str(path)
pods = {p['app']:p for p in read('post-failure-pods.json') if p['app']=='gateway'}
gateway = pods['gateway']['status']['containerStatuses'][0]
assert gateway['restartCount'] == 4
assert gateway['lastState']['terminated']['finishedAt']=='2026-10-19T21:42:28Z'
assert gateway['state']['running']['startedAt']=='2026-10-19T21:42:33Z'
turn = next(iter(read('post-failure-histories.json').values()))['turns'][0]
assert turn['tool_results'][0]['error']['code']=='tool_transport_error'
assert turn['facts']==[] and turn['pending_action'] is None
demo = json.loads((root/'artifacts/laptop-health-demo/results.json').read_text())
assert len(demo['ai_requests'])==1 and demo['ai_requests'][0]['failure_type']=='RemoteProtocolError'
resources=read('resource-summary.json')
assert resources['available_memory_min_bytes']['value']==584904704
assert abs(resources['node_max_gap_seconds']-79.125)<0.001

payloads={}
def add(path, name):
    assert name not in payloads, name
    assert path.is_file(), str(path)
    data=path.read_bytes()
    forbidden=[rb'^\s*client-(?:key|certificate)-data:\s*\S+',
        rb'^-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
        rb'ghp_[A-Za-z0-9]{20,}',rb'github_pat_[A-Za-z0-9_]{20,}']
    assert not any(re.search(pattern,data,re.M) for pattern in forbidden), name
    payloads[name]=(path,data)

for path in sorted(base.iterdir()):
    if path.is_file() and path.suffix in {'.json','.log','.xml','.py','.ps1','.conf'}:
        add(path,'validation/'+path.name)
for folder in ['nginx-negative','nginx-negative-v2','nginx-final','observer-check','replicas']:
    for path in sorted((base/folder).iterdir()):
        if path.is_file() and path.suffix in {'.json','.log','.jsonl'}:
            add(path,'validation/'+folder+'/'+path.name)
for relative in ['host.jsonl','host-observer.log','pids.json','phase.txt','stop.txt','node-observer.log','node/samples.jsonl','node/cgroup-map.json']:
    path=base/'live-resources'/relative
    if path.exists():add(path,'validation/live-resources/'+relative)
for path in sorted((root/'artifacts/laptop-health-demo').iterdir()):
    if path.suffix=='.json':add(path,'demo/'+path.name)
for name in ['run_command.py','restart_kubernetes.py','kubernetes_demo.py']:
    add(root/'artifacts/laptop-five-minute-validation'/name,'orchestration-dependencies/'+name)
for name in ['smoke.json','restart-result.json']:
    path=root/'artifacts/laptop-five-minute-kubernetes'/name
    if path.exists():add(path,'prior-record-baseline/'+name)
source_names = [p.as_posix() for p in Path('src/ml_pipeline_pro').glob('*.py')]
source_names += ['tests/test_laptop_timing.py','scripts/check_laptop_gateway.py','scripts/render_laptop_profile.py','scripts/deployment_smoke.py','scripts/check_api_replicas.py','examples/midterm_walkthrough.py','evaluations/laptop_resource_observer.ps1','uv.lock','pyproject.toml','Dockerfile']
source_names += [p.as_posix() for p in Path('deploy').rglob('*') if p.is_file() and p.suffix in {'.yaml','.conf','.json'}]
for name in source_names:add(root/name,'source/'+name)

builds=[]
for path in sorted((root/'dist').iterdir()):
    if path.suffix not in {'.whl','.gz'}:continue
    if path.suffix=='.whl':
        with zipfile.ZipFile(path) as z:
            entries=z.namelist()
            assert not any('.uv-cache' in n for n in entries)
            module='ml_pipeline_pro/laptop_deployment.py'
            assert z.read(module)==(root/'src'/module).read_bytes()
    else:
        import tarfile
        with tarfile.open(path) as tar:
            entries=tar.getnames()
            assert not any('.uv-cache' in n for n in entries)
    builds.append({'name':path.name,'sha256':digest(path.read_bytes()),'bytes':path.stat().st_size,'cache_entries':0})
assert len(builds)==2

# Display formatting is separate from immutable saved generated strings.
old=root/'docs/evidence/2026-10-19-laptop-awake-gates'
with zipfile.ZipFile(old/'raw.zip') as z:
    reports=[n for n in z.namelist() if n.endswith('snippets.json')]
    assert len(reports)==1
    report=json.loads(z.read(reports[0]))
    originals=[case['turn']['snippet']['code'] for case in report['cases'] if case['turn'].get('snippet')]
displays=re.findall(r'```python\s*\n(.*?)```',(old/'human-review.md').read_text(),re.S)
assert len(originals)==len(displays)==5,(len(originals),len(displays))
assert all(ast.dump(ast.parse(a))==ast.dump(ast.parse(b)) for a,b in zip(originals,displays,strict=True))

results={
    'implementation_revision':revision,
    'plan':'docs/plans/2026-10-19-laptop-deployment-health-plan.md',
    'approval':{'reviewer':'Jacob','date':'2026-10-19','quote':'i approve, go for it'},
    'fast':junit('fast.xml'),'focused':junit('focused.xml'),'ordinary':junit('ordinary.xml'),
    'ci':read('ci-current.json'),
    'live':{'passed':False,'request':demo['ai_requests'][0],'client_command':read('live-demo-execution.json'),
        'server_complete_turn_seconds':167.505905,'original_deadline_utc':'2026-10-19T21:44:16.260Z',
        'gateway_liveness_killing_utc':'2026-10-19T21:41:45Z','gateway_later_status':gateway,
        'saved_turn':turn,'original_idle':False,'later_idle':read('post-failure-idle.json')},
    'resources':resources,
    'acceptance':{'F1':'pass','F2':'pass','N1':'fail','N2':'retained samples; attribution incomplete','N3':'fail'},
    'fresh_dialogue_snippet_gates':'unrun after first generation failure; prior cohort passes retained separately',
    'live_expiry':'outstanding; no expiry experiment authorized or executed',
    'new_isolated_recovery_execution':False,
    'package_inspection':builds,
    'old_display_asts_equal_raw_strings':5,
    'no_retries':True,'generated_code_execution':False,
    'review':{'reviewer':'OpenAI timing_review agent','scope':'read-only renderer, probe/routing preconditions, timeline/resource arithmetic, text/diagnostic bounds','different_vendor_available':False,'services_executed':False,'findings_resolved':['preserve stale pod/idle observations separately','limit resource attribution','distinguish image identities','total capture budget and finite idle polling']},
    'next_plan_status':'awaiting human review; no new run or resource change authorized',
}
write(dest/'results.json',results)
manifest={
    'created_utc':datetime.now(UTC).isoformat(),'implementation_revision':revision,
    'entries':[{'path':name,'source':str(path.relative_to(root)).replace('\\','/'),'bytes':len(data),'sha256':digest(data)} for name,(path,data) in sorted(payloads.items())],
    'excluded':['kubeconfig and embedded certificates/keys','credentials and environment dumps','model weights and installers','build artifacts','test caches/temp directories'],
}
write(dest/'manifest.json',manifest)
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,(_,data) in sorted(payloads.items()):z.writestr(name,data)
with zipfile.ZipFile(dest/'raw.zip') as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(manifest['entries'])
    for entry in manifest['entries']:
        data=z.read(entry['path'])
        assert len(data)==entry['bytes'] and digest(data)==entry['sha256']
verification={
    'verified_utc':datetime.now(UTC).isoformat(),
    'archive_crc':'pass','payload_sha256_and_sizes':'pass',
    'payload_count':len(payloads),'uncompressed_bytes':sum(len(d) for _,d in payloads.values()),
    'archive_bytes':(dest/'raw.zip').stat().st_size,
    'archive_sha256':digest((dest/'raw.zip').read_bytes()),
    'manifest_sha256':digest((dest/'manifest.json').read_bytes()),
    'results_sha256':digest((dest/'results.json').read_bytes()),
    'asserted_fast_focused_ordinary_counts':[647,18,63],
    'all_five_ci_jobs_success':True,'old_generated_display_asts_equal':5,
    'active_gateway_restart_confirmed':True,'failed_live_request_preserved':True,
    'raw_prior_archives_and_decision_unchanged':True,
    'limits':'Local verification; read-only reviewer did not independently verify this archive.',
}
write(dest/'verification.json',verification)
print(json.dumps(verification,indent=2))
