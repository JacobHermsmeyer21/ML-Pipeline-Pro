"""Update only the preserved laptop cluster, retaining records and exact source identities."""
import argparse
import hashlib
import json
import os
import socket
import subprocess
import sys
import time
from pathlib import Path

import httpx

ROOT=Path.cwd()
OUT=ROOT/'artifacts/laptop-health-validation'
KUBE=ROOT/'artifacts/laptop-five-minute-kubernetes/kubeconfig'
CMD=['kubectl','--kubeconfig',str(KUBE),'--context','kind-mlpp-laptop-five-minute','-n','mlpp-demo']
sys.path.insert(0,str(ROOT/'artifacts/laptop-five-minute-validation'))
import restart_kubernetes as preserved
preserved.CMD=CMD
preserved.OUT=OUT


def write(name,data):(OUT/name).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')


def command(parts,name,timeout=300):
    with (OUT/(name+'.log')).open('wb') as log:
        subprocess.run(parts,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=timeout,creationflags=subprocess.CREATE_NO_WINDOW)


def forward(service,local,remote):
    with socket.socket() as probe:probe.bind(('127.0.0.1',local))
    log=(OUT/('forward-'+service+'-'+str(local)+'.log')).open('ab')
    process=subprocess.Popen([*CMD,'port-forward','service/'+service,str(local)+':'+str(remote),'--address','127.0.0.1'],stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
    return process,log


def ready(processes):
    for _ in range(30):
        assert all(p.poll() is None for p,_ in processes),'Port-forward exited'
        try:
            with httpx.Client(base_url='http://127.0.0.1:18000',timeout=2,trust_env=False,follow_redirects=False) as client:
                if client.get('/api/v1/health/ready').status_code==200:return
        except httpx.TransportError:pass
        time.sleep(1)
    raise TimeoutError('Gateway did not become ready')


def close(processes):
    for process,log in reversed(processes):
        process.terminate();process.wait(timeout=10);log.close()


def prepare():
    from ml_pipeline_pro.laptop_deployment import render_laptop_profile
    old=json.loads((ROOT/'artifacts/laptop-five-minute-kubernetes/smoke.json').read_text())
    before=preserved.capture(old,'before-health-rollout')
    write('preserved-before-rollout.json',before)
    image='ml-pipeline-pro:health-'+subprocess.check_output(['git','rev-parse','--short','HEAD'],text=True).strip()
    command(['docker','build','-t',image,'.'],'image-build',1200)
    command([str(ROOT/'.tools/bin/kind.exe'),'load','docker-image',image,'--name','mlpp-laptop-five-minute'],'image-load',600)
    manifest=render_laptop_profile(ROOT,OUT/'profile')
    data=json.loads(manifest.read_text())
    for item in data['items']:
        if item['kind']=='Deployment':
            for container in item['spec']['template']['spec']['containers']:
                if container['image'].startswith('ml-pipeline-pro:'):container['image']=image
    manifest.write_text(json.dumps(data,indent=2)+'\n')
    command([*CMD,'apply','-f',str(manifest)],'apply')
    for item in data['items']:
        if item['kind']=='Deployment':
            name=item['metadata']['name']
            command([*CMD,'rollout','status','deployment/'+name,'--timeout=180s'],'rollout-'+name)
    after=preserved.capture(old,'after-health-rollout')
    assert before==after,'Deployment changed preserved records/artifacts/replay identity'
    write('preserved-after-rollout.json',after)
    pods=json.loads(subprocess.check_output([*CMD,'get','pods','-o','json'],text=True))['items']
    expected={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'src/ml_pipeline_pro').glob('*.py')}
    observed=[]
    code="import json,hashlib,pathlib; p=pathlib.Path('/app/src/ml_pipeline_pro'); print(json.dumps({f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in p.glob('*.py')}))"
    for pod in pods:
        app=pod['metadata']['labels'].get('app')
        if app in ['model-api','monitoring-api','tuning-api']:
            actual=json.loads(subprocess.check_output([*CMD,'exec',pod['metadata']['name'],'--','python','-c',code],text=True))
            assert actual==expected,'Installed source differs from checkout'
            observed.append({'pod':pod['metadata']['name'],'app':app,'sha256':actual,'images':[{'image':c['image'],'imageID':c['imageID']} for c in pod['status']['containerStatuses']]})
    assert len([p for p in pods if p['metadata']['labels'].get('app')=='model-api'])==2
    assert len([p for p in pods if p['metadata']['labels'].get('app')=='worker'])==1
    write('deployed-source.json',{'image':image,'pods':observed,'preserved_records_artifacts_replay':True,'source_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'working_tree':subprocess.check_output(['git','status','--porcelain'],text=True)})


def ordinary():
    processes=[]
    try:
        for service,local,remote in [('gateway',18000,8000),('mongo',27017,27017),('redis',6379,6379)]:processes.append(forward(service,local,remote))
        ready(processes)
        env={**os.environ,'MLPP_RUN_INTEGRATION':'1','MLPP_RUN_WORKER_INTEGRATION':'1','MLPP_TEST_API_BASE_URL':'http://127.0.0.1:18000/api/v1','MLPP_TEST_MONGODB_URI':'mongodb://127.0.0.1:27017/?directConnection=true','MLPP_TEST_REDIS_URL':'redis://127.0.0.1:6379/0','UV_CACHE_DIR':str(ROOT/'.uv-cache')}
        subprocess.run([sys.executable,'artifacts/laptop-five-minute-validation/run_command.py','--phase','ordinary','--timeout','900','--output',str(OUT),'--',str(ROOT/'.tools/bin/uv/uv.exe'),'run','--offline','--locked','--extra','training','pytest','-m','integration and not recovery','--junitxml='+str(OUT/'ordinary.xml'),'--basetemp',str(OUT/'ordinary-temp'),'-o','cache_dir='+str(OUT/'pytest-cache-ordinary')],env=env,check=True,creationflags=subprocess.CREATE_NO_WINDOW)
    finally:close(processes)


def smoke():
    processes=[]
    try:
        processes.append(forward('gateway',18000,8000));ready(processes)
        with httpx.Client(base_url='http://127.0.0.1:18000',timeout=5,trust_env=False,follow_redirects=False) as client:
            response=client.get('/gateway-live',headers={'X-Correlation-ID':'deployed-health-check'})
            assert response.status_code==200 and response.json()=={'status':'alive'}
            assert response.headers['X-Correlation-ID']=='deployed-health-check'
        command([sys.executable,'scripts/deployment_smoke.py','--origin','http://127.0.0.1:18000','--output',str(OUT/'smoke.json')],'smoke')
        command([sys.executable,'scripts/check_api_replicas.py','--kubeconfig',str(KUBE),'--name','mlpp-laptop-five-minute','--smoke',str(OUT/'smoke.json'),'--output',str(OUT/'replicas')],'replicas')
    finally:close(processes)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('phase',choices=['prepare','ordinary','smoke','restart']);args=parser.parse_args()
    if args.phase=='prepare':prepare()
    elif args.phase=='ordinary':ordinary()
    elif args.phase=='smoke':smoke()
    else:preserved.main()
