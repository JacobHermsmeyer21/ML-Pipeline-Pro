$ErrorActionPreference = 'Stop'
$taskStart = [DateTimeOffset]::Parse('2026-10-19T21:29:34Z')
$taskEnd = [DateTimeOffset]::Parse('2026-10-19T21:48:18Z')
$result = [ordered]@{
    collected_utc = [DateTimeOffset]::UtcNow.ToString('o')
    query_start_utc = $taskStart.ToString('o')
    query_end_utc = $taskEnd.ToString('o')
    events = @()
    error = $null
    wslconfig_exists = (Test-Path -LiteralPath (Join-Path $env:USERPROFILE '.wslconfig'))
}
try {
    $taskEvents = Get-WinEvent -FilterHashtable @{
        LogName = 'System'
        StartTime = $taskStart.LocalDateTime
        EndTime = $taskEnd.LocalDateTime
    } | Where-Object {
        ($_.ProviderName -eq 'Microsoft-Windows-Kernel-Power' -and $_.Id -in @(42, 107, 109, 506, 507)) -or
        ($_.ProviderName -eq 'Microsoft-Windows-Power-Troubleshooter' -and $_.Id -eq 1)
    }
    $result.events = @($taskEvents | ForEach-Object {
        [ordered]@{ utc = $_.TimeCreated.ToUniversalTime().ToString('o'); provider = $_.ProviderName; id = $_.Id }
    })
} catch {
    $result.error = $_.Exception.Message
}
$result | ConvertTo-Json -Depth 5 | Set-Content -Encoding UTF8 artifacts/laptop-health-validation/power-events.json
$result | ConvertTo-Json -Depth 5
