"""Validate changed documentation paths/anchors and retain syntax-check inputs."""
import json
import re
import subprocess
import unicodedata
from pathlib import Path
from urllib.parse import unquote

root=Path.cwd();out=root/'artifacts/laptop-health-validation/doc-syntax';out.mkdir(exist_ok=True)
names=set(subprocess.check_output(['git','diff','HEAD','--name-only'],text=True).splitlines())
names.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard','docs'],text=True).splitlines())
files=[root/name for name in sorted(names) if name.endswith('.md')];broken=[];links=0;examples=[]
for path in files:
    source=path.read_text(encoding='utf-8-sig')
    for target in re.findall(r'\[[^\]]*\]\((<[^>]+>|[^)\s]+)(?:\s+"[^"]*\")?\)',source):
        target=unquote(target.strip('<>'))
        if re.match(r'^[a-z][a-z0-9+.-]*:',target,re.I):continue
        relative,_,anchor=target.partition('#');dest=(path.parent/relative).resolve() if relative else path;links+=1
        if not dest.exists():broken.append([path.as_posix(),target,'missing']);continue
        if anchor and dest.suffix=='.md':
            slugs=[]
            for heading in re.findall(r'^#{1,6}\s+(.+?)\s*#*$',dest.read_text(encoding='utf-8-sig'),re.M):
                heading=re.sub(r'<[^>]*>','',heading).lower()
                slugs.append(''.join(c for c in heading if c in '_- ' or unicodedata.category(c)[0] in 'LN').replace(' ','-'))
            if anchor not in slugs:broken.append([path.as_posix(),target,'anchor'])
    for block in re.findall(r'```powershell\s*\n(.*?)```',source,re.S):
        snippet=out/f'example-{len(examples):03}.ps1';snippet.write_text(block,encoding='utf-8');examples.append(snippet.as_posix())
report={'markdown_files':len(files),'local_links_anchors':links,'broken':broken,'powershell_examples':examples}
(root/'artifacts/laptop-health-validation/docs-check.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2));assert not broken
