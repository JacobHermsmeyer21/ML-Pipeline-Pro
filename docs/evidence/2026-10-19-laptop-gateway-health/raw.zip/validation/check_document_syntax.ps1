$ErrorActionPreference = 'Stop'
$taskSelection = Get-Content -Raw -LiteralPath artifacts/laptop-health-validation/docs-check.json | ConvertFrom-Json
$taskFiles = @($taskSelection.powershell_examples | ForEach-Object { Get-Item -LiteralPath $_ })
$taskResults = @()
foreach ($taskFile in $taskFiles) {
    $taskTokens = $null
    $taskErrors = $null
    $null = [System.Management.Automation.Language.Parser]::ParseFile($taskFile.FullName, [ref]$taskTokens, [ref]$taskErrors)
    $taskResults += [ordered]@{ file = $taskFile.Name; errors = @($taskErrors | ForEach-Object { $_.Message }) }
    if ($taskErrors.Count -gt 0) { throw "PowerShell syntax failed: $($taskFile.Name)" }
}
$taskReport = [ordered]@{ powershell_examples = $taskResults; executed_examples = $false }
$taskReport | ConvertTo-Json -Depth 6 | Set-Content -Encoding UTF8 artifacts/laptop-health-validation/document-syntax.json
$taskReport | ConvertTo-Json -Depth 6
