"""Derive narrow resource facts from immutable saved samples; invoke no services."""
import hashlib
import json
import re
from datetime import UTC, datetime
from pathlib import Path

out = Path('artifacts/laptop-health-validation')
host = [json.loads(s) for s in (out/'live-resources/host.jsonl').read_text().splitlines()]
node = [json.loads(s) for s in (out/'live-resources/node/samples.jsonl').read_text().splitlines()]

def valid(counter):
    return counter.get('format_status') == 0 and counter.get('value_status') in (0, 1)

def extreme(key, chooser):
    rows = [(s['performance'][key]['value'], s['utc']) for s in host
            if valid(s.get('performance', {}).get(key, {}))]
    value, utc = chooser(rows)
    return {'value': value, 'utc': utc, 'valid_samples': len(rows)}

def files(payload):
    return {name: body for name, body in re.findall(r'FILE=([^\n]+)\n(.*?)(?=\nFILE=|\Z)',payload,re.S)}

node_rows = []
for s in node:
    read = s.get('node_cgroup', {})
    parts = files(read.get('stdout',''))
    node_rows.append({
        'utc': s.get('utc'), 'sample_gap_seconds': s.get('gap_seconds'),
        'duration_seconds': s.get('duration_seconds'),
        'node_read_started_utc': read.get('started_utc'),
        'node_read_duration_seconds': read.get('duration_seconds'),
        'node_read_error': read.get('unavailable'), 'node_read_exit_code': read.get('exit_code'),
        'cpu_pressure': parts.get('/proc/pressure/cpu'),
        'memory_pressure': parts.get('/proc/pressure/memory'),
        'mem_available_kib': next((int(v) for v in re.findall(r'^MemAvailable:\s+(\d+) kB',parts.get('/proc/meminfo',''),re.M)),None),
        'gateway_cpu_stat': next((v for k,v in parts.items() if '68712c34a4a06d1dc9e7fe412e62fb48b3d51a644dd98ab7ebb839b917041630' in k),None),
        'probes': s.get('probes'), 'dns': s.get('dns_exec'),
    })
result = {
    'derived_utc': datetime.now(UTC).isoformat(),
    'host_samples': len(host), 'node_samples': len(node),
    'available_memory_min_bytes': extreme('\\Memory\\Available Bytes', min),
    'pages_input_max_per_second': extreme('\\Memory\\Pages Input/sec', max),
    'host_max_gap_seconds': max(s.get('sample_gap_seconds') or 0 for s in host),
    'host_max_sample_duration_seconds': max(s['duration_seconds'] for s in host),
    'node_max_gap_seconds': max(s.get('gap_seconds') or 0 for s in node),
    'host_process_selection': json.loads((out/'live-resources/pids.json').read_text()),
    'host_process_access_errors': sorted({e for s in host for p in s['processes'] for e in p.get('errors',[])}),
    'all_sampled_ac_connected': all(s['power']['ac_line_status']==1 for s in host),
    'node': node_rows,
    'limits': ['Inference worker llama-server absent from fixed selected host PIDs.',
        'vmmem CPU/working-set counter access denied; later process snapshot is separate.',
        'Page input includes file-backed reads; paging is not proof of swap thrashing.',
        'CPU PSI is pressure, not application CPU utilization.',
        'Raw command windows and gaps bound interpretation; timeouts can return late.',
        'Original initial/final pod status and idle=false are retained despite later observations.'],
}
(out/'resource-summary.json').write_text(json.dumps(result,indent=2)+'\n')
if not (out/'post-failure-runtime-slices.json').exists():
    summary = json.loads((out/'live-demo-summary.json').read_text())
    for key, meta in summary['runtime_slices'].items():
        data = Path('.tools/test-prerequisites',key).read_bytes()[meta['offset_bytes']:]
        dest = out/('post-failure-'+key)
        assert not dest.exists(), 'Retain an existing later runtime slice'
        dest.write_bytes(data)
        meta['later_size_bytes'] = len(data)
        meta['later_sha256'] = hashlib.sha256(data).hexdigest()
    (out/'post-failure-runtime-slices.json').write_text(json.dumps({'collected_utc':datetime.now(UTC).isoformat(),'slices':summary['runtime_slices'],'no_new_inference':True},indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['node','host_process_selection','limits']},indent=2))
print(json.dumps({'node_windows': [{k:v for k,v in s.items() if k in ['utc','sample_gap_seconds','duration_seconds','node_read_started_utc','node_read_duration_seconds','cpu_pressure','memory_pressure','mem_available_kib','gateway_cpu_stat']} for s in node_rows]},indent=2))
