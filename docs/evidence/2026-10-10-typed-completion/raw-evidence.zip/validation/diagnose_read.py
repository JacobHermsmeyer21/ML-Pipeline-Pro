import asyncio
import hashlib
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from evaluations.qwen_counter import create_counter
from evaluations.test_conversation_model import FixtureTransport, PROMPTS
from ml_pipeline_pro.config import Settings
from ml_pipeline_pro.conversation_ollama import OllamaConversationModel
from ml_pipeline_pro.conversation_schemas import ChatRequest
from ml_pipeline_pro.conversation_service import ConversationService
from ml_pipeline_pro.tool_schemas import ToolContext
from tests.conversation_memory import MemoryConversations

root=Path(__file__).resolve().parent
observations=[]
async def run():
    settings=Settings(_env_file=None,chat_enabled=True,chat_model='mlpp-qwen2.5:7b-instruct-q4_K_M-json-tools-v1',chat_max_output_tokens=512)
    native=OllamaConversationModel(settings)
    try:
        await native.prepare()
        counter=create_counter(dict(native.provenance))
        await native.close()
        native=OllamaConversationModel(settings,count_input_tokens=counter)
        await native.prepare()
        original=native._http.event_hooks['response'][0]
        async def observe(response):
            try:
                await original(response)
            finally:
                if response.request.url.path == '/api/chat' and response.is_stream_consumed:
                    observations.append({'request_sha256':hashlib.sha256(response.request.content).hexdigest(),'response':response.json()})
        native._http.event_hooks['response']=[observe]
        store=MemoryConversations()
        conversation_id,revision=None,0
        through=sys.argv[1] if len(sys.argv)>1 else 'read_guidance'
        turns=[]
        async with asyncio.timeout(600):
            for name,prompt in PROMPTS.items():
                service=ConversationService(settings,store,native,FixtureTransport())
                turn=await service.chat(ToolContext(project_id='demo'),ChatRequest(request_id=name,message=prompt,conversation_id=conversation_id,expected_revision=revision))
                conversation_id,revision=turn.conversation_id,turn.revision
                turns.append({'scenario':name,'turn':turn.model_dump(mode='json')})
                if name==through:
                    break
        report={'turns':turns,'observations':observations,'source_sha256':hashlib.sha256((Path.cwd()/'src/ml_pipeline_pro/conversation_model.py').read_bytes()).hexdigest(),'scope':'Synthetic read-only prefix; original five-call/60-second turn limits, at most 50 generation calls, 512 output tokens per call, 600 seconds overall; no action dispatch.'}
        (root/('diagnostic-'+through+'.json')).write_bytes((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode())
        print(json.dumps({'turn_status':turn.status,'responses':[{'message':item['response'].get('message'),'done_reason':item['response'].get('done_reason')} for item in observations]},ensure_ascii=False))
    finally:
        await native.close()
asyncio.run(run())
