import asyncio
import json
import sys

sys.path.insert(0, ".")
from tests.test_conversation_ollama import Runtime
from ml_pipeline_pro.conversation_model import native_conversation_tools

async def run():
    runtime = Runtime()
    async with runtime.model() as model:
        await model.generate([])
    actual = json.loads(runtime.requests[-1].content)["tools"]
    expected = native_conversation_tools()
    print(json.dumps([(a, b) for a, b in zip(actual, expected) if a != b], indent=2))

asyncio.run(run())
