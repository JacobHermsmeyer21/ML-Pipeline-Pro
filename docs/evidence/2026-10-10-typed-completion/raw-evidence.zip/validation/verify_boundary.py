"""One real inference at the admission boundary; one rejected overflow request."""
import asyncio
import copy
import json
from pathlib import Path

import httpx

from ml_pipeline_pro.config import Settings
from ml_pipeline_pro.conversation_model import ConversationModelError
from ml_pipeline_pro.conversation_ollama import OllamaConversationModel
from ml_pipeline_pro.conversation_qwen_counter import QwenInputCounter

root=Path(__file__).resolve().parent
observed=[]
class Transport(httpx.AsyncHTTPTransport):
    def __init__(self):
        super().__init__(retries=0)
        self.requests=[]
    async def handle_async_request(self, request):
        self.requests.append((request.method,request.url.path))
        return await super().handle_async_request(request)

async def run():
    settings=Settings(_env_file=None,chat_enabled=True,chat_model='mlpp-qwen2.5:7b-instruct-q4_K_M-json-tools-v1',chat_max_output_tokens=512)
    transport=Transport()
    captured=[]
    def capture(payload):
        captured.append(copy.deepcopy(payload))
        return settings.chat_context_tokens  # Inspection only: block before HTTP.
    model=OllamaConversationModel(settings,count_input_tokens=capture,async_transport=transport)
    try:
        await model.prepare()
        counter=QwenInputCounter(model.provenance,Path('.tools/local-model-setup/tokenizer.json'))
        initial=[{'role':'system','content':'This is a read-only token admission check. Use get_experiment once with exp-low.'},{'role':'user','content':'Inspect exp-low.'}]
        try:
            await model.generate(initial)
        except ConversationModelError as error:
            assert error.code=='chat_limit_exceeded'
        assert len(captured)==1 and not any(path=='/api/chat' for _,path in transport.requests)
        base=captured[0]
        assert len(base['tools']) == 14
        def messages(number):
            history=[]
            while number:
                chunk=min(number,3000)
                history.extend([{'role':'user','content':' a'*chunk},{'role':'assistant','content':'{}'}])
                number-=chunk
            return [initial[0],*history,initial[-1]]
        def count(number):
            return counter({**base,'messages':[base['messages'][0],*messages(number)]})
        target=settings.chat_context_tokens-settings.chat_max_output_tokens
        low,high=0,9000
        while low<high:
            middle=(low+high+1)//2
            if count(middle)<=target:
                low=middle
            else:
                high=middle-1
        assert count(low)==target and count(low+1)==target+1
        model._count_input_tokens=counter
        original=model._http.event_hooks['response'][0]
        async def response_hook(response):
            try:
                await original(response)
            finally:
                if response.request.url.path=='/api/chat' and response.is_stream_consumed:
                    observed.append(response.json())
        model._http.event_hooks['response']=[response_hook]
        positive_error=None
        try:
            await model.generate(messages(low))
        except ConversationModelError as error:
            positive_error=error.code
        assert len(observed)==1
        assert observed[0]['prompt_eval_count']==target
        assert observed[0]['eval_count']<=settings.chat_max_output_tokens
        before=len(transport.requests)
        try:
            await model.generate(messages(low+1))
            raise AssertionError('Overflow was admitted')
        except ConversationModelError as error:
            assert error.code=='chat_limit_exceeded'
        assert len(transport.requests)==before, 'Overflow reached HTTP transport'
        report={'model_provenance':model.provenance,'native_schema_count':len(base['tools']),'input_at_boundary':target,'reserved_output_tokens':settings.chat_max_output_tokens,'context_tokens':settings.chat_context_tokens,'overflow_input':target+1,'positive_runtime_input_tokens':observed[0]['prompt_eval_count'],'positive_runtime_output_tokens':observed[0]['eval_count'],'positive_parse_error':positive_error,'overflow_http_requests':0,'real_generation_calls':1,'response':observed[0],'scope':'Token admission only; synthetic history, no tool dispatch or model-quality claim.'}
        (root/'overflow-verification.json').write_bytes((json.dumps(report,indent=2)+'\n').encode())
        print(json.dumps({key:report[key] for key in report if key not in ('response','scope')}))
    finally:
        await model.close()
asyncio.run(run())
