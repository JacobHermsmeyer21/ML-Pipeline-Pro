"""Verify the approved slice's retained runs and archive their raw provenance."""

import hashlib
import importlib.metadata
import json
import platform
import subprocess
import tarfile
import xml.etree.ElementTree as ET
import zipfile
from datetime import UTC, datetime
from pathlib import Path

root = Path(__file__).resolve().parent
destination = Path("docs/evidence/2026-10-10-typed-completion")
destination.mkdir(parents=True, exist_ok=True)
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
source = read(root / "fast-source.json")
for path, digest in source.items():
    assert sha(Path(path).read_bytes()) == digest, path
for label in ("integration", "recovery", "live-1", "real-boundary"):
    assert read(root / f"{label}-source.json") == source, label
verification = {}
for label, expected in (("fast", 446), ("integration", 58), ("recovery", 10)):
    suites = list(ET.parse(root / f"{label}.xml").iter("testsuite"))
    counts = {key: sum(int(s.get(key, "0")) for s in suites)
              for key in ("tests", "failures", "errors", "skipped")}
    assert counts == {"tests": expected, "failures": 0, "errors": 0, "skipped": 0}, counts
    verification[label] = {**counts, **read(root / f"{label}.json")}
checks = {}
for label in ("locked-sync", "lint", "format", "dependencies", "build", "real-boundary", "docs-final"):
    checks[label] = read(root / f"{label}.json")
    assert checks[label]["native_exit_code"] == 0, label
live = read(root / "live-1-results.json")
assert len(live["cases"]) == 10 and live["status"] == "failed"
assert read(root / "live-1.json")["native_exit_code"] == 1
passed = [case["scenario"] for case in live["cases"] if case["status"] == "passed"]
assert len(passed) == 3
boundary = read(root / "overflow-verification.json")
assert boundary["native_schema_count"] == 14
assert boundary["input_at_boundary"] == boundary["positive_runtime_input_tokens"] == 7680
assert boundary["reserved_output_tokens"] == 512 and boundary["context_tokens"] == 8192
assert boundary["overflow_input"] == 7681 and boundary["overflow_http_requests"] == 0
assert live["model_provenance"] == boundary["model_provenance"]

wheel = Path("dist/ml_pipeline_pro-0.1.0-py3-none-any.whl")
sdist = Path("dist/ml_pipeline_pro-0.1.0.tar.gz")
with zipfile.ZipFile(wheel) as archive:
    modules = {name for name in archive.namelist() if name.startswith("ml_pipeline_pro/") and name.endswith(".py")}
    expected = {path.removeprefix("src/") for path in source if path.startswith("src/")}
    assert modules == expected and len(modules) == 37
    for path in expected:
        assert archive.read(path) == Path("src", path).read_bytes(), path
with tarfile.open(sdist) as archive:
    names = archive.getnames()
    assert all(not {".tools", ".cache", ".uv-cache", ".venv", ".env", ".git", "artifacts"}.intersection(Path(name).parts) for name in names)

recovery = Path("artifacts/recovery-validation/mlpp-recovery-adf6a1c5f623")
assert (recovery / "compose.log").exists()
files = {f"validation/{path.name}": path.read_bytes() for path in root.iterdir() if path.is_file()}
files.update({f"source/{path}": Path(path).read_bytes() for path in source})
support = ("pyproject.toml", "uv.lock", "Dockerfile", "compose.yaml", ".env.example",
           "tests/integration/compose.validation.yaml", "tests/integration/compose.recovery.yaml",
           "tests/fixtures/qwen_runtime_render.json", "examples/qwen-json-tools.gotmpl")
for path in support:
    data = Path(path).read_bytes()
    assert subprocess.check_output(["git", "show", f"HEAD:{path}"]) == data, path
    files[f"source/{path}"] = data
files.update({f"recovery/{path.relative_to(recovery).as_posix()}": path.read_bytes() for path in recovery.rglob("*") if path.is_file()})
archive_path = destination / "raw-evidence.zip"
with zipfile.ZipFile(archive_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
    for path, data in sorted(files.items()):
        archive.writestr(path, data)
record = {
    "client_date": "2026-10-10", "recorded_at_utc": datetime.now(UTC).isoformat(),
    "source_baseline": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
    "branch": subprocess.check_output(["git", "branch", "--show-current"], text=True).strip(),
    "working_tree": True, "platform": platform.platform(), "python": platform.python_version(),
    "approval": {"reviewer": "repository user", "date": "2026-10-10", "reference": "I approve the typed plan, start implementing"},
    "source_files_sha256": source,
    "support_files_sha256": {path: sha(Path(path).read_bytes()) for path in support},
    "packages": {name: importlib.metadata.version(name) for name in ("langchain-core", "langchain-ollama", "ollama", "tokenizers", "pydantic", "torch", "pytest", "ruff")},
    "verification": verification, "checks": checks,
    "coverage_percent": read(root / "coverage.json")["totals"]["percent_covered"],
    "package_inspection": {"wheel_application_modules": len(modules), "private_paths_absent": True,
                           "sha256": {path.name: sha(path.read_bytes()) for path in (wheel, sdist)}},
    "model_provenance": live["model_provenance"],
    "live_acceptance": {"status": "failed", "native_exit_code": 1, "passed_scenarios": passed,
                        "failed_scenarios": [case["scenario"] for case in live["cases"] if case["status"] != "passed"],
                        "generation_calls": len(live["calls"]), "reserved_tokens": live["reserved_tokens"],
                        "budget": live["budget"], "raw_result": "validation/live-1-results.json"},
    "token_admission": {key: value for key, value in boundary.items() if key != "response"},
    "diagnostic": {"raw_result": "validation/diagnostic-read_guidance.json", "scope": "Separate read-only diagnostic, not acceptance; observed 23 repeated native reads and output-length termination."},
    "review": {"reviewer": "implementing assistant", "independent": False,
               "scope": "Completion isolation, strict SDK parsing, schema byte/token accounting, unchanged confirmation/storage paths and saved failures",
               "independent_review_status": "unavailable; outstanding before A1 closure"},
    "archive": {"path": "raw-evidence.zip", "sha256": sha(archive_path.read_bytes()),
                "files_sha256": {path: sha(data) for path, data in sorted(files.items())}},
    "limits": ["Live acceptance failed; A1 and C3/C5 remain outstanding.",
               "Independent review, human model-quality review and complete clean-checkout onboarding remain outstanding.",
               "Diagnostic requests are separate from acceptance; synthetic metrics are not training measurements.",
               "Host coverage excludes container execution; no latency, capacity or remote CI claim.",
               "No weights, tokenizer data, credentials or private environment files are archived."]
}
(destination / "results.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"verification": {key: value["tests"] for key, value in verification.items()},
                  "coverage_percent": record["coverage_percent"], "live_passed": len(passed),
                  "archive_files": len(files), "archive_bytes": archive_path.stat().st_size}))
