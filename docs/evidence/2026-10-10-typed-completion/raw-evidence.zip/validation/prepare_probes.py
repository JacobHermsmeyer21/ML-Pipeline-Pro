from pathlib import Path

destination = Path(__file__).resolve().parent
source = Path(".tools/local-model-setup")
boundary = (source / "verify_overflow.py").read_text(encoding="utf-8")
boundary = boundary.replace("root/'tokenizer.json'", "Path('.tools/local-model-setup/tokenizer.json')")
boundary = boundary.replace("chat_model='qwen2.5:7b-instruct-q4_K_M'", "chat_model='mlpp-qwen2.5:7b-instruct-q4_K_M-json-tools-v1'")
boundary = boundary.replace("base=captured[0]", "base=captured[0]\n        assert len(base['tools']) == 14")
boundary = boundary.replace("report={'input_at_boundary'", "report={'model_provenance':model.provenance,'native_schema_count':len(base['tools']),'input_at_boundary'")
(destination / "verify_boundary.py").write_text(boundary, encoding="utf-8")
diagnostic = (source / "diagnose_live_reply.py").read_text(encoding="utf-8")
(destination / "diagnose_read.py").write_text(diagnostic, encoding="utf-8")
