"""Retain native exits and byte-preserving command output for this approved slice."""

import json
import hashlib
import os
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path

root = Path(__file__).resolve().parent
label, *command = sys.argv[1:]
env = {**os.environ, "UV_CACHE_DIR": str(Path.cwd() / ".cache/uv")}
started = datetime.now(UTC)
(root / f"{label}-source.json").write_text(
    json.dumps({str(path).replace("\\", "/"): hashlib.sha256(path.read_bytes()).hexdigest()
                for directory in ("src", "tests", "evaluations", "examples")
                for path in Path(directory).rglob("*.py")}, indent=2) + "\n",
    encoding="utf-8",
)
with (root / f"{label}.log").open("wb") as output:
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env)
    for line in process.stdout:
        output.write(line)
        output.flush()
        sys.stdout.buffer.write(line)
        sys.stdout.buffer.flush()
    code = process.wait()
(root / f"{label}.json").write_text(
    json.dumps({"command": command, "native_exit_code": code,
                "started_at_utc": started.isoformat(),
                "ended_at_utc": datetime.now(UTC).isoformat()}, indent=2) + "\n",
    encoding="utf-8",
)
sys.exit(code)
