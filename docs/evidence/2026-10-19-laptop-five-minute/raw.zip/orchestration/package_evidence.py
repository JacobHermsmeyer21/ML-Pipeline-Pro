"""Package only explicit, non-secret test artifacts; verify bytes without extraction."""
import hashlib
import json
import zipfile
from pathlib import Path

ROOT=Path.cwd()
BASE=ROOT/'artifacts/laptop-five-minute-validation'
DEMO=ROOT/'artifacts/laptop-five-minute-demo'
GATES=ROOT/'artifacts/laptop-five-minute-model-gates'
TARGET=ROOT/'docs/evidence/2026-10-19-laptop-five-minute'


def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))


def gate(name):
    path=GATES/(name+'.json')
    if not path.exists(): return {'status':'not_run','cases':[]}
    data=read(path)
    cases=data['cases']
    passed=[c['scenario'] for c in cases if c.get('status')=='passed' or c.get('passed') is True]
    failed=[c['scenario'] for c in cases if c['scenario'] not in passed]
    expected=10 if name=='conversation' else 7
    unrun=data.get('unrun_scenarios',[])
    if name=='conversation' and not unrun:
        import ast
        source=ast.parse((ROOT/'evaluations/test_conversation_model.py').read_text())
        prompts=next(ast.literal_eval(node.value) for node in source.body if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PROMPTS' for t in node.targets))
        unrun=[scenario for scenario in prompts if scenario not in {c['scenario'] for c in cases}]
    value={'status':'passed' if len(cases)==expected and not failed else 'failed',
            'passed':passed,'failed_or_incomplete':failed,'unrun_scenarios':unrun,
            'unrun_list_provenance':'Derived from original scenario order when raw report was interrupted before fail-fast bookkeeping.',
            'case_elapsed_seconds':{c['scenario']:c.get('elapsed_seconds') for c in cases},
            'budget':data.get('budget'),'timing_profile':data.get('timing_profile')}
    execution=BASE/('conversation-gate-execution.json' if name=='conversation' else 'snippet-gate-execution.json')
    if execution.exists():
        executed=read(execution)
        value['execution']={k:executed[k] for k in ['started_utc','ended_utc','elapsed_seconds','exit_code','power_before','power_after']}
    if name=='conversation':
        value['interruption']={'kind':'Windows system sleep during hostile_record','sleep_utc':'2026-10-19T16:45:40.146298400Z','wake_utc':'2026-10-19T18:05:28.288237000Z','source':'validation/gate-power-events.json','limits':'Case/command/runtime elapsed values include suspension and are not active CPU-only performance or proof of timely timeout enforcement.'}
        value['runner_idle_after_gate']=read(BASE/'model-gate-runtime-slices.json')['runner_idle_after_gate']
    return value


def main():
    TARGET.mkdir(parents=True,exist_ok=True)
    demo=read(DEMO/'results.json')
    summary=read(BASE/'demo-summary.json')
    histories=read(BASE/'public-histories.json')
    turns=next(iter(histories.values()))['turns']
    states=read(BASE/'kubernetes-failure-pods.json')
    gateway=next(p for p in states if p['app']=='gateway')
    events=read(BASE/'kubernetes-failure-events.json')
    killing=next(e for e in events if e['reason']=='Killing' and e['involvedObject']['name']==gateway['name'] and 'liveness' in e['message'])
    serving=[]
    for path in BASE.glob('model-api*.log'):
        for line in path.read_text(encoding='utf-8-sig').splitlines():
            try: row=json.loads(line)
            except ValueError: continue
            if row.get('correlation_id')==turns[1]['correlation_id'] and 'phase=complete_turn event=end' in row.get('message',''):
                serving.append({'file':path.name,'timestamp':row['timestamp'],'duration_ms':row['duration_ms']})
    result={'date':'2026-10-19','application_revision':summary['source_revision'],
            'timing_profile':summary['timing_profile'],
            'budgets_seconds':{'model_call':240,'whole_turn':270,'client':300,'gateway_read':310},
            'complete_workflow_passed':summary['complete_workflow_passed'],
            'power_before':summary['power_before'],'power_after':summary['power_after'],
            'first_inspection':{'client_elapsed_seconds':demo['ai_requests'][0]['elapsed_seconds'],
                'http_status':demo['ai_requests'][0]['status_code'],'saved_status':turns[0]['status'],
                'facts':turns[0]['facts'],'tool_result_count':len(turns[0]['tool_results'])},
            'comparison':{'client_elapsed_seconds':demo['ai_requests'][1]['elapsed_seconds'],
                'client_failure':demo['ai_requests'][1]['failure_type'],
                'saved_status':turns[1]['status'],'saved_message':turns[1]['message'],
                'facts':turns[1]['facts'],'pending_action':turns[1]['pending_action'],
                'tool_results':[{'name':t['tool_name'],'status':t['status'],'error':t.get('error')} for t in turns[1]['tool_results']],
                'server_complete_turn_observations':serving},
            'confirmed_delivery_failure':{'event':killing,'gateway_last_state':gateway['status']['containerStatuses'][0]['lastState'],
                'finding':'Kubernetes liveness-triggered gateway termination broke client delivery before reply-window exhaustion. The internal tool failed during the gateway outage; its exact socket failure mechanism was not captured.',
                'limits':'Cause of broad probe/DNS delays is unmeasured. Exit 137 with reason Error is not proof of OOM.'},
            'runner_idle_after_demo':summary['runner_idle_after'],
            'new_generation_retries':0,'generated_code_execution':False,
            'model_gates':{name:gate(name) for name in ['conversation','snippets']},
            'not_reached_in_complete_walkthrough':['exact proposal confirmation and resulting tuning','validated Python draft and replay','measured monitoring producer and AI diagnosis'],
            'validation':read(BASE/'implementation-verification.json'),
            'orchestration_limits':'Untracked final orchestration helpers retained byte-for-byte. Initial post-failure history collection hit RemoteProtocolError; later pure-GET collection succeeded without generation/confirmation. Kubernetes original rollout and dependency import attempts failed; continued unchanged rollout/smoke and node restart passed.'}
    if (BASE/'ci-current.json').exists(): result['implementation_ci']=read(BASE/'ci-current.json')
    payload={}
    def add(path, prefix):
        if path.exists(): payload[prefix+'/'+path.name]=path.read_bytes()
    for pattern in ['*.log','*-execution.json','*.xml']:
        for path in BASE.glob(pattern): add(path,'validation')
    for name in ['implementation-verification.json','machine-runtime.json','deployed-compose.json','deployed-kubernetes.json','docs-check.json','restart-result.json','continued-deployment-result.json','demo-summary.json','public-histories.json','saved-deadline-audit.json','kubernetes-failure-pods.json','kubernetes-failure-events.json','ci-at-deploy.json','ci-current.json','model-gate-runtime-slices.json','monitoring-component.json','gate-power-events.json']:
        add(BASE/name,'validation')
    for path in BASE.glob('*.py'): add(path,'orchestration')
    for name in ['final-docs-check.json','evidence-review.json']:
        add(BASE/name,'validation')
    for path in DEMO.glob('*.json'): add(path,'walkthrough')
    for path in GATES.glob('*.json'): add(path,'model-gates')
    kube=ROOT/'artifacts/laptop-five-minute-kubernetes'
    for path in kube.glob('*.log'): add(path,'kubernetes')
    add(kube/'smoke.json','kubernetes')
    for path in (kube/'replicas').glob('*.json'): add(path,'replicas')
    for path in (kube/'replicas').glob('*.log'): add(path,'replicas')
    for path in (ROOT/'src/ml_pipeline_pro').glob('*.py'): add(path,'application-source')
    for path in [*(ROOT/'evaluations').glob('*.py'), ROOT/'examples/midterm_walkthrough.py', ROOT/'scripts/deploy_kind.py', ROOT/'scripts/render_laptop_profile.py']:
        add(path,'harness-source')
    manifest={name:{'sha256':hashlib.sha256(data).hexdigest(),'size_bytes':len(data)} for name,data in sorted(payload.items())}
    payload['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
    archive=TARGET/'raw.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as bundle:
        for name,data in sorted(payload.items()): bundle.writestr(name,data)
    with zipfile.ZipFile(archive) as bundle:
        assert bundle.testzip() is None
        assert set(bundle.namelist())==set(manifest)|{'manifest.json'}
        for name,expected in manifest.items():
            data=bundle.read(name)
            assert len(data)==expected['size_bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256']
    result['raw_archive_sha256']=hashlib.sha256(archive.read_bytes()).hexdigest()
    (TARGET/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    (TARGET/'verification.json').write_text(json.dumps({'archive_crc':'pass','manifest_payloads':len(manifest),'exact_hashes_sizes':'pass','credentials_environment_dump_kubeconfig_weights_installers':'excluded','source_revision':summary['source_revision']},indent=2)+'\n')
    print(json.dumps({'payload_files':len(manifest),'archive_size_bytes':archive.stat().st_size,'archive_sha256':result['raw_archive_sha256'],'gates':result['model_gates']},indent=2))


if __name__=='__main__': main()
