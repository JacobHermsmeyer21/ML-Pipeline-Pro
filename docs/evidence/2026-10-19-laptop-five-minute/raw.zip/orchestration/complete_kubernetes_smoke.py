"""Continue the original rollout/smoke after retaining its cold-pull timeout."""
import json
import subprocess
import sys
import time
from pathlib import Path

import httpx

from kubernetes_demo import CMD, OUT

BASE=Path('artifacts/laptop-five-minute-kubernetes')


def command(parts,name):
    with (OUT/(name+'.log')).open('wb') as log:
        subprocess.run(parts,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=300)


def main():
    manifest=json.loads((BASE/'laptop-profile/stack.json').read_text())
    for item in manifest['items']:
        if item['kind']=='Deployment':
            name=item['metadata']['name']
            command([*CMD,'rollout','status','deployment/'+name,'--timeout=180s'],'continued-rollout-'+name)
    pods=json.loads(subprocess.check_output([*CMD,'get','pods','-o','json'],text=True))
    assert len([p for p in pods['items'] if p['metadata']['labels'].get('app')=='model-api'])==2
    assert len([p for p in pods['items'] if p['metadata']['labels'].get('app')=='worker'])==1
    with (OUT/'continued-forward.log').open('wb') as log:
        process=subprocess.Popen([*CMD,'port-forward','service/gateway','18000:8000','--address','127.0.0.1'],stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
        try:
            for _ in range(30):
                assert process.poll() is None
                try:
                    if httpx.get('http://127.0.0.1:18000/api/v1/health/ready',timeout=2,trust_env=False).status_code==200: break
                except httpx.TransportError: pass
                time.sleep(1)
            else: raise TimeoutError('Continued gateway readiness failed')
            command([sys.executable,'scripts/deployment_smoke.py','--origin','http://127.0.0.1:18000','--output',str(BASE/'smoke.json')],'continued-smoke')
            command([sys.executable,'scripts/check_api_replicas.py','--kubeconfig',str(BASE/'kubeconfig'),'--name','mlpp-laptop-five-minute','--smoke',str(BASE/'smoke.json'),'--output',str(BASE/'replicas')],'continued-replicas')
        finally:
            process.terminate(); process.wait(timeout=10)
    (OUT/'continued-deployment-result.json').write_text(json.dumps({'passed':True,'timing_profile':'laptop-five-minute','model_api_replicas':2,'serial_workers':1,'original_rollout_failed':True,'dependency_import_attempt_failed':True,'continuation':'Dependency pods became ready after initial cold-pull timeout and a failed cache import attempt. Continue original 180-second rollout checks and unchanged smoke/replica scripts; do not attribute readiness to the failed import.'},indent=2)+'\n')
    print('Continued original rollout, complete backend smoke and both-pod submission replay pass.')


if __name__=='__main__': main()
