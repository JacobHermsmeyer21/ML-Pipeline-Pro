"""Retain filtered runner evidence following the known final demo task, without prompts."""
import hashlib
import json
import re
from datetime import UTC, datetime
from pathlib import Path

base=Path('artifacts/laptop-five-minute-validation')
source=Path('.tools/test-prerequisites')
stderr=(source/'ollama-stderr.log').read_bytes()
lines=stderr.decode('utf-8',errors='replace').splitlines()
marker=next(i for i,line in enumerate(lines) if 'task 230 | stop processing' in line)
tail=lines[marker+1:]
filtered=[line for line in tail if re.search(r'all slots are idle|prompt eval time|eval time|total time|cached n_tokens|cancel task|stop processing|new prompt',line)]
(base/'ollama-stderr-model-gates-filtered.log').write_text('\n'.join(filtered)+'\n',encoding='utf-8')
stdout=(source/'ollama-stdout.log').read_bytes()
selected=[line for line in stdout.decode('utf-8',errors='replace').splitlines() if '/api/chat' in line and '2026/10/19' in line and (re.search(r' - 12:(?:3[7-9]|[4-5]\d):',line) or ' - 14:06:' in line)]
(base/'ollama-stdout-model-gates-filtered.log').write_text('\n'.join(selected)+'\n',encoding='utf-8')
states=[line for line in tail if re.search('all slots are idle|new prompt|cancel task|stop processing',line)]
report={'collected_utc':datetime.now(UTC).isoformat(),'stderr_source_sha256':hashlib.sha256(stderr).hexdigest(),'stderr_source_bytes':len(stderr),'stdout_source_sha256':hashlib.sha256(stdout).hexdigest(),'stdout_source_bytes':len(stdout),'selection':'stderr after final demo task 230 release, payload-free timing/state rows; stdout /api/chat completion rows in gate window. Not per-case timestamps for stderr.','runner_final_state':states[-1] if states else None,'runner_idle_after_gate':bool(states and 'all slots are idle' in states[-1]),'gate_sleep':'Windows Power-Troubleshooter records sleep 16:45:40.146Z to wake 18:05:28.288Z; raw gate-power-events.json retained. Do not treat sleep-inclusive runtime timing as CPU-only performance.','snippets':'Not started: AC prerequisite no longer met after interrupted dialogue gate; awaiting user availability.'}
(base/'model-gate-runtime-slices.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
