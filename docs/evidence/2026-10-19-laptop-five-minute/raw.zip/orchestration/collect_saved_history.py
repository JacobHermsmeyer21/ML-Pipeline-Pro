"""Read saved state after failed delivery; never regenerate or approve actions."""
import json
import subprocess
import time
from pathlib import Path

import httpx

from kubernetes_demo import CMD, OUT


def main():
    results=json.loads(Path('artifacts/laptop-five-minute-demo/results.json').read_text())
    identities={turn['conversation_id'] for turn in results.get('dialogue',[])}
    with (OUT/'history-reconnect-forward.log').open('wb') as log:
        process=subprocess.Popen([*CMD,'port-forward','service/gateway','18000:8000','--address','127.0.0.1'],stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
        try:
            with httpx.Client(base_url='http://127.0.0.1:18000',headers={'X-Project-ID':'demo'},timeout=10,trust_env=False,follow_redirects=False) as client:
                for _ in range(30):
                    assert process.poll() is None
                    try:
                        if client.get('/api/v1/health/ready').status_code==200: break
                    except httpx.TransportError: pass
                    time.sleep(1)
                else: raise TimeoutError('History reconnect readiness failed')
                histories={}
                for identity in identities:
                    response=client.get('/api/v1/conversations/'+identity)
                    response.raise_for_status()
                    histories[identity]=response.json()
                (OUT/'public-histories.json').write_text(json.dumps(histories,indent=2)+'\n')
                print(json.dumps({key:[{'request_id':t['request_id'],'status':t['status'],'tool_results':len(t['tool_results']),'pending_action_status':t['pending_action']['status'] if t['pending_action'] else None} for t in value['turns']] for key,value in histories.items()},indent=2))
        finally:
            process.terminate(); process.wait(timeout=10)
    request_ids=[results['backend']['training']['id']+'-'+suffix for suffix in ['inspect','suggest']]
    script='import json; from bson.json_util import dumps; from pymongo import MongoClient; from ml_pipeline_pro.config import Settings; s=Settings(); c=MongoClient(s.mongodb_uri.get_secret_value(),serverSelectionTimeoutMS=3000); print(dumps(list(c[s.mongodb_database].conversation_turns.find({"project_id":"demo","request_id":{"$in":'+json.dumps(request_ids)+'}},{"_id":1,"request_id":1,"created_at":1,"deadline":1,"state":1,"public.status":1,"public.pending_action":1}))))'
    pods=json.loads(subprocess.check_output([*CMD,'get','pods','-l','app=model-api','-o','json'],text=True))['items']
    raw=subprocess.check_output([*CMD,'exec',pods[0]['metadata']['name'],'--','python','-c',script],text=True)
    (OUT/'saved-deadline-audit.json').write_text(json.dumps(json.loads(raw),indent=2)+'\n')


if __name__=='__main__': main()
