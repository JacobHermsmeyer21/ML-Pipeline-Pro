"""Validate this documentation change, local anchors and embedded PowerShell syntax inputs."""
import hashlib
import json
import re
import subprocess
import unicodedata
import zipfile
from pathlib import Path
from urllib.parse import unquote

root=Path.cwd()
base=root/'artifacts/laptop-five-minute-validation'
names=set(subprocess.check_output(['git','diff','HEAD','--name-only'],text=True).splitlines())
names.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard','docs'],text=True).splitlines())
files=[root/name for name in sorted(names) if name.endswith('.md')]
broken=[]; links=0; examples=[]
out=base/'final-doc-syntax';out.mkdir(exist_ok=True)
for path in files:
    source=path.read_text(encoding='utf-8-sig')
    for target in re.findall(r'\[[^\]]*\]\((<[^>]+>|[^)\s]+)(?:\s+"[^"]*")?\)',source):
        target=unquote(target.strip('<>'))
        if re.match(r'^[a-z][a-z0-9+.-]*:',target,re.I):continue
        relative,_,anchor=target.partition('#')
        dest=(path.parent/relative).resolve() if relative else path
        links+=1
        if not dest.exists():broken.append([str(path.relative_to(root)),target,'missing path']);continue
        if anchor and dest.suffix=='.md':
            headings=re.findall(r'^#{1,6}\s+(.+?)\s*#*$',dest.read_text(encoding='utf-8-sig'),re.M)
            slugs=set()
            for heading in headings:
                heading=re.sub(r'<[^>]*>','',heading).lower()
                heading=''.join(c for c in heading if c in '_- ' or unicodedata.category(c)[0] in 'LN')
                slugs.add(heading.replace(' ','-'))
            if anchor not in slugs:broken.append([str(path.relative_to(root)),target,'missing anchor'])
    for block in re.findall(r'```powershell\s*\n(.*?)```',source,re.S):
        snippet=out/f'example-{len(examples):03}.ps1';snippet.write_text(block,encoding='utf-8')
        examples.append({'file':snippet.relative_to(root).as_posix(),'source':path.relative_to(root).as_posix()})
evidence=root/'docs/evidence/2026-10-19-laptop-five-minute'
results=json.loads((evidence/'results.json').read_text())
raw=evidence/'raw.zip'
assert hashlib.sha256(raw.read_bytes()).hexdigest()==results['raw_archive_sha256']
with zipfile.ZipFile(raw) as archive:
    assert archive.testzip() is None
    manifest=json.loads(archive.read('manifest.json'))
    assert set(archive.namelist())==set(manifest)|{'manifest.json'}
    for name,item in manifest.items():
        payload=archive.read(name)
        assert len(payload)==item['size_bytes'] and hashlib.sha256(payload).hexdigest()==item['sha256']
        assert 'kubeconfig' not in name.lower() and not name.endswith('.env')
        assert not re.search(rb'(?:gh[pousr]_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{20,}|-----BEGIN [A-Z ]*PRIVATE KEY-----)',payload),name
    for name,value in results['validation']['source_sha256'].items():
        assert hashlib.sha256((root/name).read_bytes()).hexdigest()==value,name
    histories=json.loads(archive.read('validation/public-histories.json'))
    turns=next(iter(histories.values()))['turns']
    assert len(turns)==2 and turns[0]['facts'][0]['value']==1.0
    assert not turns[1]['facts'] and turns[1]['pending_action'] is None
    assert turns[1]['tool_results'][0]['error']['code']=='tool_transport_error'
assert results['complete_workflow_passed'] is False
assert len(results['model_gates']['conversation']['passed'])==8
assert results['model_gates']['conversation']['status']=='failed'
assert results['model_gates']['snippets']['status']=='not_run'
assert results['implementation_ci']['conclusion']=='success'
for path in evidence.glob('*.json'):json.loads(path.read_text())
report={'markdown_files':len(files),'local_links_anchors':links,'broken':broken,'powershell_examples':examples,'archive_hash_manifest_crc':'pass','source_hashes':'pass','secret_pattern_scan':'pass','factual_boundary_assertions':'pass'}
(base/'final-docs-check.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
assert not broken
