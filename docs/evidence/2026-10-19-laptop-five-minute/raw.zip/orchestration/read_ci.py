"""Read this repository's CI using its existing credential only in memory."""
import json
import os
import subprocess
from pathlib import Path

import httpx

credential = subprocess.run(
    ['git','credential','fill'],
    input='protocol=https\nhost=github.com\npath=JacobHermsmeyer21/ML-Pipeline-Pro\n\n',
    capture_output=True,text=True,timeout=20,
    env={**os.environ,'GIT_TERMINAL_PROMPT':'0','GCM_INTERACTIVE':'never'},
)
if credential.returncode:
    raise SystemExit('Existing repository credential unavailable; no credential output retained')
fields=dict(line.split('=',1) for line in credential.stdout.splitlines() if '=' in line)
token=fields.get('password')
if not token: raise SystemExit('Existing repository credential unavailable')
with httpx.Client(base_url='https://api.github.com',headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json'},timeout=15,trust_env=False,follow_redirects=False) as client:
    response=client.get('/repos/JacobHermsmeyer21/ML-Pipeline-Pro/actions/runs/39283258489')
    response.raise_for_status()
    data=response.json()
    result={key:data[key] for key in ['id','head_sha','status','conclusion','html_url','created_at','updated_at']}
    jobs=client.get('/repos/JacobHermsmeyer21/ML-Pipeline-Pro/actions/runs/39283258489/jobs',params={'per_page':100})
    jobs.raise_for_status()
    result['jobs']=[{key:j[key] for key in ['id','name','status','conclusion','started_at','completed_at','html_url']} for j in jobs.json()['jobs']]
    Path('artifacts/laptop-five-minute-validation/ci-current.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))
