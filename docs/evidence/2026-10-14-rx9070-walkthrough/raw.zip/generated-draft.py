import os
import httpx
with httpx.Client(base_url=os.environ['MLPP_API_ORIGIN'], headers={'X-Project-ID':os.environ['MLPP_PROJECT_ID'],'X-API-Key':os.environ['MLPP_API_KEY']}, timeout=10, follow_redirects=False, trust_env=False) as client:
    response = client.get('/api/v1/experiments', params={'limit': 50, 'offset': 0})
    response.raise_for_status()
    data = response.json()