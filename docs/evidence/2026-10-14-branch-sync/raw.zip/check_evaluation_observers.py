﻿import ast
import asyncio
import json
from pathlib import Path
import runpy
import sys
import time
from types import SimpleNamespace
sys.path.insert(0, str(Path.cwd()))
from ml_pipeline_pro import conversation_guidance as guidance
from ml_pipeline_pro.conversation_schemas import fingerprint
from ml_pipeline_pro.snippet_schemas import SnippetCandidate
from tests.test_conversation_guidance import inspection_messages
from tests.test_conversation_ollama import REPLY, Runtime, chat_response, settings

async def check():
    conversation = runpy.run_path('evaluations/test_conversation_model.py')
    snippet = runpy.run_path('evaluations/test_snippet_model.py')
    facts = [{'record_id': 'selected', 'field': 'metrics.validation_f1'}]
    def fixture():
        runtime = Runtime(chat_response(message={'role': 'assistant', 'content': json.dumps({'reply': {**REPLY, 'facts': facts}})}))
        runtime.tokens = 42
        return runtime
    runtime = fixture()
    counter = conversation['ObservedCounter'](runtime.count, protocol='guided')
    config = settings(chat_protocol='guided')
    async with runtime.model(config, count_input_tokens=counter) as native:
        wrapper = conversation['BudgetedModel'](native, counter, config, deadline=time.monotonic() + 600)
        await wrapper.generate(inspection_messages())
    observed = {}
    runtime = fixture()
    path = Path('evaluations/test_snippet_model.py')
    count = next(node for node in ast.walk(ast.parse(path.read_text(encoding='utf-8'))) if isinstance(node, ast.FunctionDef) and node.name == 'count')
    scope = {name: getattr(guidance, name) for name in ('guided_schema', 'current_evidence_ids', 'explicit_missing_inputs', 'inspection_target', 'draft_request', 'current_budgets', 'requested_facts')}
    scope.update(observed=observed, settings=config, counter=runtime.count, fingerprint=fingerprint, SnippetCandidate=SnippetCandidate, native_conversation_tools=snippet['native_conversation_tools'])
    exec(compile(ast.Module(body=[count], type_ignores=[]), str(path), 'exec'), scope)
    async with runtime.model(config, count_input_tokens=scope['count']) as native:
        wrapper = snippet['EvaluatedModel'](native, observed, config, time.monotonic() + 600)
        await wrapper.generate(inspection_messages())
    assert observed['required_facts'] == facts and observed['last_count'] == 42
    print('PASS: both evaluation wrappers admit the exact scripted SDK payload with requested-fact references after tool-message name removal; no live model invoked.')

asyncio.run(check())
