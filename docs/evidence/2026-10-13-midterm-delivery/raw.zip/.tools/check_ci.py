"""Read CI status using existing Git credentials without printing credentials."""

import json
import os
import subprocess
import sys
import urllib.error
import urllib.request

environment = dict(os.environ, GIT_TERMINAL_PROMPT="0", GCM_INTERACTIVE="Never")
result = subprocess.run(
    ["git", "credential", "fill"],
    input="protocol=https\nhost=github.com\npath=JacobHermsmeyer21/ML-Pipeline-Pro.git\n\n",
    text=True, capture_output=True, env=environment, timeout=20,
)
if result.returncode:
    print("Existing Git credentials are not available for a CI status check")
    sys.exit(1)
credential = dict(line.split("=", 1) for line in result.stdout.splitlines() if "=" in line)
token = credential.get("password")
if not token:
    print("Existing Git credentials did not supply an API credential")
    sys.exit(1)
path = sys.argv[1] if len(sys.argv) > 1 else "actions/runs?per_page=3"
request = urllib.request.Request(
    "https://api.github.com/repos/JacobHermsmeyer21/ML-Pipeline-Pro/" + path,
    headers={"Authorization": "Bearer " + token, "User-Agent": "ML-Pipeline-Pro-validation"},
)
try:
    with urllib.request.urlopen(request, timeout=20) as response:
        data = json.load(response)
except urllib.error.HTTPError as exc:
    print("CI status check returned HTTP", exc.code)
    sys.exit(1)
if "workflow_runs" in data:
    print(json.dumps([
        {key: run.get(key) for key in ("id", "head_sha", "status", "conclusion", "html_url")}
        for run in data["workflow_runs"]
    ], indent=2))
elif "jobs" in data:
    print(json.dumps([
        {"id": job["id"], "name": job["name"], "status": job["status"],
         "conclusion": job["conclusion"], "steps": [
             {key: step.get(key) for key in ("name", "status", "conclusion")}
             for step in job["steps"]
         ]}
        for job in data["jobs"]
    ], indent=2))
elif "head_sha" in data:
    print(json.dumps({key:data.get(key) for key in ('id','head_sha','status','conclusion','html_url')},indent=2))
