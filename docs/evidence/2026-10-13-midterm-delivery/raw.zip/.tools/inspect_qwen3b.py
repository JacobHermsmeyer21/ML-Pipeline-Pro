import hashlib
import json
from pathlib import Path

import httpx

out = Path('artifacts/midterm-validation/qwen3b')
out.mkdir(parents=True, exist_ok=True)
with httpx.Client(base_url='http://127.0.0.1:11434', trust_env=False, timeout=120) as client:
    shows = {}
    for tag, name in [('qwen2.5:3b-instruct-q4_K_M', '3b'), ('qwen2.5:7b-instruct-q4_K_M', '7b')]:
        response = client.post('/api/show', json={'model': tag, 'verbose': True})
        response.raise_for_status()
        shows[name] = response.json()
    info3, info7 = (shows[name]['model_info'] for name in ['3b', '7b'])
    tokenizer_keys = sorted(key for key in info3 if key.startswith('tokenizer.'))
    comparison = {key: {'equal': info3[key] == info7.get(key), 'sha256': hashlib.sha256(json.dumps(info3[key], ensure_ascii=False, sort_keys=True).encode()).hexdigest()} for key in tokenizer_keys}
    for key in ('tokenizer.ggml.tokens', 'tokenizer.ggml.token_type'):
        a, b = info3[key], info7[key]
        differing = [i for i in range(min(len(a), len(b))) if a[i] != b[i]]
        comparison[key].update({'length3b': len(a), 'length7b': len(b), 'differing_ids': differing[:20], 'shared_prefix_equal': not differing, 'extra3b': a[len(b):], 'extra7b': b[len(a):]})
    (out / 'tokenizer-comparison.json').write_text(json.dumps(comparison, indent=2), encoding='utf-8')
    print(json.dumps(comparison, indent=2))
    assert all(item['equal'] or item.get('shared_prefix_equal') for item in comparison.values()), comparison
    (out / 'tokenizer-comparison.json').write_text(json.dumps(comparison, indent=2), encoding='utf-8')
    show = shows['3b']
    (out / 'base-show.json').write_text(json.dumps({key: value for key, value in show.items() if key != 'model_info'} | {'model_info': {key: value for key, value in info3.items() if not isinstance(value, list)}}, indent=2), encoding='utf-8')
    (out / 'LICENSE.txt').write_text(show['license'], encoding='utf-8')
    template = Path('examples/qwen-json-tools.gotmpl').read_text(encoding='utf-8')
    target = 'mlpp-qwen2.5:3b-instruct-q4_K_M-json-tools-v1'
    response = client.post('/api/create', json={'model': target, 'from': 'qwen2.5:3b-instruct-q4_K_M', 'template': template, 'stream': False})
    response.raise_for_status()
    tags = client.get('/api/tags').json()['models']
    response = client.post('/api/show', json={'model': target})
    response.raise_for_status()
    custom = response.json()
    (out / 'custom-show.json').write_text(json.dumps(custom, indent=2), encoding='utf-8')
    result = {'runtime_version': client.get('/api/version').json()['version'], 'base': next(item for item in tags if item['name'] == 'qwen2.5:3b-instruct-q4_K_M'), 'profile': next(item for item in tags if item['name'] == target), 'template_hash': hashlib.sha256(json.dumps(custom['template'], ensure_ascii=False, separators=(',', ':')).encode()).hexdigest(), 'tokenizer_metadata_keys': tokenizer_keys, 'tokenizer_shared_prefix_equal_to_pinned_7b': True, 'license_sha256': hashlib.sha256(show['license'].encode()).hexdigest()}
    (out / 'identity.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(result, indent=2))
