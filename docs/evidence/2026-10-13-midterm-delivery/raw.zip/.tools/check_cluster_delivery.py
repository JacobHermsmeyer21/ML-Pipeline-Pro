import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

import httpx

out=Path('artifacts/midterm-validation/kubernetes-final')
k=['kubectl','--kubeconfig',str((out/'kubeconfig').resolve()),'--context','kind-mlpp-delivery-20261013','-n','mlpp-demo']
source={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('src/ml_pipeline_pro').glob('*.py')}
probe="import hashlib,json; from pathlib import Path; import ml_pipeline_pro; print(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in Path(ml_pipeline_pro.__file__).parent.glob('*.py')}))"
for name in ('model-api','tuning-api','monitoring-api','worker','scheduler'):
    with (out/('loaded-final-rollout-'+name+'.log')).open('w',encoding='utf-8') as log:
        subprocess.run([*k,'rollout','restart','deployment/'+name],stdout=log,stderr=subprocess.STDOUT,check=True)
        subprocess.run([*k,'rollout','status','deployment/'+name,'--timeout=180s'],stdout=log,stderr=subprocess.STDOUT,check=True)
    actual=json.loads(subprocess.check_output([*k,'exec','deployment/'+name,'--','python','-c',probe],text=True))
    assert actual==source,(name,[key for key in source if source[key]!=actual.get(key)])
(out/'final-source-verification.json').write_text(json.dumps({'revision':'2945bd2','source_hashes':source,'verified_roles':['model-api','tuning-api','monitoring-api','worker','scheduler']},indent=2),encoding='utf-8')
with (out/'delivery-forward.log').open('w',encoding='utf-8') as log:
    forward=subprocess.Popen([*k,'port-forward','service/gateway','18000:8000','--address','127.0.0.1'],stdout=log,stderr=subprocess.STDOUT)
    try:
        for _ in range(50):
            assert forward.poll() is None
            try:
                if httpx.get('http://127.0.0.1:18000/api/v1/health/ready',trust_env=False,timeout=1).is_success:break
            except httpx.HTTPError:pass
            time.sleep(.2)
        else:raise TimeoutError('gateway forward')
        with (out/'delivery-walkthrough.log').open('w',encoding='utf-8') as runlog:
            subprocess.run([sys.executable,'examples/midterm_walkthrough.py','--origin','http://127.0.0.1:18000','--confirm-demo-proposal','--output',str(out/'delivery-walkthrough')],stdout=runlog,stderr=subprocess.STDOUT,check=True)
        with (out/'delivery-replicas.log').open('w',encoding='utf-8') as runlog:
            subprocess.run([sys.executable,'scripts/check_api_replicas.py','--kubeconfig',str(out/'kubeconfig'),'--name','mlpp-delivery-20261013','--smoke',str(out/'delivery-walkthrough/backend.json'),'--output',str(out/'delivery-replicas')],stdout=runlog,stderr=subprocess.STDOUT,check=True)
    finally:
        forward.terminate()
        forward.wait(timeout=10)
print('Final source, actual local AI walkthrough, and forced replica replay passed.')
