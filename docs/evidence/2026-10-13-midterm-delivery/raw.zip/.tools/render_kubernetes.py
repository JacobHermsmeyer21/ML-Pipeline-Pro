import json
from pathlib import Path

root=Path.cwd()
namespace='mlpp-demo'
resources=[{'apiVersion':'v1','kind':'Namespace','metadata':{'name':namespace}}]

def resource(kind,name,spec=None,**other):
    result={'apiVersion':'apps/v1' if kind=='Deployment' else 'v1','kind':kind,
            'metadata':{'name':name,'namespace':namespace},**other}
    if spec is not None:result['spec']=spec
    resources.append(result)
    return result

resource('ConfigMap','mlpp-config',data={
    'MLPP_MONGODB_URI':'mongodb://mongo:27017/?directConnection=true',
    'MLPP_REDIS_URL':'redis://redis:6379/0','MLPP_ARTIFACT_ROOT':'/app/artifacts',
    'MLPP_DATASET_ROOT':'/app/examples/data','MLPP_CHAT_API_ORIGIN':'http://gateway:8000',
    'MLPP_CHAT_ENABLED':'false','MLPP_CHAT_PROTOCOL':'guided'})
resource('Secret','mlpp-project-access',type='Opaque',stringData={'MLPP_PROJECT_API_KEYS':'{}'})
gateway=(root/'deploy/gateway.conf').read_text().replace('127.0.0.11','kube-dns.kube-system.svc.cluster.local')
for name in ('model-api','tuning-api','monitoring-api'):
    gateway=gateway.replace(f'http://{name}:8000',f'http://{name}.{namespace}.svc.cluster.local:8000')
resource('ConfigMap','gateway-config',data={'nginx.conf':gateway})
resource('ConfigMap','prometheus-config',data={'prometheus.yaml':(root/'deploy/monitoring/prometheus.yaml').read_text(),
    'alerts.yaml':(root/'deploy/monitoring/alerts.yaml').read_text()})
resource('ConfigMap','grafana-config',data={
    'datasource.yaml':(root/'deploy/monitoring/grafana/datasources/prometheus.yaml').read_text(),
    'provider.yaml':(root/'deploy/monitoring/grafana/dashboards/provider.yaml').read_text(),
    'workload.json':(root/'deploy/monitoring/grafana/dashboards/workload.json').read_text()})
for name,size in (('artifacts','1Gi'),('mongo-data','1Gi'),('redis-data','256Mi')):
    resource('PersistentVolumeClaim',name,{'accessModes':['ReadWriteOnce'],
        'resources':{'requests':{'storage':size}}})

def deployment(name,image,command=None,port=None,*,app=False,replicas=1,memory='512Mi',cpu='500m',request_cpu='50m',mounts=None,volumes=None):
    container={'name':name,'image':image,'imagePullPolicy':'IfNotPresent',
        'resources':{'requests':{'memory':'128Mi','cpu':request_cpu},'limits':{'memory':memory,'cpu':cpu}}}
    if command:container['command']=command
    if port:container['ports']=[{'containerPort':port}]
    if mounts:container['volumeMounts']=mounts
    if app:
        container['envFrom']=[{'configMapRef':{'name':'mlpp-config'}},{'secretRef':{'name':'mlpp-project-access'}}]
        container.setdefault('volumeMounts',[]).append({'name':'artifacts','mountPath':'/app/artifacts'})
        volumes=[*(volumes or []),{'name':'artifacts','persistentVolumeClaim':{'claimName':'artifacts'}}]
    pod={'containers':[container]}
    if volumes:pod['volumes']=volumes
    if app:pod['securityContext']={'runAsNonRoot':True,'runAsUser':10001,'fsGroup':10001}
    if port==8000:
        container['readinessProbe']={'httpGet':{'path':'/api/v1/health/ready','port':port},'periodSeconds':5,'timeoutSeconds':5}
        container['livenessProbe']={'httpGet':{'path':'/api/v1/health/live','port':port},'periodSeconds':10,'timeoutSeconds':5}
        container['startupProbe']={'httpGet':{'path':'/api/v1/health/live','port':port},'periodSeconds':2,'failureThreshold':60}
    elif port:
        container['readinessProbe']={'tcpSocket':{'port':port},'periodSeconds':5}
    spec={'replicas':replicas,'selector':{'matchLabels':{'app':name}},
          'template':{'metadata':{'labels':{'app':name}},'spec':pod}}
    if name in {'mongo','redis','worker','scheduler'}:spec['strategy']={'type':'Recreate'}
    resource('Deployment',name,spec)
    if port:
        service=resource('Service',name,{'selector':{'app':name},'ports':[{'port':port,'targetPort':port}]})
        if name=='mongo':
            service['spec'].update(clusterIP='None',publishNotReadyAddresses=True)
    return container

mongo=deployment('mongo','mongo:8.0',['mongod','--replSet','mlpp','--bind_ip_all'],27017,memory='768Mi',
    mounts=[{'name':'data','mountPath':'/data/db'}],volumes=[{'name':'data','persistentVolumeClaim':{'claimName':'mongo-data'}}])
mongo['readinessProbe']={'exec':{'command':['mongosh','--quiet','--eval',
    "try { rs.status(); } catch (e) { if (e.code !== 94) throw e; rs.initiate({_id: 'mlpp', members: [{_id: 0, host: 'mongo:27017'}]}); } quit(db.hello().isWritablePrimary ? 0 : 1)"]},'periodSeconds':5,'timeoutSeconds':5}
mongo['startupProbe']={**mongo['readinessProbe'],'failureThreshold':12}
deployment('redis','redis:7.4-alpine',['redis-server','--appendonly','yes'],6379,memory='128Mi',
    mounts=[{'name':'data','mountPath':'/data'}],volumes=[{'name':'data','persistentVolumeClaim':{'claimName':'redis-data'}}])
for name,factory in (('model-api','create_model_app'),('tuning-api','create_tuning_app'),('monitoring-api','create_monitoring_app')):
    deployment(name,'ml-pipeline-pro:midterm',['uvicorn',f'ml_pipeline_pro.main:{factory}','--factory','--host','0.0.0.0','--port','8000','--no-access-log'],8000,app=True,replicas=2 if name=='model-api' else 1)
deployment('worker','ml-pipeline-pro:midterm',['celery','-A','ml_pipeline_pro.worker:app','worker','--loglevel=INFO','--concurrency=1','--queues=training,celery'],app=True,memory='1Gi',cpu='1',request_cpu='100m')
deployment('scheduler','ml-pipeline-pro:midterm',['celery','-A','ml_pipeline_pro.worker:app','beat','--loglevel=INFO','--schedule=/tmp/mlpp-celerybeat'],app=True,memory='256Mi')
deployment('gateway','nginx:1.28-alpine',port=8000,memory='128Mi',mounts=[{'name':'config','mountPath':'/etc/nginx/nginx.conf','subPath':'nginx.conf'}],volumes=[{'name':'config','configMap':{'name':'gateway-config'}}])
deployment('prometheus','prom/prometheus:v3.5.0',['/bin/prometheus','--config.file=/etc/prometheus/prometheus.yaml','--storage.tsdb.retention.time=1d'],9090,
    mounts=[{'name':'config','mountPath':'/etc/prometheus'}],volumes=[{'name':'config','configMap':{'name':'prometheus-config'}}])
grafana=deployment('grafana','grafana/grafana:12.1.1',port=3000,
    mounts=[{'name':'config','mountPath':'/etc/grafana/provisioning/datasources/prometheus.yaml','subPath':'datasource.yaml'},
            {'name':'config','mountPath':'/etc/grafana/provisioning/dashboards/provider.yaml','subPath':'provider.yaml'},
            {'name':'config','mountPath':'/etc/grafana/provisioning/dashboards/workload.json','subPath':'workload.json'}],
    volumes=[{'name':'config','configMap':{'name':'grafana-config'}}])
grafana['env']=[{'name':'GF_AUTH_ANONYMOUS_ENABLED','value':'true'},
    {'name':'GF_AUTH_ANONYMOUS_ORG_ROLE','value':'Viewer'},{'name':'GF_AUTH_DISABLE_LOGIN_FORM','value':'true'}]
out=root/'deploy/kubernetes/stack.json'
out.parent.mkdir(parents=True,exist_ok=True)
out.write_text(json.dumps({'apiVersion':'v1','kind':'List','items':resources},indent=2)+'\n')
print('Generated single-node demo manifest with two model APIs and one serial worker.')
