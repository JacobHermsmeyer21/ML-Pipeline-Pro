import asyncio
import json
from pathlib import Path

from ml_pipeline_pro.config import Settings
from ml_pipeline_pro.connections import open_connections


async def main():
    demo=json.loads(Path('artifacts/midterm-validation/monitoring-smoke.json').read_text())
    async with open_connections(Settings(_env_file=None)) as connections:
        database=connections.mongo.get_database('ml_pipeline_pro')
        specs=[('models',{'project_id':'demo'}),
               ('experiments',{'project_id':'demo','model_id':demo['model']['id']}),
               ('model_versions',{'project_id':'demo','model_id':demo['model']['id']}),
               ('tuning_jobs',{'project_id':'demo'}),
               ('trials',{'project_id':'demo','tuning_job_id':demo['tuning']['id']})]
        results=[]
        for collection,query in specs:
            observed=await database.command({'explain':{'find':collection,'filter':query,
                'sort':{'created_at':-1,'_id':-1},'limit':50},'verbosity':'executionStats'})
            results.append({'collection':collection,'query':query,
                            'project_records':await database[collection].count_documents({'project_id':'demo'}),
                            'raw_explain':observed})
        Path('artifacts/midterm-validation/queryplans.json').write_text(json.dumps(results,default=str,indent=2)+'\n')
        print([(value['collection'],value['raw_explain']['executionStats']['nReturned'],
                value['raw_explain']['executionStats']['totalDocsExamined']) for value in results])

asyncio.run(main())
