import json
import subprocess
import sys
import time
from pathlib import Path
import httpx

out=Path('artifacts/midterm-validation/kubernetes-cpu-final')
out.mkdir(exist_ok=True)
config=Path('artifacts/midterm-validation/kubernetes-final/kubeconfig').resolve()
k=['kubectl','--kubeconfig',str(config),'--context','kind-mlpp-delivery-20261013']
manifest=json.loads(Path('deploy/kubernetes/stack.json').read_text())
total=0
roles=[]
for item in manifest['items']:
    if item['kind']!='Deployment':continue
    roles.append(item['metadata']['name'])
    for c in item['spec']['template']['spec']['containers']:
        total+=int(c['resources']['requests']['cpu'].removesuffix('m'))*item['spec']['replicas']
assert total==600,total
def command(parts,name):
    with (out/(name+'.log')).open('w',encoding='utf-8') as log:
        subprocess.run(parts,stdout=log,stderr=subprocess.STDOUT,check=True)
command([*k,'apply','-f','deploy/kubernetes/stack.json'],'apply')
for name in roles:
    command([*k,'-n','mlpp-demo','rollout','status','deployment/'+name,'--timeout=180s'],'rollout-'+name)
command([*k,'get','nodes','-o','json'],'nodes')
command([*k,'-n','mlpp-demo','get','pods','-o','json'],'pods')
with (out/'forward.log').open('w',encoding='utf-8') as log:
    forward=subprocess.Popen([*k,'-n','mlpp-demo','port-forward','service/gateway','18000:8000','--address','127.0.0.1'],stdout=log,stderr=subprocess.STDOUT)
    try:
        for i in range(50):
            assert forward.poll() is None
            try:
                if httpx.get('http://127.0.0.1:18000/api/v1/health/ready',trust_env=False,timeout=1).is_success:break
            except httpx.HTTPError:pass
            time.sleep(.2)
        else:raise TimeoutError('Gateway unavailable')
        command([sys.executable,'scripts/deployment_smoke.py','--origin','http://127.0.0.1:18000','--output',str(out/'smoke.json')],'smoke')
        command([sys.executable,'scripts/check_api_replicas.py','--kubeconfig',str(config),'--name','mlpp-delivery-20261013','--smoke',str(out/'smoke.json'),'--output',str(out/'replicas')],'replicas')
    finally:
        forward.terminate()
        forward.wait(timeout=10)
(out/'results.json').write_text(json.dumps({'requested_cpu_millicores':total,'all_deployments_ready':True,'three_trial_smoke':'passed','forced_replica_replay':'passed'},indent=2),encoding='utf-8')
print('600m request budget; all services ready; actual three-trial smoke and forced replica replay passed.')
