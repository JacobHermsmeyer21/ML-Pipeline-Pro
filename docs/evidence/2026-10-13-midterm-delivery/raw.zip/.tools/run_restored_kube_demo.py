import json
import subprocess
import sys
import time
from pathlib import Path
import httpx

base=Path('artifacts/midterm-validation/kubernetes-final')
k=['kubectl','--kubeconfig',str((base/'kubeconfig').resolve()),'--context','kind-mlpp-delivery-20261013','-n','mlpp-demo']
with (base/'restored-forward.log').open('w',encoding='utf-8') as log:
    forward=subprocess.Popen([*k,'port-forward','service/gateway','18000:8000','--address','127.0.0.1'],stdout=log,stderr=subprocess.STDOUT)
    try:
        for i in range(50):
            assert forward.poll() is None
            try:
                r=httpx.get('http://127.0.0.1:18000/api/v1/datasets',headers={'X-Project-ID':'demo'},trust_env=False,timeout=2)
                if r.is_success:break
            except httpx.HTTPError:pass
            time.sleep(.2)
        else:raise TimeoutError('Restored metadata read unavailable')
        with (base/'restored-walkthrough.log').open('w',encoding='utf-8') as runlog:
            subprocess.run([sys.executable,'examples/midterm_walkthrough.py','--origin','http://127.0.0.1:18000','--confirm-demo-proposal','--output',str(base/'restored-walkthrough')],stdout=runlog,stderr=subprocess.STDOUT,check=True)
        with (base/'restored-replicas.log').open('w',encoding='utf-8') as runlog:
            subprocess.run([sys.executable,'scripts/check_api_replicas.py','--kubeconfig',str(base/'kubeconfig'),'--name','mlpp-delivery-20261013','--smoke',str(base/'restored-walkthrough/backend.json'),'--output',str(base/'restored-replicas')],stdout=runlog,stderr=subprocess.STDOUT,check=True)
        pods=subprocess.check_output([*k,'get','pods','-o','json'],text=True)
        (base/'restored-pods.json').write_text(pods,encoding='utf-8')
    finally:
        forward.terminate()
        forward.wait(timeout=10)
print('Restored Kubernetes full local-AI demo and two-pod replay passed.')
