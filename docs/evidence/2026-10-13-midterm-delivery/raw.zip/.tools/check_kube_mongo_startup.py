import json
import subprocess
import time
from pathlib import Path

base=Path('artifacts/midterm-validation/kubernetes-final')
out=base/'mongo-startup-recovery-2'
out.mkdir(exist_ok=True)
k=['kubectl','--kubeconfig',str((base/'kubeconfig').resolve()),'--context','kind-mlpp-delivery-20261013']
def run(args,name,*,check=True):
    r=subprocess.run([*k,*args],text=True,capture_output=True,timeout=210)
    (out/(name+'.log')).write_text(r.stdout+r.stderr,encoding='utf-8')
    if check:r.check_returncode()
    return r
def mongo_json(expression,name,*,check=True):
    return run(['-n','mlpp-demo','exec','deployment/mongo','--','mongosh','--quiet','--eval','JSON.stringify('+expression+')'],name,check=check)
snapshot="{writable:db.hello().isWritablePrimary,config_version:rs.conf().version,dataset_ids:db.getSiblingDB('ml_pipeline_pro').datasets.find({}, {_id:1}).toArray().map(x=>x._id).sort()}"
manifest=json.loads(Path('deploy/kubernetes/stack.json').read_text())
mongo=next(item for item in manifest['items'] if item['kind']=='Deployment' and item['metadata']['name']=='mongo')
path=out/'mongo.json'
path.write_text(json.dumps(mongo,indent=2),encoding='utf-8')
run(['apply','-f',str(path)],'apply')
run(['-n','mlpp-demo','rollout','status','deployment/mongo','--timeout=180s'],'initial-rollout')
before=json.loads(mongo_json(snapshot,'before').stdout)
assert before['writable'] and before['dataset_ids'],before
dns=json.loads(run(['-n','kube-system','get','deployment/coredns','-o','json'],'dns-before').stdout)
replicas=dns['spec']['replicas']
assert replicas>0
failure=None
try:
    run(['-n','kube-system','scale','deployment/coredns','--replicas=0'],'dns-stop')
    for i in range(100):
        pods=json.loads(run(['-n','kube-system','get','pods','-l','k8s-app=kube-dns','-o','json'],'dns-pods').stdout)
        if not pods['items']:break
        time.sleep(.2)
    else:raise TimeoutError('CoreDNS did not stop')
    run(['-n','mlpp-demo','rollout','restart','deployment/mongo'],'mongo-restart-without-dns')
    for i in range(40):
        r=mongo_json('db.hello()','unhealthy-hello',check=False)
        if r.returncode==0:
            failure=json.loads(r.stdout)
            if not failure.get('isWritablePrimary') and 'valid replica set config' in failure.get('info',''):
                break
        time.sleep(.5)
    else:raise AssertionError('Expected startup membership failure was not observed')
    # Keep the fault present through the configured startup allowance. A brief
    # DNS outage recovered before the probe fired in the retained first attempt.
    for i in range(180):
        status=json.loads(run(['-n','mlpp-demo','get','pods','-l','app=mongo','-o','json'],'fault-pods').stdout)
        counts=[item.get('restartCount',0) for pod in status['items'] for item in pod['status'].get('containerStatuses',[])]
        if counts and max(counts)>=1:break
        time.sleep(1)
    else:raise AssertionError('Startup probe did not restart the failed process')
finally:
    run(['-n','kube-system','scale','deployment/coredns',f'--replicas={replicas}'],'dns-restore')
    run(['-n','kube-system','rollout','status','deployment/coredns','--timeout=180s'],'dns-restored')
run(['-n','mlpp-demo','rollout','status','deployment/mongo','--timeout=180s'],'recovered-rollout')
after=json.loads(mongo_json(snapshot,'after').stdout)
pods=json.loads(run(['-n','mlpp-demo','get','pods','-l','app=mongo','-o','json'],'recovered-pods').stdout)
restart=pods['items'][0]['status']['containerStatuses'][0]['restartCount']
assert after==before,(before,after)
assert restart>=1,restart
result={'before':before,'unhealthy_hello':failure,'after':after,'automatic_process_restarts':restart,'restored_dns_replicas':replicas,'forced_reconfiguration':False,'data_deleted':False}
(out/'results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print('Observed DNS startup failure; startup probe restarted MongoDB into writable primary; saved records/config preserved.')
