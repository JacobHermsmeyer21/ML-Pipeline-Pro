import os
import subprocess
import sys
import urllib.error
import urllib.request
from pathlib import Path

cred=subprocess.run(['git','credential','fill'],input='protocol=https\nhost=github.com\npath=JacobHermsmeyer21/ML-Pipeline-Pro.git\n\n',text=True,capture_output=True,check=True,env=dict(os.environ,GIT_TERMINAL_PROMPT='0',GCM_INTERACTIVE='Never'))
token=dict(line.split('=',1) for line in cred.stdout.splitlines() if '=' in line)['password']
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):return None
path=('artifacts/'+sys.argv[1].removeprefix('artifact:')+'/zip') if sys.argv[1].startswith('artifact:') else ('jobs/'+sys.argv[1]+'/logs')
url='https://api.github.com/repos/JacobHermsmeyer21/ML-Pipeline-Pro/actions/'+path
request=urllib.request.Request(url,headers={'Authorization':'Bearer '+token,'User-Agent':'MLPP-CI-verification'})
try:
    response=urllib.request.build_opener(NoRedirect()).open(request,timeout=30)
except urllib.error.HTTPError as error:
    if error.code not in (301,302,303,307):raise RuntimeError('CI logs HTTP '+str(error.code)) from None
    # Signed storage URL is private transport metadata. Do not print/save it or forward credentials.
    location=error.headers['Location']
    if not location.startswith('https://'):raise RuntimeError('Unexpected log redirect')
    response=urllib.request.urlopen(urllib.request.Request(location,headers={'User-Agent':'MLPP-CI-verification'}),timeout=30)
with response:
    data=response.read(10*1024*1024+1)
if len(data)>10*1024*1024:raise RuntimeError('CI log cap exceeded')
Path(sys.argv[2]).write_bytes(data)
print('Saved CI job log; no transport credentials included.')
