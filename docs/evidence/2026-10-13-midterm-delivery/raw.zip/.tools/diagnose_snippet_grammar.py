import asyncio
import json
import time
from pathlib import Path
from unittest.mock import patch

from ml_pipeline_pro.config import Settings
from ml_pipeline_pro.conversation_ollama import OllamaConversationModel
from ml_pipeline_pro.conversation_qwen_counter import QwenInputCounter
from ml_pipeline_pro.snippet_generation import snippet_messages
from ml_pipeline_pro.snippet_schemas import SnippetCandidate, SnippetRequest
from ml_pipeline_pro.snippet_validation import validate_snippet

async def main():
    settings=Settings(_env_file=None,chat_model='mlpp-qwen2.5:7b-instruct-q4_K_M-json-tools-v1',
                      chat_protocol='guided',chat_model_timeout_seconds=60)
    counter=None
    payloads=[]
    def count(payload):
        payloads.append(payload)
        return counter(payload)
    request=SnippetRequest(profile='create_tuning_job',inputs={'dataset_id':'dataset','model_id':'model',
        'config':{'max_runtime_seconds':10},'objective_metric':'validation_f1',
        'limits':{'max_trials':2,'max_runtime_seconds':40}}).normalized()
    original=SnippetCandidate.model_json_schema
    def schema():
        result=original()
        result['properties']['code'].pop('maxLength',None)
        return result
    async with OllamaConversationModel(settings,count_input_tokens=count) as model:
        counter=QwenInputCounter(model.provenance,Path('.tools/local-model-setup/tokenizer.json'))
        with patch.object(SnippetCandidate,'model_json_schema',side_effect=schema):
            started=time.monotonic()
            step=await model.generate_snippet(snippet_messages(request,'Generate Python tuning draft'))
            duration=time.monotonic()-started
            issues=validate_snippet(step.snippet.code,request)
            result={'diagnostic_only':True,'timeout_seconds':60,'decoder_maxLength_removed':True,
                    'duration_seconds':duration,'usage':step.usage,'host_validation_issues':issues,
                    'step':step.model_dump(mode='json'),'payloads':payloads}
            Path('artifacts/midterm-validation/grammar-diagnostic.json').write_text(json.dumps(result,indent=2)+'\n')
            print(json.dumps({key:result[key] for key in ['duration_seconds','usage','host_validation_issues']}))
asyncio.run(main())
