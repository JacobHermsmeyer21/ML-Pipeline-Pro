import subprocess
import sys
from pathlib import Path
out=Path(sys.argv[1])
out.write_text(subprocess.check_output([sys.executable,'.tools/check_ci.py',*sys.argv[2:]],text=True),encoding='utf-8')
print('Saved safe CI status metadata to',out)
