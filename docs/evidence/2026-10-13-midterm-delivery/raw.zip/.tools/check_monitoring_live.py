import json
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path

import httpx

demo=json.loads(Path('artifacts/midterm-validation/monitoring-smoke.json').read_text())
with httpx.Client(base_url='http://127.0.0.1:8000',headers={'X-Project-ID':'demo'},timeout=30,trust_env=False) as client:
    response=client.post(f"/api/v1/models/{demo['model']['id']}/versions",json={
        'version':'measured-'+str(int(time.time())), 'experiment_id':demo['training']['id']})
    response.raise_for_status()
    version=response.json()
    subprocess.run([sys.executable,'examples/monitor_workload.py','--model-id',demo['model']['id'],
                    '--version-id',version['id'],'--output','artifacts/midterm-validation/monitoring-measured-workload.json'],check=True)
    workload=json.loads(Path('artifacts/midterm-validation/monitoring-measured-workload.json').read_text())
    accepted=datetime.fromisoformat(workload['observations'][-1]['created_at'])
    query='mlpp_workload_latency_issue{model_version_id="'+version['id']+'"}'
    queries=[]
    for index in range(31):
        query_response=httpx.get('http://127.0.0.1:9090/api/v1/query',params={'query':query},timeout=10)
        query_response.raise_for_status()
        queries.append({'at':datetime.now(UTC).isoformat(),'response':query_response.json()})
        series=query_response.json()['data']['result']
        if series and float(series[0]['value'][1])==1:
            delay=(datetime.now(UTC)-accepted).total_seconds()
            break
        time.sleep(1)
    else:raise AssertionError('No observed Prometheus issue within target')
    assert delay<=30
    summary=client.get(f"/api/v1/monitoring/model-versions/{version['id']}/summary").json()
    assert summary['sample_count']==20 and summary['seeded_count']==5
    grafana=httpx.get('http://127.0.0.1:3000/api/dashboards/uid/mlpp-midterm',timeout=10)
    grafana.raise_for_status()
    assert grafana.json()['dashboard']['refresh']=='15s'
    proxy=httpx.get('http://127.0.0.1:3000/api/datasources/proxy/uid/mlpp-prometheus/api/v1/query',
                    params={'query':query},timeout=10)
    proxy.raise_for_status()
    assert proxy.json()['data']['result']
    advice=httpx.post(f"http://127.0.0.1:8002/api/v1/monitoring/model-versions/{version['id']}/diagnosis",
                     headers={'X-Project-ID':'demo'},timeout=60)
    Path('artifacts/midterm-validation/monitoring-live-progress.json').write_text(json.dumps({
        'version':version,'summary':summary,'prometheus_queries':queries,
        'visibility_seconds_after_accepted_sample':delay,'grafana_dashboard':grafana.json(),
        'grafana_query':proxy.json(),'diagnosis_status':advice.status_code,'diagnosis':advice.json()},indent=2)+'\n')
    advice.raise_for_status()
    diagnosis=advice.json()
    assert set(diagnosis['generated_advice']['observation_ids'])<=set(summary['observation_ids'])
    assert 'inspect_seeded_delay' in diagnosis['generated_advice']['proposed_checks']
    result={'version':version,'summary':summary,'prometheus_queries':queries,
            'visibility_seconds_after_accepted_sample':delay,'target_seconds':30,
            'grafana_dashboard':grafana.json(),'grafana_query':proxy.json(),'diagnosis':diagnosis,
            'actual_inferences':20,'declared_seeded_inferences':5,'automatic_changes':False}
    Path('artifacts/midterm-validation/monitoring-live.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'visibility_seconds':delay,'interpretation':diagnosis['generated_advice']['interpretation'],
                      'checks':diagnosis['generated_advice']['proposed_checks'],'usage':diagnosis['model_provenance']},indent=2))
