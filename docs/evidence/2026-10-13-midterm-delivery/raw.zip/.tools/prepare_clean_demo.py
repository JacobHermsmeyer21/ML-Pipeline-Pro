import hashlib
import shutil
from pathlib import Path
root=Path.cwd()
clean=root/'.tools/midterm-clean'
source=root/'.tools/local-model-setup/tokenizer.json'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='c0382117ea329cdf097041132f6d735924b697924d6f6fc3945713e96ce87539'
target=clean/'.tools/local-model-setup/tokenizer.json'
target.parent.mkdir(parents=True,exist_ok=True)
shutil.copyfile(source,target)
(clean/'artifacts').mkdir(exist_ok=True)
overlay='services:\n'
for name,port in [('api','18010:8000'),('mongo','27027:27017'),('redis','6381:6379'),('prometheus','19090:9090'),('grafana','13010:3000')]:
    overlay+=f'  {name}:\n    ports: !override ["127.0.0.1:{port}"]\n'
for name in ('model-api','tuning-api','monitoring-api','worker','scheduler'):
    overlay+=f'  {name}:\n    image: ml-pipeline-pro:clean-midterm\n'
(clean/'artifacts/clean-ports.yaml').write_text(overlay,encoding='utf-8')
print('Verified external tokenizer and isolated demo ports prepared; no .env copied.')
