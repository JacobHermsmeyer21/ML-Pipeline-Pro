import json
import subprocess
from pathlib import Path

out = Path('artifacts/midterm-validation/kubernetes-final')
k = ['kubectl', '--kubeconfig', str((out / 'kubeconfig').resolve()), '--context', 'kind-mlpp-delivery-20261013', '-n', 'mlpp-demo']
def run(args, name):
    with (out / (name + '.log')).open('w', encoding='utf-8') as log:
        subprocess.run(args, stdout=log, stderr=subprocess.STDOUT, check=True)

run(['docker', 'exec', 'mlpp-delivery-20261013-control-plane', 'mkdir', '-p', '/mlpp-local'], 'tokenizer-dir')
run(['docker', 'cp', '.tools/local-model-setup/tokenizer.json', 'mlpp-delivery-20261013-control-plane:/mlpp-local/tokenizer.json'], 'tokenizer-copy')
run([*k, 'apply', '-f', 'deploy/kubernetes/ollama-local.json'], 'ollama-service')
for name in ('model-api', 'tuning-api', 'monitoring-api', 'worker', 'scheduler'):
    run([*k, 'rollout', 'restart', 'deployment/' + name], 'final-restart-' + name)
    run([*k, 'rollout', 'status', 'deployment/' + name, '--timeout=180s'], 'final-rollout-' + name)
for name in ('model-api', 'monitoring-api'):
    path = out / (name + '-ai.json')
    path.write_text(Path('deploy/kubernetes/local-ai-patch.json').read_text().replace('DOMAIN_NAME', name), encoding='utf-8')
    run([*k, 'patch', 'deployment', name, '--type', 'strategic', '--patch-file', str(path)], 'ai-patch-' + name)
    run([*k, 'rollout', 'status', 'deployment/' + name, '--timeout=180s'], 'ai-rollout-' + name)
run([*k, 'get', 'pods', '-o', 'json'], 'final-pods')
run([*k, 'exec', 'deployment/model-api', '--', 'python', '-c', "import httpx; r=httpx.get('http://ollama.mlpp-demo.svc.cluster.local:11434/api/version',trust_env=False,timeout=10); r.raise_for_status(); assert r.json()['version']=='0.40.2'; print(r.text)"], 'ai-runtime')
print('Final image rollout and optional local runtime connection passed.')
