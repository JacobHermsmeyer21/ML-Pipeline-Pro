"""All-nine midterm workflow; local model inference and reviewable outputs, no code execution."""

import argparse
import json
import os
import subprocess
import sys
import time
from contextlib import ExitStack
from pathlib import Path

import httpx

from ml_pipeline_pro.conversation_timing import DIAGNOSTIC_PROFILE, PROFILE_NAMES, timing_profile


def timed_ai_post(client, path, *, profile, result, output, **kwargs):
    """Retain failed attempts too; a late success cannot pass the response criterion."""
    item = {"path": path, "origin": str(client.base_url)}
    result.setdefault("ai_requests", []).append(item)
    started = time.monotonic()
    try:
        response = client.post(path, timeout=profile.client_seconds, **kwargs)
        item["status_code"] = response.status_code
        item["response"] = response.json()
        response.raise_for_status()
        if profile.client_seconds is not None:
            assert time.monotonic() - started <= profile.client_seconds, (
                "Complete reply exceeded timing profile"
            )
        return response
    except Exception as exc:
        item["failure_type"] = type(exc).__name__
        raise
    finally:
        item["elapsed_seconds"] = time.monotonic() - started
        output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--origin", default="http://127.0.0.1:8000")
    parser.add_argument("--project", default="demo")
    parser.add_argument("--timing-profile", choices=PROFILE_NAMES, default="default")
    parser.add_argument("--diagnostic-model-api-origin")
    parser.add_argument("--diagnostic-monitoring-api-origin")
    parser.add_argument("--output", type=Path, default=Path("artifacts/midterm-walkthrough"))
    parser.add_argument(
        "--confirm-demo-proposal",
        action="store_true",
        help="Explicitly approve this bounded test proposal; Python remains unexecuted",
    )
    args = parser.parse_args()
    profile = timing_profile(args.timing_profile)
    diagnostic = profile.name == DIAGNOSTIC_PROFILE
    origins = (args.diagnostic_model_api_origin, args.diagnostic_monitoring_api_origin)
    if diagnostic and not all(origins):
        parser.error("Unbounded diagnostics require both explicit direct AI API origins")
    if not diagnostic and any(origins):
        parser.error("Direct diagnostic origins require laptop-unbounded-diagnostic")
    args.output.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        [
            sys.executable,
            "scripts/deployment_smoke.py",
            "--origin",
            args.origin,
            "--project",
            args.project,
            "--output",
            str(args.output / "backend.json"),
        ],
        check=True,
    )
    backend = json.loads((args.output / "backend.json").read_text())
    headers = {"X-Project-ID": args.project}
    if key := os.getenv("MLPP_API_KEY"):
        headers["X-API-Key"] = key
    result = {
        "backend": backend,
        "code_execution": False,
        "dialogue": [],
        "timing_profile": profile.name,
        "complete_reply_seconds": profile.client_seconds,
        "result_kind": "unbounded_diagnostic_observation" if diagnostic else "bounded_walkthrough",
        "bounded_profile_acceptance": False if diagnostic else None,
    }
    with ExitStack() as stack:
        client = stack.enter_context(
            httpx.Client(
                base_url=args.origin,
                headers=headers,
                timeout=90,
                trust_env=False,
                follow_redirects=False,
            )
        )
        ai_client = (
            stack.enter_context(
                httpx.Client(
                    base_url=origins[0],
                    headers=headers,
                    timeout=None,
                    trust_env=False,
                    follow_redirects=False,
                )
            )
            if diagnostic
            else client
        )

        def chat(request_id, message, previous=None):
            body = {
                "request_id": backend["training"]["id"] + "-" + request_id,
                "message": message,
                "expected_revision": previous["revision"] if previous else 0,
            }
            if previous:
                body["conversation_id"] = previous["conversation_id"]
            response = timed_ai_post(
                ai_client,
                "/api/v1/chat",
                json=body,
                profile=profile,
                result=result,
                output=args.output / "results.json",
            )
            response.raise_for_status()
            turn = response.json()
            result["dialogue"].append(turn)
            (args.output / "results.json").write_text(json.dumps(result, indent=2) + "\n")
            return turn, body

        inspection, _ = chat(
            "inspect",
            f"Inspect experiment {backend['training']['id']}. Return a verified "
            "metrics.validation_f1 fact and guide my next pipeline step in one sentence.",
        )
        assert inspection["status"] == "completed" and inspection["facts"], (
            f"AI inspection must complete with verified facts; got status={inspection['status']}, "
            f"error={inspection.get('error')}. Saved response: {args.output / 'results.json'}"
        )
        assert any(fact["record_id"] == backend["training"]["id"] for fact in inspection["facts"])
        prompt = (
            f"Compare {backend['training']['id']} and {backend['tuning']['best_experiment_id']} "
            "by validation_f1, then propose tuning "
            f"dataset {backend['dataset']['id']} with model {backend['model']['id']}. "
            "Use validation history to guide your proposal. Per-trial runtime is 10 seconds, "
            "objective validation_f1, maximum 2 trials and 40 seconds total. Do not submit it."
        )
        tuning, body = chat("suggest", prompt, inspection)
        action = tuning["pending_action"]
        assert tuning["status"] == "awaiting_confirmation" and action is not None
        assert action["status"] == "pending_confirmation"
        assert action["tool"]["name"] == "create_tuning_job"
        arguments = action["tool"]["arguments"]
        assert arguments["dataset_id"] == backend["dataset"]["id"]
        assert arguments["model_id"] == backend["model"]["id"]
        assert arguments["config"]["max_runtime_seconds"] == 10
        assert arguments["limits"]["max_trials"] == 2
        assert arguments["limits"]["max_runtime_seconds"] == 40
        assert arguments["objective_metric"] == "validation_f1"
        assert any(item["status"] == "succeeded" for item in tuning["tool_results"])
        replay = timed_ai_post(
            ai_client,
            "/api/v1/chat",
            json=body,
            profile=profile,
            result=result,
            output=args.output / "results.json",
        )
        replay.raise_for_status()
        assert replay.json() == tuning
        result["saved_proposal_replay_equal"] = True
        decision_path = (
            f"/api/v1/conversations/{tuning['conversation_id']}/actions/"
            f"{action['action_id']}/decision"
        )
        decision = client.post(
            decision_path,
            json={
                "decision": "approve" if args.confirm_demo_proposal else "reject",
                "arguments_hash": action["arguments_hash"],
            },
        )
        decision.raise_for_status()
        result["explicit_test_decision"] = decision.json()
        if args.confirm_demo_proposal:
            domain_id = decision.json()["outcome"]["data"]["id"]
            deadline = time.monotonic() + 90
            while time.monotonic() < deadline:
                job = client.get("/api/v1/tuning-jobs/" + domain_id).json()
                if job["status"] in {"succeeded", "failed", "cancelled"}:
                    assert job["status"] == "succeeded"
                    result["confirmed_tuning"] = job
                    break
                time.sleep(1)
            else:
                raise TimeoutError("Confirmed test tuning did not finish")
        draft, draft_body = chat(
            "python", "Generate Python listing experiments, limit 50, offset 0. Do not execute."
        )
        assert draft["snippet"]["status"] == "validated" and draft["snippet"]["review_required"]
        assert (
            timed_ai_post(
                ai_client,
                "/api/v1/chat",
                json=draft_body,
                profile=profile,
                result=result,
                output=args.output / "results.json",
            ).json()
            == draft
        )
        result["draft_replay_equal"] = True
        result["history"] = client.get("/api/v1/conversations/" + tuning["conversation_id"]).json()
    subprocess.run(
        [
            sys.executable,
            "examples/monitor_workload.py",
            "--origin",
            args.origin,
            "--project",
            args.project,
            "--model-id",
            backend["model"]["id"],
            "--version-id",
            backend["version"]["id"],
            "--output",
            str(args.output / "workload.json"),
        ],
        check=True,
    )
    with httpx.Client(
        base_url=origins[1] if diagnostic else args.origin,
        headers=headers,
        timeout=None if diagnostic else 90,
        trust_env=False,
        follow_redirects=False,
    ) as client:
        diagnosis = timed_ai_post(
            client,
            f"/api/v1/monitoring/model-versions/{backend['version']['id']}/diagnosis",
            profile=profile,
            result=result,
            output=args.output / "results.json",
        )
        diagnosis.raise_for_status()
        result["monitoring"] = diagnosis.json()
        assert "inspect_seeded_delay" in result["monitoring"]["generated_advice"]["proposed_checks"]
    (args.output / "results.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(
        "Unbounded diagnostic walkthrough completed; bounded-profile acceptance is untested."
        if diagnostic
        else "Real dialogue/history/proposal/decision/draft/monitoring walkthrough passed."
    )


if __name__ == "__main__":
    main()
