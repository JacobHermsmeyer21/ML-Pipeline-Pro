"""Preserve the named test node and verify identical records/artifacts after restart."""
import hashlib
import json
import subprocess
import time
from pathlib import Path

import httpx

from kubernetes_demo import CMD, OUT

NODE = 'mlpp-laptop-five-minute-control-plane'


def run(parts, name):
    with (OUT/(name+'.log')).open('wb') as log:
        subprocess.run(parts,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=300)


def capture(smoke, label):
    with (OUT/(label+'-forward.log')).open('wb') as log:
        process=subprocess.Popen([*CMD,'port-forward','service/gateway','18000:8000','--address','127.0.0.1'],stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
        try:
            with httpx.Client(base_url='http://127.0.0.1:18000',headers={'X-Project-ID':'demo'},timeout=10,trust_env=False,follow_redirects=False) as client:
                for _ in range(60):
                    assert process.poll() is None
                    try:
                        if client.get('/api/v1/health/ready').status_code==200: break
                    except httpx.TransportError: pass
                    time.sleep(1)
                else: raise TimeoutError('Restart gateway readiness timed out')
                records={}
                for kind,identity in [('datasets',smoke['dataset']['id']),('models',smoke['model']['id'])]:
                    response=client.get('/api/v1/'+kind+'/'+identity)
                    response.raise_for_status(); records[kind]=response.json()
                versions=client.get('/api/v1/models/'+smoke['model']['id']+'/versions')
                versions.raise_for_status(); records['versions']=versions.json()
                assert any(v['id']==smoke['version']['id'] for v in records['versions']['items'])
                for kind,identity in [('experiments',smoke['training']['id']),('tuning-jobs',smoke['tuning']['id'])]:
                    response=client.get('/api/v1/'+kind+'/'+identity)
                    response.raise_for_status(); records[kind]=response.json()
                artifacts=[]
                for artifact in records['experiments']['artifacts']:
                    response=client.get('/api/v1/experiments/'+smoke['training']['id']+'/artifacts/'+artifact['name'])
                    response.raise_for_status()
                    measured={'name':artifact['name'],'size_bytes':len(response.content),'sha256':hashlib.sha256(response.content).hexdigest()}
                    assert measured['size_bytes']==artifact['size_bytes'] and measured['sha256']==artifact['sha256']
                    artifacts.append(measured)
                response=client.post('/api/v1/experiments',json={'dataset_id':smoke['dataset']['id'],'model_id':smoke['model']['id'],'config':{'epochs':5,'max_runtime_seconds':20}},headers={'Idempotency-Key':'train_'+smoke['model']['name'].removeprefix('classifier_')})
                response.raise_for_status()
                assert response.json()['id']==smoke['training']['id']
                return {'records':records,'verified_artifacts':artifacts,'submission_replay_id':response.json()['id']}
        finally:
            process.terminate(); process.wait(timeout=10)


def main():
    smoke=json.loads(Path('artifacts/laptop-five-minute-kubernetes/smoke.json').read_text())
    before=capture(smoke,'before-node-restart')
    run(['docker','stop','--time','30',NODE],'node-stop')
    run(['docker','start',NODE],'node-start')
    deadline=time.monotonic()+180
    while time.monotonic()<deadline:
        ready=subprocess.run([*CMD,'get','--raw=/readyz'],capture_output=True,timeout=10)
        if ready.returncode==0: break
        time.sleep(2)
    else: raise TimeoutError('Restart API server readiness timed out')
    run([*CMD,'wait','--for=condition=Ready','pod','--all','--timeout=240s'],'restart-pods-ready')
    after=capture(smoke,'after-node-restart')
    assert before==after,'Restart changed saved records, artifacts or submission identity'
    Path('artifacts/laptop-five-minute-validation/restart-result.json').write_text(json.dumps({'passed':True,'before':before,'after':after},indent=2)+'\n')
    print('Named node restart preserves completed records, verified artifact bytes and submission replay.')


if __name__=='__main__': main()
