"""Run the approved existing walkthrough once, retaining public evidence only."""
import hashlib
import json
import os
import re
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path

import httpx

from run_command import power

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'artifacts/laptop-five-minute-validation'
KUBE = ROOT / 'artifacts/laptop-five-minute-kubernetes/kubeconfig'
CMD = ['kubectl','--kubeconfig',str(KUBE),'--context','kind-mlpp-laptop-five-minute','-n','mlpp-demo']
MODEL = 'mlpp-qwen2.5:7b-instruct-q4_K_M-json-tools-v1'


def write(name, data):
    (OUT/name).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')


def command(parts):
    return subprocess.check_output(parts,text=True)


def ids(value):
    found=set()
    if isinstance(value,dict):
        if isinstance(value.get('conversation_id'),str): found.add(value['conversation_id'])
        for child in value.values(): found.update(ids(child))
    elif isinstance(value,list):
        for child in value: found.update(ids(child))
    return found


def main():
    assert power()['ac_line_status']==1, 'Connect presentation laptop to AC before inference'
    report={'started_utc':datetime.now(UTC).isoformat(),'power_before':power(),
            'source_revision':command(['git','rev-parse','HEAD']).strip(),
            'working_tree':command(['git','status','--porcelain']),
            'timing_profile':'laptop-five-minute','source_sha256':{},'retries':0,
            'generated_code_execution':False,'complete_workflow_passed':False}
    for p in [*Path('src/ml_pipeline_pro').glob('*.py'),Path('examples/midterm_walkthrough.py'),Path('examples/warm_local_model.py'),Path('examples/monitor_workload.py'),Path(__file__)]:
        report['source_sha256'][p.as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
    offsets={name:(ROOT/'.tools/test-prerequisites'/name).stat().st_size for name in ['ollama-stderr.log','ollama-stdout.log']}
    with httpx.Client(base_url='http://127.0.0.1:11434',timeout=5,trust_env=False,follow_redirects=False) as runtime:
        version=runtime.get('/api/version').json()
        model=next(m for m in runtime.get('/api/tags').json()['models'] if m['name']==MODEL)
        assert version['version']=='0.40.2'
        assert model['digest'].removeprefix('sha256:')=='abadc4bf8517d77dcc8db312ca98cd7cb43488243048c41f1b5746e031427779'
        report.update(runtime=version,model={'name':model['name'],'digest':model['digest']})
    headers={'X-Project-ID':'demo'}
    if key:=os.getenv('MLPP_API_KEY'): headers['X-API-Key']=key
    exit_code=1
    forwarded=None
    try:
        log=(OUT/'demo-forward.log').open('wb')
        forwarded=subprocess.Popen([*CMD,'port-forward','service/gateway','18000:8000','--address','127.0.0.1'],stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
        with httpx.Client(base_url='http://127.0.0.1:18000',headers=headers,timeout=10,trust_env=False,follow_redirects=False) as client:
            for _ in range(30):
                assert forwarded.poll() is None,'Gateway port-forward exited'
                try:
                    if client.get('/api/v1/health/ready').status_code==200: break
                except httpx.TransportError: pass
                time.sleep(1)
            else: raise TimeoutError('Gateway did not become ready')
            report['readiness_before']=200
            for phase,timeout,parts in [
                ('warmup',150,[sys.executable,'examples/warm_local_model.py','--model',MODEL]),
                ('demo',1800,[sys.executable,'examples/midterm_walkthrough.py','--origin','http://127.0.0.1:18000','--timing-profile','laptop-five-minute','--confirm-demo-proposal','--output','artifacts/laptop-five-minute-demo']),
            ]:
                result=subprocess.run([sys.executable,str(OUT/'run_command.py'),'--phase',phase,'--timeout',str(timeout),'--',*parts],creationflags=subprocess.CREATE_NO_WINDOW)
                report[phase]=json.loads((OUT/(phase+'-execution.json')).read_text())
                if result.returncode:
                    exit_code=result.returncode
                    break
                if phase=='demo':
                    report['complete_workflow_passed']=True
                    exit_code=0
            result_path=ROOT/'artifacts/laptop-five-minute-demo/results.json'
            if result_path.exists():
                result=json.loads(result_path.read_text())
                histories={}
                for identity in ids(result.get('ai_requests',[])):
                    response=client.get('/api/v1/conversations/'+identity)
                    histories[identity]={'status_code':response.status_code,'body':response.json()}
                write('public-histories.json',histories)
            report['readiness_after']=client.get('/api/v1/health/ready').status_code
    finally:
        if forwarded is not None:
            forwarded.terminate()
            forwarded.wait(timeout=10)
            log.close()
        pods=json.loads(command([*CMD,'get','pods','-o','json']))['items']
        report['pods']=[{'name':p['metadata']['name'],'app':p['metadata']['labels'].get('app'),'phase':p['status']['phase'],'containers':[{'image':c['image'],'imageID':c['imageID'],'ready':c['ready'],'restartCount':c['restartCount']} for c in p['status'].get('containerStatuses',[])]} for p in pods]
        for pod in pods:
            if pod['metadata']['labels'].get('app') in {'model-api','monitoring-api','gateway'}:
                name=pod['metadata']['name']
                (OUT/(name+'.log')).write_text(command([*CMD,'logs',name]),encoding='utf-8')
        for name,offset in offsets.items():
            with (ROOT/'.tools/test-prerequisites'/name).open('rb') as source:
                source.seek(offset); text=source.read().decode('utf-8',errors='replace')
            lines=[line for line in text.splitlines() if re.search(r'all slots are idle|prompt eval time|eval time|total time|cache|cancel task|stop processing|new prompt|/api/chat',line,re.I)]
            (OUT/(name.replace('.log','-demo-filtered.log'))).write_text('\n'.join(lines)+'\n',encoding='utf-8')
            if name=='ollama-stderr.log':
                states=[line for line in lines if re.search('all slots are idle|new prompt|cancel task|stop processing',line)]
                report['runner_final_state']=states[-1] if states else 'no state observed'
                report['runner_idle_after']='all slots are idle' in report['runner_final_state']
        report.update(power_after=power(),ended_utc=datetime.now(UTC).isoformat())
        write('demo-summary.json',report)
    print(json.dumps({key:report[key] for key in ['complete_workflow_passed','runner_idle_after','power_before','power_after']}))
    raise SystemExit(exit_code)


if __name__=='__main__': main()
