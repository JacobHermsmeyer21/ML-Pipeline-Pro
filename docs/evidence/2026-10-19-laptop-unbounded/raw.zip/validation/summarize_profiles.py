"""Offline compare installed finite/diagnostic specifications and restart counts."""
import copy
import json
from pathlib import Path

base=Path('artifacts/laptop-unbounded-validation')
def read(name):return json.loads((base/name).read_text())
finite=read('initial-finite-deployment/laptop-five-minute-installation.json')
diagnostic=read('laptop-unbounded-diagnostic-installation.json')
before={d['metadata']['name']:d for d in finite['deployments']}
after={d['metadata']['name']:d for d in diagnostic['deployments']}
assert before.keys()==after.keys()
changes=[]
allowed={'gateway','model-api','tuning-api','monitoring-api'}
for name in sorted(before):
    a,b=copy.deepcopy(before[name]['spec']),copy.deepcopy(after[name]['spec'])
    assert a['replicas']==b['replicas'],name
    ac,bc=a['template']['spec']['containers'][0],b['template']['spec']['containers'][0]
    assert ac.get('resources')==bc.get('resources'),name
    removed=[]
    if name in allowed:
        for key in ['startupProbe','readinessProbe','livenessProbe']:
            assert key in ac and key not in bc,(name,key)
            ac.pop(key);removed.append(key)
        ae={v['name']:v for v in ac.get('env',[])}
        be={v['name']:v for v in bc.get('env',[])}
        changed=[key for key in ae.keys()|be.keys() if ae.get(key)!=be.get(key)]
        if name in {'gateway','tuning-api'}:assert not changed
        else:
            assert set(changed)=={'MLPP_CHAT_UNBOUNDED_DIAGNOSTIC','MLPP_CHAT_TIMEOUT_SECONDS','MLPP_CHAT_MODEL_TIMEOUT_SECONDS'}
            assert be['MLPP_CHAT_UNBOUNDED_DIAGNOSTIC']['value']=='true'
            assert be['MLPP_CHAT_TIMEOUT_SECONDS']['value']==be['MLPP_CHAT_MODEL_TIMEOUT_SECONDS']['value']=='none'
        ac.pop('env',None);bc.pop('env',None)
        changes.append({'deployment':name,'probes_removed':removed,'env_changes':{key:{'before':ae.get(key),'diagnostic':be.get(key)} for key in sorted(changed)},'replicas':a['replicas'],'resources_unchanged':True})
    assert a==b,name
initial=read('initial-pods.json');final=read('final-pods.json')
def counts(pods):
    return {p['name']:{c['name']:{'restart_count':c['restartCount'],'container_id':c['containerID']} for c in p['status'].get('containerStatuses',[])} for p in pods}
assert counts(initial)==counts(final),'A container restarted or pod identity changed during measurement'
report={'installed_specification_comparison':'pass; only approved probe and timeout env changes',
        'changes':changes,'all_replicas_resources_and_unrelated_specifications_unchanged':True,
        'measurement_restart_counts_before':counts(initial),'measurement_restart_counts_after':counts(final),
        'pod_identities_and_restart_counts_unchanged':True}
(base/'profile-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
