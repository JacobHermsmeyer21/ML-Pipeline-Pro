"""Run approved verification gates serially and retain their original output."""
import os
import subprocess
import sys
from pathlib import Path

root=Path.cwd();out=root/'artifacts/laptop-unbounded-validation';out.mkdir(exist_ok=True)
uv=str(root/'.tools/bin/uv/uv.exe')
env={**os.environ,'UV_CACHE_DIR':str(root/'.uv-cache')}
phases=[
 ('sync',180,[uv,'sync','--offline','--locked','--extra','training']),
 ('ruff',120,[uv,'run','--offline','--locked','--extra','training','ruff','check','.']),
 ('format',120,[uv,'run','--offline','--locked','--extra','training','ruff','format','--check','.']),
 ('fast',900,[uv,'run','--offline','--locked','--extra','training','pytest','-m','not integration','--cov','--junitxml='+str(out/'fast.xml'),'--basetemp',str(out/'fast-temp'),'-o','cache_dir='+str(out/'pytest-cache-fast')]),
 ('dependencies',120,[uv,'pip','check']),
 ('build',300,[uv,'build','--offline']),
]
for phase,timeout,command in phases:
    print('Starting',phase,flush=True)
    subprocess.run([sys.executable,'artifacts/laptop-five-minute-validation/run_command.py','--phase',phase,'--timeout',str(timeout),'--output',str(out),'--',*command],env=env,check=True,creationflags=subprocess.CREATE_NO_WINDOW)
