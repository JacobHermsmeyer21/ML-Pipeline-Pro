"""Approved serial diagnostic runs; no AI/request/process waiting cutoff or retry."""
import hashlib
import ctypes
import json
import os
import re
import runpy
import subprocess
import sys
import time
from datetime import UTC,datetime
from pathlib import Path
from uuid import uuid4

import httpx
from bson.json_util import dumps
from pymongo import MongoClient

from operations import CMD,OUT,ROOT,active,close,forward,ready,write

power=runpy.run_path(str(ROOT/'artifacts/laptop-five-minute-validation/run_command.py'))['power']
MODEL='mlpp-qwen2.5:7b-instruct-q4_K_M-json-tools-v1'
DIGEST='abadc4bf8517d77dcc8db312ca98cd7cb43488243048c41f1b5746e031427779'
RUNTIME=ROOT/'.tools/test-prerequisites'

def resources():
    # Same lightweight Win32 counters as the retained diagnostic; no model/eval imports.
    class Memory(ctypes.Structure):
        _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(name,ctypes.c_ulonglong)
            for name in ['total','available','page_total','page_available','vtotal','vfree','ext']]
    memory=Memory();memory.length=ctypes.sizeof(memory)
    idle,kernel,user=(ctypes.c_ulonglong() for _ in range(3))
    api=ctypes.windll.kernel32
    if not api.GlobalMemoryStatusEx(ctypes.byref(memory)) or not api.GetSystemTimes(ctypes.byref(idle),ctypes.byref(kernel),ctypes.byref(user)):
        return {'unavailable':True}
    return {'monotonic_seconds':time.monotonic(),'physical_total_bytes':memory.total,
        'physical_available_bytes':memory.available,'commit_limit_bytes':memory.page_total,
        'commit_available_bytes':memory.page_available,'cpu_idle_100ns':idle.value,
        'cpu_kernel_100ns':kernel.value,'cpu_user_100ns':user.value}

def state():
    lines=(RUNTIME/'ollama-stderr.log').read_text(errors='replace').splitlines()
    selected=[s for s in lines if re.search('all slots are idle|new prompt|cancel task|stop processing',s)]
    return selected[-1] if selected else None

def wait_idle():
    while True:
        current=state()
        if current and 'all slots are idle' in current:return current
        time.sleep(5)

def snapshot(prefix):
    for kind in ['pods','events']:
        values=json.loads(subprocess.check_output([*CMD,'get',kind,'-o','json'],text=True,timeout=30))['items']
        if kind=='pods':values=[{'name':p['metadata']['name'],'app':p['metadata']['labels'].get('app'),'status':p['status']} for p in values]
        write(prefix+'-'+kind+'.json',values)

def histories(runout,project):
    path=runout/'results.json'
    if not path.exists():return
    result=json.loads(path.read_text());backend=result.get('backend',{})
    training=backend.get('training',{}).get('id')
    if not training:return
    processes=[]
    try:
        processes.append(forward('service/mongo',27017,27017,'history-'))
        time.sleep(2)
        with MongoClient('mongodb://127.0.0.1:27017/?directConnection=true',serverSelectionTimeoutMS=5000) as client:
            turns=list(client.ml_pipeline_pro.conversation_turns.find(
                {'project_id':project}, {'_id':1,'conversation_id':1,'request_id':1,'timeout_mode':1,'deadline':1,'created_at':1,'public.status':1,'public.error':1,'public.pending_action':1}))
            parents=list(client.ml_pipeline_pro.conversations.find({'project_id':project},
                {'_id':1,'project_id':1,'revision':1,'timeout_mode':1,'deadline':1,'active_turn_id':1}))
        (runout/'saved-deadlines.json').write_text(dumps({'turns':turns,'parents':parents},indent=2)+'\n')
        ids={t['conversation_id'] for t in turns}
        with httpx.Client(base_url='http://127.0.0.1:18001',headers={'X-Project-ID':project},timeout=15,trust_env=False,follow_redirects=False) as client:
            saved={}
            for identity in ids:
                response=client.get('/api/v1/conversations/'+identity);response.raise_for_status();saved[identity]=response.json()
            (runout/'public-histories.json').write_text(json.dumps(saved,indent=2)+'\n')
    finally:close(processes)

def main():
    assert not (OUT/'measurement.json').exists(),'Use fresh diagnostic evidence; no automatic retry'
    helpers=[Path(__file__).resolve(),OUT/'operations.py',ROOT/'artifacts/laptop-five-minute-validation/restart_kubernetes.py',ROOT/'artifacts/laptop-five-minute-validation/kubernetes_demo.py',ROOT/'artifacts/laptop-five-minute-validation/run_command.py']
    report={'started_utc':datetime.now(UTC).isoformat(),'source_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
        'automatic_wall_cutoff_seconds':None,'automatic_retries':0,'generated_code_execution':False,'maximum_runs':2,
        'status':'running','phase':'preflight','bounded_profile_acceptance':False,'source_sha256':{str(p.relative_to(ROOT)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in [*(ROOT/'src/ml_pipeline_pro').glob('*.py'),ROOT/'examples/midterm_walkthrough.py',*helpers]},'runs':[]}
    processes=[]
    process=None
    item=None
    work_may_be_active=False
    write('measurement.json',report)
    try:
        assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip(),'Measure committed clean application source'
        assert power()['ac_line_status']==1,'Connect AC before inference'
        wait_idle()
        pods=active('laptop-unbounded-diagnostic')
        model=next(p['pod'] for p in pods if p['app']=='model-api')
        monitor=next(p['pod'] for p in pods if p['app']=='monitoring-api')
        for target,port in [('service/gateway',18000),('pod/'+model,18001),('pod/'+monitor,18002)]:
            processes.append(forward(target,port,label='measurement-'))
        ready(processes,('http://127.0.0.1:18000','http://127.0.0.1:18001','http://127.0.0.1:18002'))
        offsets={name:(RUNTIME/name).stat().st_size for name in ['ollama-stderr.log','ollama-stdout.log']}
        report.update(power_before=power(),runtime_offsets=offsets,direct_model_pod=model,direct_monitoring_pod=monitor)
        snapshot('initial')
        with httpx.Client(base_url='http://127.0.0.1:11434',timeout=8,trust_env=False,follow_redirects=False) as client:
            version=client.get('/api/version');version.raise_for_status()
            tags=client.get('/api/tags');tags.raise_for_status()
            installed=next(m for m in tags.json()['models'] if m['name']==MODEL)
            assert installed['digest'].removeprefix('sha256:')==DIGEST and version.json()['version']=='0.40.2'
            report.update(model={'tag':MODEL,'digest':DIGEST},runtime_version=version.json()['version'])
            resident=client.get('/api/ps');resident.raise_for_status();report['resident_before_warmup']=resident.json()
            report['phase']='empty-prompt-warmup'
            write('measurement.json',report)
            warm_start=time.monotonic()
            work_may_be_active=True
            warm=client.post('/api/generate',timeout=None,json={'model':MODEL,'prompt':'','stream':False,'keep_alive':'30m','options':{'num_ctx':8192}})
            warm.raise_for_status();assert warm.json()['done'] and warm.json()['response']==''
            report['warmup']={'elapsed_seconds':time.monotonic()-warm_start,'reply':warm.json(),'timeout':None,'generated_text':False}
            write('measurement.json',report)
        wait_idle()
        work_may_be_active=False
        for number in [1,2]:
            assert power()['ac_line_status']==1
            directory=ROOT/('artifacts/laptop-unbounded-demo-'+str(number))
            assert not directory.exists(),'Preserve old outputs; use fresh run identities'
            project='laptop-unbounded-'+uuid4().hex[:12]
            argv=[sys.executable,'examples/midterm_walkthrough.py','--origin','http://127.0.0.1:18000','--project',project,
                  '--timing-profile','laptop-unbounded-diagnostic','--diagnostic-model-api-origin','http://127.0.0.1:18001',
                  '--diagnostic-monitoring-api-origin','http://127.0.0.1:18002','--confirm-demo-proposal','--output',str(directory)]
            item={'number':number,'project':project,'argv':argv,'started_utc':datetime.now(UTC).isoformat(),'power_before':power(),
                  'runner_before':wait_idle(),'timeout_seconds':None,'explicit_warmup_before':number==1,'source_sha256':report['source_sha256']}
            item['status']='running'
            report['phase']='walkthrough-'+str(number)
            report['runs'].append(item);write('measurement.json',report)
            started=time.monotonic()
            with (OUT/('demo-'+str(number)+'.log')).open('wb') as log, (OUT/('host-'+str(number)+'.jsonl')).open('w') as samples:
                work_may_be_active=True
                process=subprocess.Popen(argv,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
                item['process_id']=process.pid
                write('measurement.json',report)
                while process.poll() is None:
                    sample={'utc':datetime.now(UTC).isoformat(),'elapsed_seconds':time.monotonic()-started,'power':power()}
                    try:sample['resources']=resources()
                    except Exception as exc:sample['resource_unavailable']=type(exc).__name__
                    samples.write(json.dumps(sample)+'\n');samples.flush()
                    write('progress.json',{'run':number,'utc':sample['utc'],'elapsed_seconds':sample['elapsed_seconds'],'status':'waiting; no generation progress inferred'})
                    for _ in range(30):
                        if process.poll() is not None:break
                        time.sleep(1)
                item.update(exit_code=process.returncode,elapsed_seconds=time.monotonic()-started,ended_utc=datetime.now(UTC).isoformat(),power_after=power(),status='completed' if process.returncode==0 else 'failed')
                report['phase']='waiting-for-runtime-idle-after-'+str(number)
                write('measurement.json',report)
            # A failed HTTP request never causes observer cleanup to kill ongoing runtime work.
            item.update(runner_after=wait_idle(),idle_observed_utc=datetime.now(UTC).isoformat())
            work_may_be_active=False
            report['phase']='collecting-after-'+str(number)
            write('measurement.json',report)
            histories(directory,project)
            snapshot('after-run-'+str(number))
            write('measurement.json',report)
            if item['exit_code']!=0:break
        snapshot('final')
        for pod in pods:
            result=subprocess.run([*CMD,'logs',pod['pod']],capture_output=True,timeout=30)
            (OUT/(pod['pod']+'-measurement.log')).write_bytes(result.stdout+result.stderr)
        for name,offset in offsets.items():
            data=(RUNTIME/name).read_bytes()[offset:]
            (OUT/('measurement-'+name)).write_bytes(data)
        report.update(ended_utc=datetime.now(UTC).isoformat(),power_after=power(),runner_final_state=state(),
                      all_planned_runs_completed_correctly=len(report['runs'])==2 and all(r['exit_code']==0 for r in report['runs']))
        report['status']='completed' if report['all_planned_runs_completed_correctly'] else 'failed'
        report['phase']='finished'
        write('measurement.json',report)
    except BaseException as exc:
        report.update(status='interrupted' if isinstance(exc,KeyboardInterrupt) else 'failed',exception_type=type(exc).__name__,ended_utc=datetime.now(UTC).isoformat(),capture_complete=False)
        if item is not None and item.get('status')=='running':
            item.update(observer_status=report['status'],observed_child_exit_code=process.poll() if process is not None else None)
        report['outstanding_model_work']='unknown' if work_may_be_active else False
        raise
    finally:
        report['cleanup_deferred_until_idle_or_explicit_stop']=work_may_be_active
        report['owned_forward_process_ids']=[p.pid for p,_ in processes]
        write('measurement.json',report)
        if not work_may_be_active:close(processes)
    raise SystemExit(0 if report.get('all_planned_runs_completed_correctly') else 1)

if __name__=='__main__':main()
