"""Check capture syntax, non-inference CLI guards and build payloads offline."""
import ast
import hashlib
import json
import runpy
import subprocess
import sys
import tarfile
import zipfile
from pathlib import Path

out=Path('artifacts/laptop-unbounded-validation')
for source in out.glob('*.py'):ast.parse(source.read_text())
values=runpy.run_path(str(out/'measure_demo.py'))
sample=values['resources']()
assert sample.get('physical_total_bytes',0)>0,sample
report={'capture_python_syntax':'pass','host_counter_functional_sample':sample,'live_model_calls':0,'guards':[]}
# Exercise failure journaling without entering network/model preflight or writing a run.
scope=values['main'].__globals__
journal=[]
original_write,original_power=scope['write'],scope['power']
scope['write']=lambda name,value: journal.append(json.loads(json.dumps(value))) if name=='measurement.json' else None
scope['power']=lambda: {'ac_line_status':0}
try:
    try:values['main']()
    except AssertionError:pass
    else:raise AssertionError('Preflight must fail before network/model calls')
finally:
    scope['write'],scope['power']=original_write,original_power
assert journal[0]['status']=='running' and journal[-1]['status']=='failed'
assert journal[-1]['capture_complete'] is False and journal[-1]['outstanding_model_work'] is False
assert not journal[-1]['runs'] and not journal[-1]['cleanup_deferred_until_idle_or_explicit_stop']
assert all(any(name.endswith(helper) for name in journal[0]['source_sha256']) for helper in ['operations.py','restart_kubernetes.py','kubernetes_demo.py','run_command.py'])
report['preflight_failure_journal_and_helper_provenance']='pass; simulated AC refusal, zero model/network calls'
commands=[
 ('ordinary-model-gate-rejects-unbounded',[sys.executable,'-m','pytest','evaluations/test_conversation_model.py','--timing-profile','laptop-unbounded-diagnostic','--collect-only','-q'],4),
 ('ordinary-snippet-gate-rejects-unbounded',[sys.executable,'-m','pytest','evaluations/test_snippet_model.py','--timing-profile','laptop-unbounded-diagnostic','--collect-only','-q'],4),
 ('diagnostic-requires-direct-origins',[sys.executable,'examples/midterm_walkthrough.py','--timing-profile','laptop-unbounded-diagnostic'],2),
]
for name,command,expected in commands:
    result=subprocess.run(command,capture_output=True,timeout=30)
    (out/(name+'.log')).write_bytes(result.stdout+result.stderr)
    assert result.returncode==expected,(name,result.returncode)
    assert b'error' in result.stderr.lower() or b'ERROR' in result.stderr,name
    report['guards'].append({'name':name,'argv':command,'expected_exit_code':expected,'exit_code':result.returncode})
builds=[]
for path in Path('dist').iterdir():
    if path.suffix=='.whl':
        with zipfile.ZipFile(path) as z:
            names=z.namelist()
            assert z.read('ml_pipeline_pro/conversation_store.py')==Path('src/ml_pipeline_pro/conversation_store.py').read_bytes()
    elif path.name.endswith('.tar.gz'):
        with tarfile.open(path) as tar:names=tar.getnames()
    else:continue
    assert not any('.uv-cache' in name for name in names),path
    builds.append({'name':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size,'cache_entries':0})
assert len(builds)==2
report['builds']=builds
(out/'capture-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
