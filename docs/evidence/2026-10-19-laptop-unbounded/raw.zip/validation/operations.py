"""Operate only the preserved named laptop cluster; no inference in this module."""
import hashlib
import json
import os
import socket
import subprocess
import sys
import time
from datetime import UTC,datetime
from pathlib import Path

import httpx

ROOT=Path.cwd();OUT=ROOT/'artifacts/laptop-unbounded-validation'
KUBE=ROOT/'artifacts/laptop-five-minute-kubernetes/kubeconfig'
CMD=['kubectl','--kubeconfig',str(KUBE),'--context','kind-mlpp-laptop-five-minute','-n','mlpp-demo']
NODE='mlpp-laptop-five-minute-control-plane'
sys.path.insert(0,str(ROOT/'artifacts/laptop-five-minute-validation'))
import restart_kubernetes as preserved
preserved.CMD=CMD;preserved.OUT=OUT

def write(name,value):
    (OUT/name).write_text(json.dumps(value,indent=2)+'\n')

def command(parts,name,timeout=300):
    started=time.monotonic();record={'argv':parts,'started_utc':datetime.now(UTC).isoformat(),'timeout_seconds':timeout}
    try:
        with (OUT/(name+'.log')).open('wb') as log:
            result=subprocess.run(parts,stdout=log,stderr=subprocess.STDOUT,timeout=timeout,creationflags=subprocess.CREATE_NO_WINDOW)
        record['exit_code']=result.returncode
    finally:
        record.update(ended_utc=datetime.now(UTC).isoformat(),elapsed_seconds=time.monotonic()-started)
        write(name+'-command.json',record)
    assert result.returncode==0,name

def forward(target,local,remote=8000,label=''):
    with socket.socket() as probe:probe.bind(('127.0.0.1',local))
    log=(OUT/(label+'forward-'+str(local)+'.log')).open('ab')
    process=subprocess.Popen([*CMD,'port-forward',target,str(local)+':'+str(remote),'--address','127.0.0.1'],stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
    return process,log

def close(processes):
    for process,log in reversed(processes):
        if process.poll() is None:
            process.terminate();process.wait(timeout=10)
        log.close()

def ready(processes,origins=('http://127.0.0.1:18000',)):
    for _ in range(60):
        assert all(p.poll() is None for p,_ in processes),'Own port-forward exited'
        try:
            with httpx.Client(timeout=3,trust_env=False,follow_redirects=False) as client:
                if all(client.get(origin+'/api/v1/health/ready').status_code==200 for origin in origins):return
        except httpx.TransportError:pass
        time.sleep(1)
    raise TimeoutError('Explicit HTTP preflight failed')

def active(profile):
    pods=json.loads(subprocess.check_output([*CMD,'get','pods','-o','json'],text=True,timeout=30))['items']
    pods=[p for p in pods if p['status']['phase']=='Running' and not p['metadata'].get('deletionTimestamp')]
    expected={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'src/ml_pipeline_pro').glob('*.py')}
    code="""import json,hashlib,pathlib,ml_pipeline_pro,httpx
from ml_pipeline_pro.config import Settings
s=Settings(_env_file=None);p=pathlib.Path(ml_pipeline_pro.__file__).parent
r=httpx.get('http://127.0.0.1:8000/api/v1/health/ready',timeout=5,trust_env=False);r.raise_for_status()
print(json.dumps({'module_path':str(p),'sha256':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in p.glob('*.py')},'http_readiness':r.json(),'settings':{'chat_enabled':s.chat_enabled,'model':s.chat_model,'protocol':s.chat_protocol,'unbounded':s.chat_unbounded_diagnostic,'model_seconds':s.chat_model_timeout_seconds,'turn_seconds':s.chat_timeout_seconds}}))
"""
    observed=[]
    for pod in pods:
        app=pod['metadata']['labels'].get('app')
        if app not in ['model-api','tuning-api','monitoring-api']:continue
        item=json.loads(subprocess.check_output([*CMD,'exec',pod['metadata']['name'],'--','python','-c',code],text=True,timeout=30))
        assert item['sha256']==expected
        if app in ['model-api','monitoring-api']:
            diagnostic=profile=='laptop-unbounded-diagnostic'
            assert item['settings']['unbounded']==diagnostic
            assert item['settings']['model_seconds']==(None if diagnostic else 240)
            assert item['settings']['turn_seconds']==(None if diagnostic else 270)
            assert item['settings']['protocol']=='guided'
        item.update(pod=pod['metadata']['name'],app=app,images=[{'image':c['image'],'imageID':c['imageID']} for c in pod['status']['containerStatuses']])
        observed.append(item)
    assert len(observed)==4
    deployments=json.loads(subprocess.check_output([*CMD,'get','deployments','-o','json'],text=True))['items']
    rendered=json.loads((OUT/profile/'stack.json').read_text())['items']
    expected_deployments={i['metadata']['name']:i for i in rendered if i['kind']=='Deployment'}
    for deployment in deployments:
        name=deployment['metadata']['name']
        if name not in expected_deployments:continue
        actual=deployment['spec']['template']['spec']['containers'][0]
        expected_container=expected_deployments[name]['spec']['template']['spec']['containers'][0]
        assert actual.get('resources')==expected_container.get('resources'),name
        for probe in ['livenessProbe','readinessProbe','startupProbe']:
            expected_probe=expected_container.get(probe)
            if expected_probe is None:assert probe not in actual,(name,probe)
            else:
                for key,value in expected_probe.items():
                    if key=='httpGet':
                        for field,item in value.items():assert actual[probe][key][field]==item,(name,probe)
                    else:assert actual[probe][key]==value,(name,probe)
    write(profile+'-installation.json',{'pods':observed,'deployments':deployments,'source_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()})
    return observed

def deploy(profile,build=False):
    from ml_pipeline_pro.laptop_deployment import render_laptop_profile
    baseline=json.loads((ROOT/'artifacts/laptop-five-minute-kubernetes/smoke.json').read_text())
    before=preserved.capture(baseline,'before-'+profile)
    write('before-'+profile+'-records.json',before)
    if build:
        image='ml-pipeline-pro:unbounded-'+subprocess.check_output(['git','rev-parse','--short','HEAD'],text=True).strip()
        command(['docker','build','-t',image,'.'],'image-build',1200)
        command([str(ROOT/'.tools/bin/kind.exe'),'load','docker-image',image,'--name','mlpp-laptop-five-minute'],'image-load',600)
        write('image.json',{'tag':image,'host_id':subprocess.check_output(['docker','image','inspect',image,'--format','{{.Id}}'],text=True).strip()})
    image=json.loads((OUT/'image.json').read_text())['tag']
    manifest=render_laptop_profile(ROOT,OUT/profile,profile_name=profile)
    data=json.loads(manifest.read_text())
    for item in data['items']:
        if item['kind']=='Deployment':
            for c in item['spec']['template']['spec']['containers']:
                if c['image'].startswith('ml-pipeline-pro:'):c['image']=image
    manifest.write_text(json.dumps(data,indent=2)+'\n')
    command([*CMD,'apply','-f',str(manifest)],profile+'-apply')
    for item in data['items']:
        if item['kind']=='Deployment':
            name=item['metadata']['name']
            command([*CMD,'rollout','status','deployment/'+name,'--timeout=180s'],profile+'-rollout-'+name)
    active(profile)
    after=preserved.capture(baseline,'after-'+profile)
    assert before==after,'Rollout changed preserved records/artifacts/replay identity'
    write('after-'+profile+'-records.json',after)

def ordinary():
    processes=[]
    try:
        for target,local,remote in [('service/gateway',18000,8000),('service/mongo',27017,27017),('service/redis',6379,6379)]:
            processes.append(forward(target,local,remote,'ordinary-'))
        ready(processes)
        env={**os.environ,'MLPP_RUN_INTEGRATION':'1','MLPP_RUN_WORKER_INTEGRATION':'1','MLPP_TEST_API_BASE_URL':'http://127.0.0.1:18000/api/v1','MLPP_TEST_MONGODB_URI':'mongodb://127.0.0.1:27017/?directConnection=true','MLPP_TEST_REDIS_URL':'redis://127.0.0.1:6379/0','UV_CACHE_DIR':str(ROOT/'.uv-cache')}
        subprocess.run([sys.executable,'artifacts/laptop-five-minute-validation/run_command.py','--phase','ordinary','--timeout','900','--output',str(OUT),'--',str(ROOT/'.tools/bin/uv/uv.exe'),'run','--offline','--locked','--extra','training','pytest','-m','integration and not recovery','--junitxml='+str(OUT/'ordinary.xml'),'--basetemp',str(OUT/'ordinary-temp'),'-o','cache_dir='+str(OUT/'pytest-cache-ordinary')],env=env,check=True,creationflags=subprocess.CREATE_NO_WINDOW)
    finally:close(processes)

if __name__=='__main__':
    action=sys.argv[1]
    if action=='prepare':deploy('laptop-five-minute',build=True)
    elif action=='diagnostic':deploy('laptop-unbounded-diagnostic')
    elif action=='restore':deploy('laptop-five-minute')
    elif action=='ordinary':ordinary()
    else:raise ValueError('Unknown explicit operation')
