"""Temporary thread-scoped wake request for verification and the approved experiment."""
import ctypes
import json
import time
from datetime import UTC,datetime
from pathlib import Path

out=Path('artifacts/laptop-unbounded-validation');stop=out/'keep-awake-stop.txt'
assert not stop.exists()
api=ctypes.windll.kernel32.SetThreadExecutionState
api.argtypes=[ctypes.c_uint];api.restype=ctypes.c_uint
previous=api(0x80000001)
assert previous
report={'started_utc':datetime.now(UTC).isoformat(),'previous_state':previous,'requested_flags':0x80000001,'power_policy_modified':False,'automatic_wall_cutoff':None}
(out/'keep-awake.json').write_text(json.dumps(report,indent=2)+'\n')
try:
    while not stop.exists():time.sleep(1)
finally:
    report.update(ended_utc=datetime.now(UTC).isoformat(),released_state=api(0x80000000))
    (out/'keep-awake.json').write_text(json.dumps(report,indent=2)+'\n')
