"""Archive allowlisted completed diagnostic evidence; never invoke services/model."""
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from datetime import UTC, datetime
from pathlib import Path

ROOT=Path.cwd()
BASE=ROOT/'artifacts/laptop-unbounded-validation'
DEST=ROOT/'docs/evidence/2026-10-19-laptop-unbounded'
REVISION='1152aa858eca169d49e1d5d003bab2229e4cddf9'

def read(name):return json.loads((BASE/name).read_text(encoding='utf-8-sig'))
def sha(data):return hashlib.sha256(data).hexdigest()
def write(name,value):(DEST/name).write_text(json.dumps(value,indent=2)+'\n')
def junit(name):
    suites=list(ET.parse(BASE/name).getroot().iter('testsuite'))
    counts={k:sum(int(s.get(k,0)) for s in suites) for k in ['tests','failures','errors','skipped']}
    assert counts['failures']==counts['errors']==counts['skipped']==0,counts
    return counts

def main():
    assert not DEST.exists(),'Preserve published evidence; package once'
    measurement=read('measurement.json')
    assert measurement['source_revision']==REVISION
    assert measurement['status'] in ['completed','failed','interrupted']
    assert measurement['automatic_wall_cutoff_seconds'] is None
    assert not measurement['cleanup_deferred_until_idle_or_explicit_stop']
    assert read('keep-awake.json')['released_state']
    restore=read('restoration-verification.json')
    assert restore['runner_idle_before_restore'] and restore['finite_settings_and_probes_verified']
    checks={name:junit(name+'.xml') for name in ['fast','ordinary','recovery']}
    assert [checks[n]['tests'] for n in checks]==[661,73,10]
    for name in ['sync','ruff','format','fast','dependencies','build','ordinary','recovery']:
        assert read(name+'-execution.json')['exit_code']==0,name
    ci=read('ci-implementation.json')
    assert ci['head_sha']==REVISION and ci['conclusion']=='success'
    assert len(ci['jobs'])==5 and all(j['conclusion']=='success' for j in ci['jobs'])
    for name,expected in measurement['source_sha256'].items():
        assert sha((ROOT/name).read_bytes())==expected,name
    assert read('before-laptop-unbounded-diagnostic-records.json')==read('after-laptop-unbounded-diagnostic-records.json')
    assert read('before-laptop-five-minute-records.json')==read('after-laptop-five-minute-records.json')
    old_archives=[]
    for folder in ['2026-10-19-laptop-five-minute','2026-10-19-laptop-awake-gates','2026-10-19-laptop-gateway-health']:
        for path in (ROOT/'docs/evidence'/folder).iterdir():
            if path.is_file():
                relative=path.relative_to(ROOT).as_posix()
                assert subprocess.check_output(['git','show','HEAD:'+relative])==path.read_bytes(),relative
        old_archives.append(folder)
    payloads={}
    def add(path,name):
        assert path.is_file() and name not in payloads,name
        data=path.read_bytes()
        forbidden=[rb'^\s*client-(?:key|certificate)-data:\s*\S+',rb'^-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',rb'ghp_[A-Za-z0-9]{20,}',rb'github_pat_[A-Za-z0-9_]{20,}']
        assert not any(re.search(p,data,re.M) for p in forbidden),name
        payloads[name]=(path,data)
    for path in sorted(BASE.iterdir()):
        if path.is_file() and path.suffix in {'.json','.jsonl','.log','.xml','.py','.txt'}:add(path,'validation/'+path.name)
    for path in sorted((BASE/'initial-finite-deployment').iterdir()):
        if path.is_file() and path.suffix in {'.json','.log'}:add(path,'validation/initial-finite-deployment/'+path.name)
    runs=[]
    for item in measurement['runs']:
        directory=ROOT/('artifacts/laptop-unbounded-demo-'+str(item['number']))
        for path in sorted(directory.iterdir()):
            if path.is_file() and path.suffix=='.json':add(path,'demo-'+str(item['number'])+'/'+path.name)
        result=json.loads((directory/'results.json').read_text()) if (directory/'results.json').exists() else {}
        requests=[{k:request[k] for k in ['path','origin','elapsed_seconds','status_code','failure_type'] if k in request} for request in result.get('ai_requests',[])]
        runs.append({'number':item['number'],'status':item['status'],'exit_code':item.get('exit_code'),'walkthrough_seconds':item.get('elapsed_seconds'),'requests':requests,'saved_proposal_replay_equal':result.get('saved_proposal_replay_equal'),'draft_replay_equal':result.get('draft_replay_equal'),'generated_code_execution':result.get('code_execution'),'dialogue_statuses':[t['status'] for t in result.get('dialogue',[])],'runner_after':item.get('runner_after')})
    for name in ['run_command.py','restart_kubernetes.py','kubernetes_demo.py']:
        add(ROOT/'artifacts/laptop-five-minute-validation'/name,'orchestration-dependencies/'+name)
    add(ROOT/'artifacts/laptop-five-minute-kubernetes/smoke.json','prior-record-baseline/smoke.json')
    sources=[p for p in (ROOT/'src/ml_pipeline_pro').glob('*.py')]
    sources += [ROOT/name for name in ['tests/test_unbounded_diagnostic.py','tests/integration/test_unbounded_store.py','tests/conversation_memory.py','scripts/render_laptop_profile.py','scripts/deploy_kind.py','scripts/deployment_smoke.py','examples/midterm_walkthrough.py','examples/monitor_workload.py','uv.lock','pyproject.toml','Dockerfile']]
    sources += [p for p in (ROOT/'deploy').rglob('*') if p.is_file() and p.suffix in {'.yaml','.conf','.json'}]
    for path in sources:add(path,'source/'+path.relative_to(ROOT).as_posix())
    samples=[]
    for path in sorted(BASE.glob('host-*.jsonl')):
        samples.extend(json.loads(line) for line in path.read_text().splitlines() if line.strip())
    available=[s['resources']['physical_available_bytes'] for s in samples if s.get('resources',{}).get('physical_available_bytes') is not None]
    results={'implementation_revision':REVISION,'plan':'docs/plans/2026-10-19-laptop-unbounded-diagnostic-plan.md','approval':{'reviewer':'Jacob','quote':'go for it','date':'2026-10-19'},'checks':checks,'ci':ci,'measurement':{'status':measurement['status'],'runs':runs,'warmup':measurement.get('warmup'),'all_planned_runs_completed_correctly':measurement.get('all_planned_runs_completed_correctly',False),'bounded_profile_acceptance':False,'full_gateway_ai_reliability':'untested: AI requests use explicitly verified direct API origins'},'resources':{'sample_count':len(samples),'minimum_host_available_bytes':min(available) if available else None,'causal_attribution':'not established by these lightweight host counters'},'restoration':restore,'review':read('review.json'),'live_finite_expiry':'outstanding; not executed in this diagnostic','fresh_ten_and_seven_gates':'unrun; preceding accepted cohort retained unchanged','generated_code_execution':False,'automatic_retries':0,'prior_archives_unchanged':old_archives,'initial_probe_free_readiness_attempt':'failed connection-refused during startup; retained separately from later successful explicit HTTP preflight','package_inspection':read('capture-validation.json')['builds']}
    DEST.mkdir(parents=True)
    write('results.json',results)
    manifest={'created_utc':datetime.now(UTC).isoformat(),'implementation_revision':REVISION,'entries':[{'path':name,'source':path.relative_to(ROOT).as_posix(),'bytes':len(data),'sha256':sha(data)} for name,(path,data) in sorted(payloads.items())],'excluded':['private kubeconfig and certificates/keys','credentials/environment dumps','model weights/installers','package archives','test caches/temp directories and recovery database dumps','rendered Secret objects']}
    write('manifest.json',manifest)
    with zipfile.ZipFile(DEST/'raw.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for name,(_,data) in sorted(payloads.items()):archive.writestr(name,data)
    with zipfile.ZipFile(DEST/'raw.zip') as archive:
        assert archive.testzip() is None
        assert set(archive.namelist())==set(payloads)
        for entry in manifest['entries']:
            data=archive.read(entry['path']);assert len(data)==entry['bytes'] and sha(data)==entry['sha256']
    verification={'verified_utc':datetime.now(UTC).isoformat(),'archive_crc':'pass','payload_hashes_and_sizes':'pass','payload_count':len(payloads),'archive_bytes':(DEST/'raw.zip').stat().st_size,'archive_sha256':sha((DEST/'raw.zip').read_bytes()),'manifest_sha256':sha((DEST/'manifest.json').read_bytes()),'results_sha256':sha((DEST/'results.json').read_bytes()),'live_source_and_executed_helper_hashes_match':True,'prior_evidence_unchanged':True,'checks_counts':[661,73,10],'all_five_implementation_ci_jobs':'success','limits':'Archive verified locally; reviewer did not independently reproduce measurements or verify payload bytes'}
    write('verification.json',verification)
    print(json.dumps(verification,indent=2))

if __name__=='__main__':main()
