"""Restore the finite profile only after observed runtime idle; no generation."""
import json
import subprocess
from datetime import UTC,datetime

from measure_demo import power,wait_idle
from operations import OUT,deploy,write

measurement=json.loads((OUT/'measurement.json').read_text())
assert measurement['status'] in ['completed','failed','interrupted'],'Do not restore a running measurement'
assert not measurement['cleanup_deferred_until_idle_or_explicit_stop'],'Resolve outstanding work before restoration'
idle=wait_idle()  # No deadline and no process cancellation.
record={'started_utc':datetime.now(UTC).isoformat(),'runner_idle_before_restore':True,
        'runner_observation':idle,'idle_observed_utc':datetime.now(UTC).isoformat(),
        'finite_settings_and_probes_verified':False,'status':'running','power_before':power(),
        'source_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()}
write('restoration-verification.json',record)
try:
    deploy('laptop-five-minute')
    record.update(status='completed',finite_settings_and_probes_verified=True,
                  deployed_profile='laptop-five-minute',model_seconds=240,turn_seconds=270,
                  chat_unbounded_diagnostic=False,preserved_records_artifacts_replay='unchanged')
except BaseException as exc:
    record.update(status='failed',exception_type=type(exc).__name__)
    raise
finally:
    record.update(ended_utc=datetime.now(UTC).isoformat(),power_after=power())
    write('restoration-verification.json',record)
print(json.dumps(record,indent=2))
