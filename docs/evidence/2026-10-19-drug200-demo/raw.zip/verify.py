"""Validate changed documentation, retained archive, and measured result claims."""

import hashlib
import json
import re
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DEST = ROOT / "docs/evidence/2026-10-19-drug200-demo"
paths = [DEST / "README.md", ROOT / "docs/guides/dashboard.md", ROOT / "docs/memory/dashboard-column-mapping.md", ROOT / "docs/memory/README.md"]
links = 0
for path in paths:
    content = path.read_text(encoding="utf-8")
    assert all(line == line.rstrip() for line in content.splitlines()), path
    for target in re.findall(r"\[[^\]]*\]\(([^)]+)\)", content):
        if target.startswith(("http://", "https://")):
            continue
        file, _, anchor = target.partition("#")
        resolved = (path.parent / file).resolve() if file else path
        assert resolved.exists(), (path, target)
        if anchor:
            headings = re.findall(r"^#+\s+(.+)$", resolved.read_text(encoding="utf-8"), re.M)
            slugs = [re.sub(r"[^\w -]", "", title.lower()).replace(" ", "-") for title in headings]
            assert anchor in slugs, (path, target, slugs)
        links += 1

result = json.loads((DEST / "results.json").read_text())
manifest = json.loads((DEST / "manifest.json").read_text())
assert hashlib.sha256((DEST / "raw.zip").read_bytes()).hexdigest() == result["raw_archive_sha256"]
with zipfile.ZipFile(DEST / "raw.zip") as archive:
    assert archive.testzip() is None
    assert len(archive.namelist()) == len(manifest) + 1
    for name, metadata in manifest.items():
        data = archive.read(name)
        assert hashlib.sha256(data).hexdigest() == metadata["sha256"]
        assert len(data) == metadata["size_bytes"]
        if name.endswith(".py"):
            compile(data, name, "exec")
    assert archive.read("workspace.js") == (ROOT / "src/ml_pipeline_pro/dashboard/workspace.js").read_bytes()
    fast_bytes = archive.read("fast.log")
    fast = fast_bytes.decode("utf-16" if fast_bytes.startswith(b"\xff\xfe") else "utf-8-sig")
    assert "684 passed, 85 deselected in 52.15s" in fast
    assert "81%" in fast
    before, after = [json.loads(archive.read(name)) for name in ["browser-before.json", "browser-after.json"]]
    assert before["status"] == after["status"] == "passed"
    assert any("feature_columns=Drug" in url for url in before["steps"][-1]["result"])
    metrics = after["training"]["metrics"]
    assert metrics["validation_f1"] == 1 and metrics["best_epoch"] == 24
    assert round(metrics["test_accuracy"] * 100, 1) == 95.6
    workload = json.loads(archive.read("workload.json"))
    assert len(workload["observations"]) == 20
    assert sum(row["fault"] == "seeded_latency" for row in workload["observations"]) == 5
    assert workload["training_artifacts_written"] is False
assert hashlib.sha256(Path(r"C:\Users\jacob\Downloads\drug200.csv").read_bytes()).hexdigest() == result["preparation"]["source_sha256"]
report = {"status": "passed", "local_links_and_anchors": links, "changed_markdown_files": len(paths), "archive_payload_hashes": len(manifest), "python_capture_syntax": "passed", "source_and_measurement_claims": "passed", "original_dataset_hash_unchanged": True}
(DEST / "verification.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps(report))
