"""Execution capture: prepare the user's existing CSV for the numeric-only demo."""

import csv
import hashlib
import io
import json
import random
import subprocess
from collections import Counter, defaultdict
from pathlib import Path

from ml_pipeline_pro.config import Settings
from ml_pipeline_pro.datasets import load_dataset
from ml_pipeline_pro.schemas import DatasetDefinition

OUT = Path(__file__).resolve().parent
SOURCE = Path(r"C:\Users\jacob\Downloads\drug200.csv")
raw = SOURCE.read_bytes()
rows = list(csv.DictReader(io.StringIO(raw.decode("utf-8-sig"))))
assert len(rows) == 200
assert list(rows[0]) == ["Age", "Sex", "BP", "Cholesterol", "Na_to_K", "Drug"]

# Fix category vocabularies explicitly; no vocabulary or statistics learned from
# validation/test rows. Use one-hot features rather than impose category ordering.
categories = {"Sex": ["F", "M"], "BP": ["HIGH", "LOW", "NORMAL"], "Cholesterol": ["HIGH", "NORMAL"]}
labels = {name: index for index, name in enumerate(["DrugY", "drugA", "drugB", "drugC", "drugX"])}
features = ["Age", "Na_to_K"] + [f"{name}_{value}" for name, values in categories.items() for value in values]
groups = defaultdict(list)
for index, row in enumerate(rows):
    assert row["Drug"] in labels
    for name, values in categories.items():
        assert row[name] in values
    groups[row["Drug"]].append(index)

# Stratify each class with a fixed seed. Floor train=60%, validation=20%; the
# remainder goes to test. Row rounding gives 117/38/45 for this exact file.
assignments = {}
rng = random.Random(42)
for label in sorted(groups):
    indices = groups[label][:]
    rng.shuffle(indices)
    train_end, validation_end = int(len(indices) * .6), int(len(indices) * .6) + int(len(indices) * .2)
    for offset, index in enumerate(indices):
        assignments[index] = "train" if offset < train_end else "validation" if offset < validation_end else "test"

destination = OUT / "drug200-demo.csv"
with destination.open("w", newline="", encoding="utf-8") as stream:
    writer = csv.DictWriter(stream, fieldnames=[*features, "Drug", "split"], lineterminator="\n")
    writer.writeheader()
    for index, row in enumerate(rows):
        encoded = {"Age": float(row["Age"]), "Na_to_K": float(row["Na_to_K"])}
        encoded.update({f"{name}_{value}": int(row[name] == value) for name, values in categories.items() for value in values})
        writer.writerow({**encoded, "Drug": labels[row["Drug"]], "split": assignments[index]})

loaded = load_dataset(DatasetDefinition(name="drug200_demo", version="v1", uri=destination.name, feature_columns=features, target_column="Drug"), Settings(_env_file=None, dataset_root=OUT))
assert SOURCE.read_bytes() == raw
report = {
    "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
    "source_file": "Downloads/drug200.csv", "source_sha256": hashlib.sha256(raw).hexdigest(),
    "source_rows": len(rows), "source_classes": dict(Counter(row["Drug"] for row in rows)),
    "prepared_file": destination.name, "prepared_sha256": loaded.sha256,
    "feature_columns": features, "target_column": "Drug", "split_column": "split",
    "label_mapping": labels, "fixed_category_vocabularies": categories, "seed": 42,
    "split_method": "Per-class shuffle; floor 60% train, floor 20% validation, remainder test",
    "row_counts": loaded.row_counts,
    "class_counts": {split: dict(Counter(str(value) for value in content.targets)) for split, content in loaded.splits.items()},
    "original_unchanged": True,
    "note": "One educational classification demo. Numeric normalization is fitted by the existing trainer on training rows only. No clinical validation or treatment use.",
}
(OUT / "preparation.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps(report, indent=2))
