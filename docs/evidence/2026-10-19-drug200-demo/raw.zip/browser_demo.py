"""Retained execution harness for actual installed-Chrome controls and API reads."""

import hashlib
import json
import sys
from datetime import UTC, datetime
from pathlib import Path

OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(OUT.parent / "dashboard-implementation"))
import browser_control

browser_control.OUT = OUT
phase = sys.argv[1]
browser = browser_control.Browser(port=9235)
report = {"phase": phase, "started_at": datetime.now(UTC).isoformat(), "steps": []}


def step(name, value=True):
    report["steps"].append({"name": name, "result": value})
    (OUT / f"browser-{phase}.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(name, flush=True)


def fill(values):
    browser.evaluate("(()=>{for(const [id,value] of Object.entries(" + json.dumps(values) + ")){const n=document.getElementById(id);n.value=value;n.dispatchEvent(new Event('input',{bubbles:true}));n.dispatchEvent(new Event('change',{bubbles:true}));}return true})()")


def js(source):
    return browser.evaluate("(async()=>{const {state}=await import('/dashboard/core.js');" + source + "})()")


try:
    browser.navigate("http://127.0.0.1:8000/dashboard/")
    browser.wait("document.querySelector('#service-status').textContent.includes('connected')")
    browser.evaluate("document.querySelector('[data-view=datasets]').click()")
    browser.upload("#dataset-file", Path(r"C:\Users\jacob\Downloads\drug200.csv"))
    browser.wait("document.querySelector('#dataset-features').value.includes('Na_to_K')")
    browser.evaluate("window.uploadRequests=[];window.demoFetch=window.fetch;window.fetch=async function(input,init){if(String(input).startsWith('/api/v1/datasets/upload'))window.uploadRequests.push(String(input));return window.demoFetch(input,init)}")
    fill({"dataset-name": "drug200_demo", "dataset-target": "Drug"})
    columns = browser.evaluate("document.querySelector('#dataset-features').value")
    step("raw_file_target_mapping", columns)
    step("form_before_submission", browser.evaluate("({disabled:document.querySelector('#upload-submit').disabled,valid:document.querySelector('#upload-form').checkValidity(),fields:[...document.querySelector('#upload-form').elements].filter(n=>!n.validity.valid).map(n=>({id:n.id,value:n.value,message:n.validationMessage}))})"))
    if phase == "before":
        assert "Drug" in columns.split(", ")
        browser.evaluate("document.querySelector('#upload-submit').click()")
        browser.wait("document.querySelector('#upload-result').textContent.includes('Dataset columns must be distinct')")
        step("original_failure_reproduced", browser.evaluate("document.querySelector('#upload-result').textContent"))
        step("request_confirmed_target_in_features", browser.evaluate("window.uploadRequests"))
        browser.screenshot("original-failure.png")
    else:
        assert columns == "Age, Sex, BP, Cholesterol, Na_to_K"
        step("target_change_excludes_target")
        fill({"dataset-features": "Age, Na_to_K", "dataset-split": "Age"})
        assert browser.evaluate("document.querySelector('#dataset-features').value") == "Na_to_K"
        step("split_change_preserves_manual_subset")
        fill({"dataset-split": "split", "dataset-features": "Age, Age"})
        browser.evaluate("document.querySelector('#upload-submit').click()")
        browser.wait("document.querySelector('#upload-result').textContent.includes('no duplicates')")
        assert browser.evaluate("window.uploadRequests.length") == 0
        step("duplicate_features_blocked_before_upload")
        fill({"dataset-features": "Age, Drug"})
        browser.evaluate("document.querySelector('#upload-submit').click()")
        assert browser.evaluate("window.uploadRequests.length") == 0
        step("manual_target_overlap_blocked_before_upload")
        fill({"dataset-features": "Age", "dataset-split": "Drug"})
        browser.evaluate("document.querySelector('#upload-submit').click()")
        assert browser.evaluate("window.uploadRequests.length") == 0
        step("same_target_and_split_blocked_before_upload")
        fill({"dataset-split": "split", "dataset-features": "Age, Na_to_K"})
        browser.evaluate("document.querySelector('#upload-submit').click()")
        browser.wait("document.querySelector('#upload-result').textContent.includes('CSV must contain distinct feature, target, and split columns')")
        assert browser.evaluate("window.uploadRequests.length") == 1
        step("raw_csv_still_requires_explicit_split", browser.evaluate("document.querySelector('#upload-result').textContent"))

        # Prepared file retains Drug as the selected target, exercising the
        # original mapping failure at the successful upload boundary.
        browser.upload("#dataset-file", OUT / "drug200-demo.csv")
        browser.wait("document.querySelector('#dataset-features').value.includes('Cholesterol_NORMAL')")
        features = browser.evaluate("document.querySelector('#dataset-features').value.split(', ')")
        assert "Drug" not in features and "split" not in features and len(features) == 9
        browser.evaluate("document.querySelector('#upload-submit').click()")
        browser.wait("document.querySelector('#upload-result').textContent.includes('Dataset verified and saved')")
        browser.wait("(async()=>{const {state}=await import('/dashboard/core.js');return state.datasets.find(d=>d.id===state.selectedDataset)?.name==='drug200_demo'})()")
        dataset = js("return state.datasets.find(d=>d.id===state.selectedDataset)")
        assert dataset["sha256"] == hashlib.sha256((OUT / "drug200-demo.csv").read_bytes()).hexdigest()
        assert dataset["row_counts"] == {"train": 117, "validation": 38, "test": 45}
        report["dataset"] = dataset
        step("prepared_file_uploaded_in_browser", dataset)
        browser.screenshot("drug200-uploaded.png")
        browser.evaluate("document.querySelector('[data-view=runs]').click();document.querySelector('#model-create-open').click()")
        fill({"model-name": "drug200_classifier_" + datetime.now(UTC).strftime("%H%M%S")})
        browser.evaluate("document.querySelector('#model-form button[type=submit]').click()")
        browser.wait("!document.querySelector('#model-dialog').open")
        browser.wait("document.querySelector('#training-model').selectedOptions[0]?.textContent.includes('drug200_classifier_')")
        model = js("return state.models.find(m=>m.id===state.selectedModel)")
        report["model"] = model
        # Use the existing training defaults and selection behavior.
        browser.evaluate("document.querySelector('#train-submit').click()")
        browser.wait("document.querySelector('#review-dialog').open")
        step("reviewed_training", browser.evaluate("document.querySelector('#review-content').textContent"))
        browser.evaluate("document.querySelector('#review-confirm').click()")
        browser.wait("document.querySelector('#run-detail').textContent.includes('Register this completed model version')", seconds=90)
        run = js("return state.experiments.find(r=>r.dataset_id===" + json.dumps(dataset["id"]) + "&&r.model_id===" + json.dumps(model["id"]) + ")")
        assert run["status"] == "succeeded" and run["test_evaluated"]
        report["training"] = run
        step("real_worker_completed_training", run)
        artifacts = []
        for artifact in run["artifacts"]:
            content = browser.client.get(f"http://127.0.0.1:8000/api/v1/experiments/{run['id']}/artifacts/{artifact['name']}", headers={"X-Project-ID": "demo"}).raise_for_status().content
            assert len(content) == artifact["size_bytes"]
            assert hashlib.sha256(content).hexdigest() == artifact["sha256"]
            artifacts.append(artifact)
        step("artifact_hash_and_size_verified", artifacts)
        browser.screenshot("drug200-trained.png")
        browser.evaluate("document.querySelector('#run-detail form button[type=submit]').click()")
        browser.wait("document.querySelector('#global-message').textContent.includes('Model version registered')")
        version = js("return state.versions.find(v=>v.id===state.selectedVersion)")
        report["version"] = version
        step("registered_completed_model", version)
        browser.command("Page.reload", {"ignoreCache": True})
        browser.wait("document.querySelector('#service-status')?.textContent.includes('connected')")
        assert js("return state.datasets.some(d=>d.id===" + json.dumps(dataset["id"]) + ")")
        assert js("return state.experiments.some(r=>r.id===" + json.dumps(run["id"]) + ")")
        step("saved_records_survive_reload")
        assert not browser.events
    report["status"] = "passed"
except Exception as exc:
    report["status"] = "failed"
    report["error"] = {"type": type(exc).__name__, "message": str(exc)}
    browser.screenshot(f"{phase}-failure.png")
    raise
finally:
    report["page_exceptions"] = browser.events
    report["finished_at"] = datetime.now(UTC).isoformat()
    (OUT / f"browser-{phase}.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    browser.close()
