"""Retain safe execution evidence without copying the user's source/prepared rows."""

import hashlib
import json
import shutil
import zipfile
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
DEST = ROOT / "docs/evidence/2026-10-19-drug200-demo"
DEST.mkdir(exist_ok=True, parents=True)
included = [
    "prepare.py", "browser_demo.py", "browser_inspection.py", "archive.py", "verify.py",
    "preparation.json", "browser-before.json", "browser-after.json",
    "browser-inspection.json", "browser-graphs.json", "workload.json",
    "fast.log", "fast.junit.xml", "sync.log", "lint.log", "format.log",
    "dependencies.log", "package-build.log", "package-verification.json",
    "image-build.log", "deploy.log", "original-failure.png", "inspection-failure.png",
]
files = {name: (OUT / name).read_bytes() for name in included}
files["browser_control.py"] = (OUT.parent / "dashboard-implementation/browser_control.py").read_bytes()
files["workspace.js"] = (ROOT / "src/ml_pipeline_pro/dashboard/workspace.js").read_bytes()
files["source-baseline.txt"] = b"14c62f85d991d2a5bf7c72947e3812550eece493\n"
manifest = {name: {"sha256": hashlib.sha256(content).hexdigest(), "size_bytes": len(content)} for name, content in files.items()}
(DEST / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
with zipfile.ZipFile(DEST / "raw.zip", "w", zipfile.ZIP_DEFLATED) as archive:
    for name, content in files.items():
        archive.writestr(name, content)
    archive.writestr("manifest.json", json.dumps(manifest, indent=2) + "\n")
for original, copy in [("drug200-trained.png", "training.png"), ("drug200-agent.png", "agent.png"), ("drug200-monitoring.png", "monitoring.png")]:
    shutil.copyfile(OUT / original, DEST / copy)

before = json.loads((OUT / "browser-before.json").read_text())
after = json.loads((OUT / "browser-after.json").read_text())
graphs = json.loads((OUT / "browser-graphs.json").read_text())
inspection = json.loads((OUT / "browser-inspection.json").read_text())
assert before["status"] == after["status"] == graphs["status"] == "passed"
agent_turn = inspection["steps"][0]["details"]
assert agent_turn["status"] == "completed" and agent_turn["facts"][0]["value"] == 1
result = {
    "captured_at": datetime.now(UTC).isoformat(),
    "source_baseline": "14c62f85d991d2a5bf7c72947e3812550eece493",
    "model_api_image": "sha256:1947f9c3658622d1a908efe9b7f5fd8db5df5c1f56cd9199074c67e6a23154d5",
    "workspace_js_sha256": manifest["workspace.js"]["sha256"],
    "request_reference": "c7064d87d9e7fc9253bd5cb79a212413",
    "preparation": json.loads((OUT / "preparation.json").read_text()),
    "dataset": after["dataset"], "model": after["model"], "training": after["training"], "version": after["version"],
    "baseline_browser_reproduced": before["status"], "corrected_browser_demo": after["status"],
    "agent_inspection": {"status": agent_turn["status"], "conversation_id": agent_turn["conversation_id"], "facts": agent_turn["facts"], "model": agent_turn.get("execution", {})},
    "initial_graph_capture": {"status": inspection["status"], "failure": inspection["error"], "cause": "lazy iframes not scrolled into view"},
    "corrected_graph_capture": graphs["status"],
    "fast_checks": {"passed": 684, "integration_deselected": 85, "selected_skips": 0, "seconds": 52.15, "coverage_rounded_percent": 81},
    "lint_format_dependencies_locked_sync": "passed", "package_build": "passed",
    "full_ordinary_and_recovery_suites": "not rerun; actual upload-to-worker demo exercised",
    "review": "implementing-assistant self-review; no independent review",
    "raw_archive_sha256": hashlib.sha256((DEST / "raw.zip").read_bytes()).hexdigest(),
    "git_push": "reported in final session handoff after this capture",
}
(DEST / "results.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"archive_members": len(files) + 1, "archive_bytes": (DEST / "raw.zip").stat().st_size, "raw_sha256": result["raw_archive_sha256"]}))
