﻿import json
from datetime import UTC,datetime
from browser_control import Browser,OUT
backend=json.loads((OUT/json.loads((OUT/'backend-latest.json').read_text())['path']).read_text());b=Browser(port=9229);report={'started_at':datetime.now(UTC).isoformat()}
try:
 b.navigate('http://127.0.0.1:8000/dashboard/');b.wait("document.querySelector('#service-status')?.textContent.includes('connected')")
 b.evaluate("(()=>{const row=[...document.querySelectorAll('#runs-body tr')].find(n=>n.textContent.includes("+json.dumps(backend['training']['id'][:8])+"));if(!row)throw Error('Run missing');row.querySelector('button').click()})()")
 b.wait("[...document.querySelectorAll('#run-detail button')].some(n=>n.textContent==='Compare validation results')")
 b.evaluate("[...document.querySelectorAll('#run-detail button')].find(n=>n.textContent==='Compare validation results').click()")
 b.wait("document.querySelector('#review-dialog').open")
 comparison=b.evaluate("document.querySelector('#review-content').textContent");assert backend['training']['id'] in comparison and 'Best validation record' in comparison
 report['comparison']=comparison
 b.evaluate("document.querySelector('#review-dialog [data-close-dialog]').click()")
 b.evaluate("[...document.querySelectorAll('#tuning-list button')].find(n=>n.textContent==='Inspect trials').click()")
 b.wait("document.querySelector('#review-dialog').open")
 trials=b.evaluate("document.querySelector('#review-content').textContent");assert 'Trial 0' in trials and 'undefined' not in trials
 report['trials']=trials;assert not b.events,b.events;report['status']='passed'
except Exception as e:report['status']='failed';report['failure']=str(e);raise
finally:report['page_exceptions']=b.events;(OUT/'browser-comparison-trials.json').write_text(json.dumps(report,indent=2)+'\n');b.close()
