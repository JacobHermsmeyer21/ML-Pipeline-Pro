﻿import json,time
from datetime import UTC,datetime
from browser_control import Browser,OUT
ids=json.loads((OUT/'monitor-ids.json').read_text(encoding='utf-8-sig'));b=Browser(port=9228);report={'started_at':datetime.now(UTC).isoformat()}
try:
 b.navigate('http://127.0.0.1:8000/dashboard/');b.wait("document.querySelector('#service-status')?.textContent.includes('connected')")
 b.evaluate("(()=>{const n=document.querySelector('#training-model');n.value="+json.dumps(ids['model_id'])+";n.dispatchEvent(new Event('change',{bubbles:true}))})()")
 b.wait("(async()=>{const {state}=await import('/dashboard/core.js');return state.selectedVersion==="+json.dumps(ids['version_id'])+"})()")
 b.evaluate("document.querySelector('[data-view=monitoring]').click()")
 b.wait("!document.querySelector('#diagnose-button').disabled")
 b.evaluate("window.diagnosisFetch=window.fetch;window.fetch=async function(input,init){const started=performance.now();const response=await window.diagnosisFetch(input,init);if(String(input).endsWith('/diagnosis'))window.diagnosisEvidence={response:await response.clone().json(),status:response.status,elapsed_seconds:(performance.now()-started)/1000};return response}")
 b.evaluate("document.querySelector('#diagnose-button').click()")
 b.wait("document.querySelector('#diagnosis-result').textContent.includes('AI interpretation')",seconds=95)
 report['http']=b.evaluate('window.diagnosisEvidence');assert report['http']['status']==200 and report['http']['elapsed_seconds']<=90
 report['visible']=b.evaluate("document.querySelector('#diagnosis-result').textContent");assert report['http']['response']['automatic_changes'] is False
 b.screenshot('monitoring-diagnosis.png');report['status']='passed'
except Exception as e:
 report['status']='failed';report['failure']=str(e);raise
finally:
 report['page_exceptions']=b.events;(OUT/'browser-diagnosis.json').write_text(json.dumps(report,indent=2)+'\n');b.close()
