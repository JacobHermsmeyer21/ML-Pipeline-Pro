﻿import json
from browser_control import Browser,OUT
b=Browser(port=9233);report={'viewports':[]}
try:
 b.navigate('http://127.0.0.1:8000/dashboard/');b.command('Page.bringToFront');b.wait("document.querySelector('#service-status')?.textContent.includes('connected')")
 for width,height in [(1440,900),(1280,800)]:
  b.command('Emulation.setDeviceMetricsOverride',{'width':width,'height':height,'deviceScaleFactor':1,'mobile':False})
  data=b.evaluate("({width:innerWidth,height:innerHeight,overflow:document.documentElement.scrollWidth>innerWidth,dataset:document.querySelector('#training-dataset').getBoundingClientRect().toJSON(),model:document.querySelector('#training-model').getBoundingClientRect().toJSON()})")
  assert not data['overflow'] and abs(data['dataset']['top']-data['model']['top'])<=2,data
  assert data['model']['left']>=data['dataset']['right'],data
  b.screenshot(f'workspace-live-{width}.png');report['viewports'].append(data)
 assert not b.events,b.events;report['page_exceptions']=b.events;report['status']='passed';print(json.dumps(report,indent=2))
finally:
 (OUT/'browser-layout-final.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');b.close()
