﻿"""Browser project-switch races, unavailable services, credentials and keyboard checks."""
import json
from datetime import UTC,datetime
from browser_control import Browser,OUT

stamp=datetime.now(UTC).strftime('%Y%m%dT%H%M%S');evidence=OUT/('browser-resilience-'+stamp+'.json')
report={'started_at':datetime.now(UTC).isoformat(),'steps':[]};b=Browser(port=9227)
def js(source):return b.evaluate("(async()=>{const {state}=await import('/dashboard/core.js');"+source+"})()")
def step(name,details=None):
 report['steps'].append({'step':name,'details':details});evidence.write_text(json.dumps(report,indent=2)+'\n');print(name,flush=True)
def connect(project,key=''):
 b.evaluate("document.querySelector('#connection-open').click()")
 b.evaluate("document.querySelector('#connection-project').value="+json.dumps(project)+";document.querySelector('#connection-key').value="+json.dumps(key)+";document.querySelector('#connection-form button[type=submit]').click()")
try:
 b.navigate('http://127.0.0.1:8000/dashboard/');b.wait("document.querySelector('#service-status')?.textContent.includes('connected')")
 assert js('return state.datasets.length')>0
 b.evaluate("window.baseFetch=window.fetch;window.delayOldRead=true;window.oldReadStarted=false;window.oldReadFinished=false;window.newProjectReads=0;window.simulatedOffline=false;window.fetch=async function(input,init){if(window.simulatedOffline&&String(input).startsWith('/api/v1/')&&init?.method==='GET')throw new TypeError('Deliberate unavailable-service check');if(init?.headers?.['X-Project-ID']!=='demo')window.newProjectReads++;const response=await window.baseFetch(input,init);if(window.delayOldRead&&String(input).startsWith('/api/v1/datasets?')&&init?.headers?.['X-Project-ID']==='demo'){window.delayOldRead=false;window.oldReadStarted=true;await new Promise(resolve=>setTimeout(resolve,1200));window.oldReadFinished=true;}return response}")
 b.evaluate("document.querySelector('#refresh-runs').click()")
 b.wait('window.oldReadStarted')
 empty_project='browser_empty_'+stamp;connect(empty_project)
 b.wait('window.oldReadFinished&&window.newProjectReads>=4')
 b.wait("(async()=>{const {state}=await import('/dashboard/core.js');return !state.loading&&state.project==="+json.dumps(empty_project)+"})()")
 assert js('return state.datasets.length===0&&state.models.length===0&&state.experiments.length===0&&state.turns.length===0')
 assert b.evaluate("document.querySelectorAll('#grafana-panels iframe').length===0")
 b.evaluate("document.querySelector('[data-view=monitoring]').click()")
 b.wait("document.querySelector('#grafana-panels').textContent.includes('unavailable in this project')")
 assert b.evaluate("document.querySelectorAll('#grafana-panels iframe').length===0")
 step('late_old_project_reply_cannot_populate_new_workspace',{'project':empty_project,'empty_records':True,'foreign_graphs':False})
 sentinel='browser-only-dummy-key-'+stamp;connect('demo',sentinel)
 b.wait("(async()=>{const {state}=await import('/dashboard/core.js');return !state.loading&&state.datasets.length>0})()")
 assert js('return state.key=== '+json.dumps(sentinel))
 snapshot=b.evaluate("({url:location.href,storage:JSON.stringify({...localStorage,...sessionStorage}),visible:document.body.innerText,keyField:document.querySelector('#connection-key').value})")
 assert all(sentinel not in value for value in snapshot.values())
 step('key_stays_in_page_memory_out_of_storage_url_and_visible_dom',{'persistent_storage_contains_key':False})
 b.evaluate('window.simulatedOffline=true;document.querySelector(\'#refresh-runs\').click()')
 b.wait("document.querySelector('#service-status').textContent.includes('unavailable')")
 assert 'Deliberate unavailable-service check' in b.evaluate("document.querySelector('#global-message').textContent")
 b.screenshot('workspace-unavailable.png')
 b.evaluate('window.simulatedOffline=false;document.querySelector(\'#refresh-runs\').click()')
 b.wait("document.querySelector('#service-status').textContent.includes('connected')")
 step('unavailable_service_visible_and_manual_refresh_recovers')
 b.evaluate('window.beforeDashboardReload=true');b.command('Page.reload',{'ignoreCache':True})
 b.wait("!window.beforeDashboardReload&&document.querySelector('#service-status')?.textContent.includes('connected')")
 assert js("return state.key===''"), 'Key restored after reload'
 step('reload_does_not_restore_key')
 ax=b.command('Accessibility.getFullAXTree')['nodes']
 controls=[{'role':n.get('role',{}).get('value'),'name':n.get('name',{}).get('value','')} for n in ax if not n.get('ignored') and n.get('role',{}).get('value') in ['button','combobox','textbox','link']]
 assert controls and all(n['name'].strip() for n in controls),controls
 b.command('Page.bringToFront')
 b.evaluate("document.querySelector('#connection-open').focus()")
 assert b.evaluate('document.activeElement.id')=='connection-open'
 step('keyboard_focus_before_enter',b.evaluate('({focus:document.activeElement.id,active:document.hasFocus()})'))
 b.command('Input.dispatchKeyEvent',{'type':'keyDown','key':'Enter','code':'Enter','windowsVirtualKeyCode':13,'nativeVirtualKeyCode':13,'text':'\r'})
 b.command('Input.dispatchKeyEvent',{'type':'keyUp','key':'Enter','code':'Enter','windowsVirtualKeyCode':13,'nativeVirtualKeyCode':13,'text':'\r'})
 b.wait("document.querySelector('#connection-dialog').open")
 focused=b.evaluate('document.activeElement.id');assert focused=='connection-project',focused
 b.command('Input.dispatchKeyEvent',{'type':'keyDown','key':'Tab','code':'Tab','windowsVirtualKeyCode':9})
 b.command('Input.dispatchKeyEvent',{'type':'keyUp','key':'Tab','code':'Tab','windowsVirtualKeyCode':9})
 assert b.evaluate('document.activeElement.id')=='connection-key'
 b.command('Input.dispatchKeyEvent',{'type':'keyDown','key':'Escape','code':'Escape','windowsVirtualKeyCode':27})
 b.command('Input.dispatchKeyEvent',{'type':'keyUp','key':'Escape','code':'Escape','windowsVirtualKeyCode':27})
 b.wait("!document.querySelector('#connection-dialog').open")
 step('accessible_control_names_and_keyboard_dialog_flow',{'controls':controls,'initial_dialog_focus':focused})
 assert not b.events,b.events
 report['status']='passed';(OUT/'resilience-latest.json').write_text(json.dumps({'path':evidence.name})+'\n')
except Exception as error:
 report['status']='failed';report['failure']={'type':type(error).__name__,'message':str(error)};b.screenshot('resilience-failure-'+stamp+'.png');raise
finally:
 report['page_exceptions']=b.events;report['finished_at']=datetime.now(UTC).isoformat();evidence.write_text(json.dumps(report,indent=2)+'\n');b.close()
