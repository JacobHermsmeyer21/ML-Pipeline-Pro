﻿"""Fresh version: visible empty panels must pick up new measurements and update summary."""
import json,subprocess,time
from datetime import UTC,datetime
from browser_control import Browser,OUT,ROOT
import httpx
backend=json.loads((OUT/json.loads((OUT/'backend-latest.json').read_text())['path']).read_text());stamp=datetime.now(UTC).strftime('%Y%m%dT%H%M%S');b=Browser(port=9232);report={'started_at':datetime.now(UTC).isoformat()}
def js(source):return b.evaluate("(async()=>{const {state}=await import('/dashboard/core.js');"+source+"})()")
def content(index):
 children=b.command('Page.getFrameTree')['frameTree'].get('childFrames',[])
 if len(children)<=index:return None
 context=b.command('Page.createIsolatedWorld',{'frameId':children[index]['frame']['id'],'worldName':'refresh-boundary'})['executionContextId']
 return b.command('Runtime.evaluate',{'contextId':context,'expression':"({text:document.body.innerText,canvas:document.querySelectorAll('canvas').length})",'returnByValue':True})['result'].get('value')
try:
 b.navigate('http://127.0.0.1:8000/dashboard/');b.command('Page.bringToFront');b.wait("document.querySelector('#service-status')?.textContent.includes('connected')")
 b.evaluate("(()=>{const row=[...document.querySelectorAll('#runs-body tr')].find(n=>n.textContent.includes("+json.dumps(backend['training']['id'][:8])+"));row.querySelector('button').click()})()")
 b.wait("document.querySelector('#run-detail input[name=version]')!==null")
 b.evaluate("document.querySelector('#run-detail input[name=version]').value="+json.dumps('refresh_'+stamp)+";document.querySelector('#run-detail form button[type=submit]').click()")
 b.wait("document.querySelector('#global-message').textContent.includes('Model version registered')")
 version=js('return state.selectedVersion');report['model_id']=backend['model']['id'];report['version_id']=version
 b.evaluate("document.querySelector('[data-view=monitoring]').click()")
 b.wait("document.querySelector('#monitor-summary').textContent.includes('No observations')")
 b.evaluate("document.querySelector('#grafana-panels iframe').scrollIntoView({block:'center'})")
 deadline=time.monotonic()+20
 while time.monotonic()<deadline:
  initial=content(0)
  if initial and 'No data' in initial['text']:break
  time.sleep(.15)
 assert initial and 'No data' in initial['text'],initial
 report['initial_empty']=initial;report['initial_summary']=b.evaluate("document.querySelector('#monitor-summary').textContent")
 compose=['docker','compose','--project-name','mlpp-rx9070-walkthrough-20261014','-f','compose.yaml','-f','compose.services.yaml','-f','compose.monitoring.yaml','-f','compose.ai.yaml','-f','compose.dashboard.yaml']
 result=subprocess.run([*compose,'exec','-T','worker','python','examples/monitor_workload.py','--origin','http://api:8000','--model-id',backend['model']['id'],'--version-id',version,'--output','artifacts/dashboard-refresh-regression.json'],capture_output=True,text=True,timeout=60,cwd=ROOT)
 report['producer']={'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr};assert result.returncode==0
 subprocess.run([*compose,'cp','worker:/app/artifacts/dashboard-refresh-regression.json',str(OUT/('refresh-workload-'+stamp+'.json'))],check=True,capture_output=True,text=True,cwd=ROOT)
 deadline=time.monotonic()+40
 while time.monotonic()<deadline:
  observed=content(0)
  if observed and observed['canvas']>0:break
  time.sleep(.15)
 report['updated_panel']=observed;report['summary_when_graph_updates']=b.evaluate("document.querySelector('#monitor-summary').textContent")
 assert observed and observed['canvas']>0,observed
 b.wait("document.querySelector('#monitor-summary').textContent.includes('20 observations')",seconds=20)
 assert not b.evaluate("document.querySelector('#diagnose-button').disabled")
 report['updated_summary']=b.evaluate("document.querySelector('#monitor-summary').textContent");report['status']='passed';b.screenshot('monitoring-refresh-boundary.png')
except Exception as error:
 report['status']='failed';report['failure']={'type':type(error).__name__,'message':str(error)};b.screenshot('refresh-boundary-failure-'+stamp+'.png');raise
finally:
 report['page_exceptions']=b.events;report['finished_at']=datetime.now(UTC).isoformat();path=OUT/('browser-refresh-boundary-'+stamp+'.json');path.write_text(json.dumps(report,indent=2)+'\n');(OUT/'refresh-boundary-latest.json').write_text(json.dumps({'path':path.name})+'\n');b.close()
