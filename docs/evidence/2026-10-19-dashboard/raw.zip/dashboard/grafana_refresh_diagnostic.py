﻿import json,time
from datetime import UTC,datetime
from browser_control import Browser,OUT
ids=json.loads((OUT/'monitor-ids.json').read_text(encoding='utf-8-sig'));b=Browser(port=9231);report={'started_at':datetime.now(UTC).isoformat(),'queries':[],'visibility':[]}
original=b.command
# Capture query bodies and timestamps only; never request headers.
def command(method,params=None):
 b.sequence+=1;identity=b.sequence;b.socket.send(json.dumps({'id':identity,'method':method,'params':params or {}}))
 while True:
  message=json.loads(b.socket.recv(timeout=30))
  if message.get('method')=='Network.requestWillBeSent' and '/api/ds/query' in message['params']['request']['url']:
   request=message['params']['request'];report['queries'].append({'at':datetime.now(UTC).isoformat(),'url':request['url'],'postData':request.get('postData')})
  if message.get('id')==identity:
   if 'error' in message:raise RuntimeError(str(message['error']))
   return message.get('result',{})
b.command=command
try:
 url='http://127.0.0.1:3000/d-solo/mlpp-workspace?panelId=1&from=now-15m&to=now&refresh=15s&var-model_version_id='+ids['version_id']
 b.navigate(url)
 b.command('Page.bringToFront')
 for phase in ['initial','after_timer']:
  if phase=='after_timer':
   deadline=time.monotonic()+18
   while time.monotonic()<deadline:b.evaluate('document.readyState');time.sleep(.15)
  report['visibility'].append(b.evaluate("({at:Date.now(),hidden:document.hidden,visibility:document.visibilityState,focused:document.hasFocus(),text:document.body.innerText,canvas:document.querySelectorAll('canvas').length,soloFeature:window.grafanaBootData?.settings?.featureToggles?.dashboardSceneSolo})"))
 report['status']='diagnostic_completed';print(json.dumps(report,indent=2))
finally:
 (OUT/'grafana-refresh-diagnostic.json').write_text(json.dumps(report,indent=2)+'\n');b.close()
