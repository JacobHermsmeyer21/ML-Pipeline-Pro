"""Exercise actual dashboard controls, including a lost/invalid training acknowledgement."""

import hashlib
import json
import time
from datetime import UTC, datetime
from pathlib import Path

from browser_control import Browser, OUT, ROOT

identity = datetime.now(UTC).strftime("%Y%m%dT%H%M%S")
evidence = OUT / ("browser-backend-" + identity + ".json")
report = {"started_at": datetime.now(UTC).isoformat(), "steps": [], "injected_fault": "malformed first training acknowledgement after real upstream acceptance"}


def save():
    evidence.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")


def step(name, details=None):
    report["steps"].append({"step": name, "details": details, "at": datetime.now(UTC).isoformat()})
    save()
    print(name, flush=True)


browser = Browser(port=9224)


def js(source):
    return browser.evaluate("(async()=>{const {state}=await import('/dashboard/core.js');" + source + "})()")


def fill(values):
    browser.evaluate("(()=>{for(const [id,value] of Object.entries(" + json.dumps(values) + ")){const n=document.getElementById(id);n.value=value;n.dispatchEvent(new Event('input',{bubbles:true}));n.dispatchEvent(new Event('change',{bubbles:true}));}return true})()")


try:
    browser.command("Browser.setDownloadBehavior", {"behavior": "allow", "downloadPath": str(OUT / ("downloads-" + identity))})
    browser.navigate("http://127.0.0.1:8000/dashboard/")
    browser.wait("document.querySelector('#service-status').textContent.includes('connected')")
    before = js("return state.experiments.length")
    assert not browser.evaluate("document.documentElement.scrollWidth>innerWidth")
    step("connected", {"prior_loaded_experiments": before})
    browser.evaluate("document.querySelector('[data-view=datasets]').click()")
    browser.upload("#dataset-file", ROOT / "examples/data/classification.csv")
    browser.wait("document.querySelector('#dataset-features').value.includes('feature_2')")
    fill({"dataset-name": "dashboard_demo_" + identity, "dataset-version": "v1"})
    browser.evaluate("document.querySelector('#upload-submit').click()")
    browser.wait("document.querySelector('#upload-result').textContent.includes('Dataset verified and saved')")
    browser.wait("(async()=>{const {state}=await import('/dashboard/core.js');return state.datasets.find(d=>d.id===state.selectedDataset)?.name===" + json.dumps("dashboard_demo_" + identity) + "})()")
    dataset = js("return state.datasets.find(d=>d.id===state.selectedDataset)")
    assert dataset["row_counts"] == {"train": 80, "validation": 20, "test": 20}
    assert dataset["sha256"] == hashlib.sha256((ROOT / "examples/data/classification.csv").read_bytes()).hexdigest()
    report["dataset"] = dataset
    step("browser_upload_and_column_mapping", {"dataset_id": dataset["id"], "sha256": dataset["sha256"]})
    browser.screenshot("datasets-live-" + identity + ".png")
    browser.evaluate("document.querySelector('[data-view=runs]').click();document.querySelector('#model-create-open').click()")
    fill({"model-name": "dashboard_classifier_" + identity})
    browser.evaluate("document.querySelector('#model-form button[type=submit]').click()")
    browser.wait("!document.querySelector('#model-dialog').open")
    browser.wait("document.querySelector('#training-model').selectedOptions[0]?.textContent.includes('dashboard_classifier_')")
    model = js("return state.models.find(m=>m.id===state.selectedModel)")
    browser.wait("(async()=>{const {state}=await import('/dashboard/core.js');return state.versionsForModel===state.selectedModel})()")
    assert js("return state.versions.length") == 0, "New model retained another model's versions"
    assert browser.evaluate("document.querySelector('#monitor-version').options.length") == 1
    report["model"] = model
    step("browser_model_creation_and_version_scope", {"model_id": model["id"]})
    browser.evaluate("window.originalTrainingFetch=window.fetch;window.trainingPosts=[];window.droppedTrainingAck=false;window.fetch=async function(input,init){const isTraining=String(input)==='/api/v1/experiments'&&init?.method==='POST';if(isTraining)window.trainingPosts.push({key:init.headers['Idempotency-Key'],body:JSON.parse(init.body)});const response=await window.originalTrainingFetch(input,init);if(isTraining&&!window.droppedTrainingAck){window.droppedTrainingAck=true;window.acceptedTrainingId=(await response.clone().json()).id;return new Response('deliberately malformed acknowledgement',{status:200,headers:{'Content-Type':'application/json'}})}return response}")
    browser.evaluate("document.querySelector('#train-submit').click()")
    browser.wait("document.querySelector('#review-dialog').open")
    review = browser.evaluate("document.querySelector('#review-content').textContent")
    assert dataset["name"] in review and model["name"] in review
    browser.evaluate("const confirm=document.querySelector('#review-confirm');confirm.click();confirm.click()")
    browser.wait("document.querySelector('#training-recovery').hidden===false&&!document.querySelector('#review-dialog').open")
    pending = js("return state.pendingTraining")
    assert pending["unknown"]
    assert browser.evaluate("window.trainingPosts.length") == 1
    assert browser.evaluate("document.querySelector('#train-submit').disabled")
    step("malformed_accepted_training_ack_keeps_original_identity", {"key": pending["key"], "accepted_id": browser.evaluate("window.acceptedTrainingId")})
    browser.evaluate("document.querySelector('#training-recovery button').click()")
    browser.wait("document.querySelector('#training-recovery').hidden===true")
    browser.wait("document.querySelector('#run-detail').textContent.includes('Register this completed model version')", seconds=90)
    posts = browser.evaluate("window.trainingPosts")
    assert len(posts) == 2 and posts[0] == posts[1]
    run_id = browser.evaluate("window.acceptedTrainingId")
    runs = js("return state.experiments.filter(r=>r.dataset_id===" + json.dumps(dataset["id"]) + ")")
    assert len(runs) == 1 and runs[0]["id"] == run_id and runs[0]["status"] == "succeeded"
    run = runs[0]; report["training"] = run
    step("same_submission_replay_and_real_worker_completion", {"id": run_id, "metrics": run["metrics"], "matching_requests": posts})
    browser.evaluate("[...document.querySelectorAll('#run-detail button')].find(n=>n.textContent==='Download model.pt').click()")
    browser.wait("document.querySelector('#global-message').textContent.includes('hash and size verified')")
    artifact = next(item for item in run["artifacts"] if item["name"] == "model.pt")
    downloaded = OUT / ("downloads-" + identity) / "model.pt"
    download_deadline = time.monotonic() + 5
    while not downloaded.is_file() and time.monotonic() < download_deadline:
        time.sleep(.05)
    assert downloaded.is_file() and hashlib.sha256(downloaded.read_bytes()).hexdigest() == artifact["sha256"]
    assert downloaded.stat().st_size == artifact["size_bytes"]
    step("actual_browser_artifact_download_hash_and_size", artifact)
    browser.evaluate("document.querySelector('#run-detail form button[type=submit]').click()")
    browser.wait("document.querySelector('#global-message').textContent.includes('Model version registered')")
    version = js("return state.versions.find(v=>v.id===state.selectedVersion)")
    assert version["experiment_id"] == run_id
    report["version"] = version
    step("browser_model_version_registration", {"version_id": version["id"]})
    browser.evaluate("document.querySelector('[data-view=monitoring]').click()")
    browser.wait("document.querySelector('#monitor-summary').textContent.includes('No observations')")
    assert browser.evaluate("document.querySelector('#diagnose-button').disabled")
    assert browser.evaluate("document.querySelectorAll('#grafana-panels iframe').length") == 3
    step("new_version_empty_monitoring_state", {"message": browser.evaluate("document.querySelector('#monitor-summary').textContent")})
    browser.screenshot("monitoring-empty-" + identity + ".png")
    browser.evaluate("window.beforeDashboardReload=true")
    browser.command("Page.reload", {"ignoreCache": True})
    browser.wait("!window.beforeDashboardReload && document.querySelector('#service-status')?.textContent.includes('connected')")
    assert js("return state.datasets.some(d=>d.id===" + json.dumps(dataset["id"]) + ")")
    assert js("return state.experiments.some(r=>r.id===" + json.dumps(run_id) + ")")
    step("browser_reload_retains_saved_records")
    assert not browser.events, browser.events
    report["status"] = "passed"
    (OUT / "backend-latest.json").write_text(json.dumps({"path": evidence.name}) + "\n")
except Exception as error:
    report["status"] = "failed"
    report["failure"] = {"type": type(error).__name__, "message": str(error)}
    browser.screenshot("backend-failure-" + identity + ".png")
    raise
finally:
    report["page_exceptions"] = browser.events
    report["finished_at"] = datetime.now(UTC).isoformat()
    save()
    browser.close()
