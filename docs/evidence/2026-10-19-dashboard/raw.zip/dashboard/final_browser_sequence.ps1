$ErrorActionPreference = 'Continue'
$browserSteps = @(
    @('browser_backend.py', 'browser-backend-integrated.log'),
    @('browser_agent.py', 'browser-agent-integrated.log')
)
foreach ($browserStep in $browserSteps) {
    & .venv/Scripts/python.exe (Join-Path artifacts/dashboard-implementation $browserStep[0]) *> (Join-Path artifacts/dashboard-implementation $browserStep[1])
    if ($LASTEXITCODE -ne 0) { Get-Content (Join-Path artifacts/dashboard-implementation $browserStep[1]) -Tail 25; exit $LASTEXITCODE }
    Write-Output "$($browserStep[0]) passed"
}
$backendPointer = Get-Content artifacts/dashboard-implementation/backend-latest.json | ConvertFrom-Json
$backendResult = Get-Content (Join-Path artifacts/dashboard-implementation $backendPointer.path) | ConvertFrom-Json
@{model_id=$backendResult.model.id; version_id=$backendResult.version.id} | ConvertTo-Json | Set-Content artifacts/dashboard-implementation/monitor-ids.json -Encoding UTF8
$dashboardCompose = @('compose','--project-name','mlpp-rx9070-walkthrough-20261014','-f','compose.yaml','-f','compose.services.yaml','-f','compose.monitoring.yaml','-f','compose.ai.yaml','-f','compose.dashboard.yaml')
& docker @dashboardCompose exec -T worker python examples/monitor_workload.py --origin http://api:8000 --model-id $backendResult.model.id --version-id $backendResult.version.id --output artifacts/dashboard-workload-20261019.json *> artifacts/dashboard-implementation/workload-integrated.log
if ($LASTEXITCODE -ne 0) { Get-Content artifacts/dashboard-implementation/workload-integrated.log; exit $LASTEXITCODE }
& docker @dashboardCompose cp worker:/app/artifacts/dashboard-workload-20261019.json artifacts/dashboard-implementation/workload-integrated.json
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$browserChecks = @(
    @('browser_graphs.py','browser-graphs-integrated.log'),
    @('browser_diagnosis.py','browser-diagnosis-integrated.log'),
    @('browser_resilience.py','browser-resilience-integrated.log'),
    @('browser_comparison.py','browser-comparison-integrated.log')
)
foreach ($browserCheck in $browserChecks) {
    & .venv/Scripts/python.exe (Join-Path artifacts/dashboard-implementation $browserCheck[0]) *> (Join-Path artifacts/dashboard-implementation $browserCheck[1])
    if ($LASTEXITCODE -ne 0) { Get-Content (Join-Path artifacts/dashboard-implementation $browserCheck[1]) -Tail 25; exit $LASTEXITCODE }
    Write-Output "$($browserCheck[0]) passed"
}
