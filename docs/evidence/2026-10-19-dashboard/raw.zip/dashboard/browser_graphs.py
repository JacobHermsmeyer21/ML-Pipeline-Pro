"""Verify actual embedded Grafana content, Prometheus values and desktop layouts."""
import json
import time
from datetime import UTC, datetime
from browser_control import Browser, OUT
import httpx

backend=json.loads((OUT/json.loads((OUT/'backend-latest.json').read_text())['path']).read_text())
monitored_version=json.loads((OUT/'monitor-ids.json').read_text(encoding='utf-8-sig'))['version_id']
identity=datetime.now(UTC).strftime('%Y%m%dT%H%M%S')
report={'started_at':datetime.now(UTC).isoformat(),'steps':[]}
evidence=OUT/('browser-graphs-'+identity+'.json')
b=Browser(port=9226)
def js(source):
 return b.evaluate("(async()=>{const {state}=await import('/dashboard/core.js');"+source+"})()")
def step(name,value=None):
 report['steps'].append({'step':name,'details':value}); evidence.write_text(json.dumps(report,indent=2)+'\n');print(name,flush=True)
def frame_content(frame):
 context=b.command('Page.createIsolatedWorld',{'frameId':frame['frame']['id'],'worldName':'dashboard-verification'})['executionContextId']
 result=b.command('Runtime.evaluate',{'contextId':context,'expression':"({url:location.href,text:document.body.innerText,canvas:document.querySelectorAll('canvas').length,svg:document.querySelectorAll('svg').length})",'returnByValue':True})
 if 'exceptionDetails' in result: raise RuntimeError(str(result['exceptionDetails']))
 return result['result'].get('value')
try:
 b.navigate('http://127.0.0.1:8000/dashboard/');b.wait("document.querySelector('#service-status')?.textContent.includes('connected')")
 b.evaluate("const n=document.querySelector('#training-model');n.value="+json.dumps(backend['model']['id'])+";n.dispatchEvent(new Event('change',{bubbles:true}))")
 b.wait("(async()=>{const {state}=await import('/dashboard/core.js');return state.versionsForModel===state.selectedModel&&state.selectedVersion==="+json.dumps(monitored_version)+"})()")
 b.evaluate("document.querySelector('[data-view=monitoring]').click()")
 b.wait("document.querySelector('#monitor-summary').textContent.includes('20 observations')")
 assert not b.evaluate("document.querySelector('#diagnose-button').disabled")
 frames=b.evaluate("[...document.querySelectorAll('#grafana-panels iframe')].map(n=>({src:n.src,title:n.title}))")
 assert len(frames)==3 and all('var-model_version_id='+monitored_version in f['src'] for f in frames)
 full_url=b.evaluate("document.querySelector('#grafana-open').href");assert 'var-model_version_id='+monitored_version in full_url and 'from=now-15m' in full_url
 report['full_dashboard_url']=full_url
 step('version_scoped_frames_and_measured_summary',{'frames':frames,'summary':b.evaluate("document.querySelector('#monitor-summary').textContent")})
 with httpx.Client(trust_env=False,timeout=10) as client:
  summary=client.get('http://127.0.0.1:8000/api/v1/monitoring/model-versions/'+monitored_version+'/summary',headers={'X-Project-ID':'demo'}).json()
  assert summary['sample_count']==20 and summary['seeded_count']==5
  prom={};deadline=time.monotonic()+35
  while time.monotonic()<deadline:
   for metric in ['mlpp_workload_mean_latency_ms','mlpp_workload_max_latency_ms','mlpp_workload_labeled_accuracy','mlpp_workload_error_count','mlpp_workload_seeded_count']:
    response=client.get('http://127.0.0.1:9090/api/v1/query',params={'query':metric+'{model_version_id="'+monitored_version+'"}'});response.raise_for_status();prom[metric]=response.json()
   if all(item.get('data',{}).get('result') for item in prom.values()):break
   time.sleep(.2)
  assert all(item['data']['result'] for item in prom.values()),prom
  assert float(prom['mlpp_workload_seeded_count']['data']['result'][0]['value'][1])==5
  assert abs(float(prom['mlpp_workload_max_latency_ms']['data']['result'][0]['value'][1])-summary['max_latency_ms'])<.001
  embed=client.get(frames[0]['src']);embed.raise_for_status();assert 'deny' not in embed.headers.get('X-Frame-Options','').lower()
  csp=client.get('http://127.0.0.1:8000/dashboard/').headers['Content-Security-Policy'];assert 'frame-src http://127.0.0.1:3000' in csp
  dashboard=client.get('http://127.0.0.1:3000/api/dashboards/uid/mlpp-workspace').json()['dashboard']
  assert dashboard['panels'][0]['fieldConfig']['defaults']['custom']['thresholdsStyle']['mode']=='line'
  step('prometheus_matches_saved_observations_and_embedding_headers',{'summary':summary,'prometheus':prom,'embed_status':embed.status_code,'x_frame_options':embed.headers.get('X-Frame-Options'),'parent_csp':csp,'dashboard':dashboard})
 for index in range(3):
  b.evaluate(f"document.querySelectorAll('#grafana-panels iframe')[{index}].scrollIntoView({{block:'center'}})")
  deadline=time.monotonic()+25
  while time.monotonic()<deadline:
   children=b.command('Page.getFrameTree')['frameTree'].get('childFrames',[])
   if len(children)>index and (frame_content(children[index]) or {}).get('canvas',0)>0:break
   time.sleep(.15)
 deadline=time.monotonic()+30;contents=[]
 while time.monotonic()<deadline:
  tree=b.command('Page.getFrameTree')['frameTree'];children=tree.get('childFrames',[])
  contents=[frame_content(frame) for frame in children]
  if len(contents)==3 and all(c and c['canvas']>0 and 'No data' not in c['text'] for c in contents):break
  time.sleep(.2)
 assert len(contents)==3 and all(c['canvas']>0 and 'No data' not in c['text'] for c in contents),contents
 step('three_real_grafana_canvases_render_measured_series',contents)
 b.evaluate("document.querySelector('#grafana-panels').scrollIntoView({block:'start'})")
 b.screenshot('monitoring-live-1440.png')
 b.evaluate("const rangeNode=document.querySelector('#monitor-range');rangeNode.value='1h';rangeNode.dispatchEvent(new Event('change',{bubbles:true}))")
 b.wait("[...document.querySelectorAll('#grafana-panels iframe')].every(n=>n.src.includes('from=now-1h'))")
 assert b.evaluate("document.querySelector('#grafana-open').href.includes('from=now-1h')")
 step('time_range_updates_all_panels')
 b.command('Emulation.setDeviceMetricsOverride',{'width':1280,'height':800,'deviceScaleFactor':1,'mobile':False})
 assert not b.evaluate('document.documentElement.scrollWidth>innerWidth')
 b.screenshot('monitoring-live-1280.png')
 b.evaluate("document.querySelector('[data-view=runs]').click()")
 b.evaluate('window.scrollTo(0,0)')
 b.screenshot('workspace-live-1280.png')
 b.command('Emulation.setDeviceMetricsOverride',{'width':1440,'height':900,'deviceScaleFactor':1,'mobile':False})
 b.screenshot('workspace-live-1440.png')
 step('both_desktop_layouts_no_horizontal_overflow')
 assert not b.events,b.events
 report['status']='passed';(OUT/'graphs-latest.json').write_text(json.dumps({'path':evidence.name})+'\n')
except Exception as error:
 report['status']='failed';report['failure']={'type':type(error).__name__,'message':str(error)};b.screenshot('graphs-failure-'+identity+'.png');raise
finally:
 report['page_exceptions']=b.events;report['finished_at']=datetime.now(UTC).isoformat();evidence.write_text(json.dumps(report,indent=2)+'\n');b.close()
