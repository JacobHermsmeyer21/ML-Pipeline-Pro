"""Use an isolated installed Chrome profile to verify the real local browser workflow."""

import base64
import json
import subprocess
import time
from pathlib import Path

import httpx
from websockets.sync.client import connect

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent


class Browser:
    def __init__(self, *, port=9223, width=1440, height=900):
        self.port = port
        self.profile = OUT / ("browser-" + str(port) + "-" + str(time.time_ns()))
        self.log = (OUT / f"chrome-{port}.log").open("w", encoding="utf-8")
        self.process = subprocess.Popen(
            [
                r"C:\Program Files\Google\Chrome\Application\chrome.exe",
                "--headless=new", "--disable-gpu", "--no-first-run",
                "--no-default-browser-check", "--remote-debugging-address=127.0.0.1",
                f"--remote-debugging-port={port}",
                f"--user-data-dir={self.profile}",
                f"--window-size={width},{height}", "about:blank",
            ],
            stdout=self.log, stderr=subprocess.STDOUT,
            creationflags=subprocess.CREATE_NO_WINDOW,
        )
        self.client = httpx.Client(trust_env=False, timeout=3)
        for _ in range(40):
            try:
                pages = self.client.get(f"http://127.0.0.1:{port}/json/list").json()
                page = next(p for p in pages if p["type"] == "page")
                break
            except (httpx.HTTPError, ValueError, StopIteration):
                time.sleep(.1)
        else:
            raise RuntimeError("Isolated browser did not start")
        self.socket_context = connect(page["webSocketDebuggerUrl"], max_size=32 * 1024 * 1024)
        self.socket = self.socket_context.__enter__()
        self.sequence = 0
        self.events = []
        self.command("Runtime.enable")
        self.command("Page.enable")
        self.command("Network.enable")
        self.command("Emulation.setDeviceMetricsOverride", {
            "width": width, "height": height, "deviceScaleFactor": 1, "mobile": False,
        })

    def command(self, method, params=None):
        self.sequence += 1
        identity = self.sequence
        self.socket.send(json.dumps({"id": identity, "method": method, "params": params or {}}))
        while True:
            message = json.loads(self.socket.recv(timeout=120))
            if message.get("id") == identity:
                if "error" in message:
                    raise RuntimeError(json.dumps(message["error"]))
                return message.get("result", {})
            # Do not archive Network events: request headers can contain project credentials.
            if message.get("method") == "Runtime.exceptionThrown":
                self.events.append(message["params"]["exceptionDetails"])

    def evaluate(self, source):
        result = self.command("Runtime.evaluate", {
            "expression": source, "awaitPromise": True, "returnByValue": True,
            "userGesture": True,
        })
        if "exceptionDetails" in result:
            raise RuntimeError(json.dumps(result["exceptionDetails"]))
        return result.get("result", {}).get("value")

    def navigate(self, url):
        self.command("Page.navigate", {"url": url})
        self.wait("document.readyState === 'complete'", seconds=20)

    def wait(self, condition, *, seconds=30):
        started = time.monotonic()
        while time.monotonic() - started < seconds:
            try:
                if self.evaluate(condition):
                    return
            except RuntimeError as error:
                if not any(text in str(error) for text in ("Execution context was destroyed", "Inspected target navigated or closed", "Cannot find context")):
                    raise
            time.sleep(.15)
        raise TimeoutError("Browser condition did not become true: " + condition)

    def screenshot(self, name):
        image = self.command("Page.captureScreenshot", {"format": "png", "captureBeyondViewport": False})
        (OUT / name).write_bytes(base64.b64decode(image["data"]))

    def upload(self, selector, path):
        document = self.command("DOM.getDocument")
        node = self.command("DOM.querySelector", {"nodeId": document["root"]["nodeId"], "selector": selector})
        self.command("DOM.setFileInputFiles", {"nodeId": node["nodeId"], "files": [str(Path(path).resolve())]})

    def close(self):
        self.socket_context.__exit__(None, None, None)
        self.process.terminate()
        try:
            self.process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            self.process.kill()
            self.process.wait(timeout=5)
        self.client.close()
        self.log.close()


if __name__ == "__main__":
    browser = Browser()
    try:
        browser.navigate("http://127.0.0.1:8000/dashboard/")
        browser.wait("document.querySelector('#service-status').textContent.includes('connected')")
        print(json.dumps(browser.evaluate("({title:document.title, datasets:document.querySelector('#stat-datasets').textContent, experiments:document.querySelector('#stat-runs').textContent, overflow:document.documentElement.scrollWidth>innerWidth})")))
        browser.screenshot("workspace-first-live.png")
        print(json.dumps({"page_exceptions": browser.events}))
    finally:
        browser.close()
