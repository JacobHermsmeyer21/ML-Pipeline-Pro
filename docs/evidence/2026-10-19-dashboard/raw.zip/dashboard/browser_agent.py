﻿"""Real browser chat, lost reply recovery, exact reject/approve and saved Python draft."""
import json
import time
from datetime import UTC, datetime
from browser_control import Browser, OUT

backend = json.loads((OUT / json.loads((OUT / 'backend-latest.json').read_text())['path']).read_text())
identity = datetime.now(UTC).strftime('%Y%m%dT%H%M%S')
evidence = OUT / ('browser-agent-' + identity + '.json')
report = {'started_at': datetime.now(UTC).isoformat(), 'steps': [], 'source_backend': json.loads((OUT / 'backend-latest.json').read_text())['path'], 'model_retries': 0, 'timing_profile': 'default desktop: 20 second model, 60 second turn, 90 second client'}
b = Browser(port=9225)
def js(source):
    return b.evaluate("(async()=>{const {state}=await import('/dashboard/core.js');"+source+"})()")
def save():
    captured = b.evaluate('window.chatOutcomes||[]')
    if captured: report['chat_http'] = captured
    evidence.write_text(json.dumps(report,indent=2)+'\n')
def step(name, value=None):
    report['steps'].append({'step':name,'details':value,'at':datetime.now(UTC).isoformat()}); save(); print(name,flush=True)
def send(prompt):
    b.evaluate("document.querySelector('#chat-input').value="+json.dumps(prompt)+";document.querySelector('#chat-send').click()")
    b.wait("(async()=>{const {state}=await import('/dashboard/core.js');return !state.chatBusy})()",seconds=95)
    turn=js('return state.turns.at(-1)'); step('chat_reply', turn)
    return turn
def action_status(action_id,status):
    return "(async()=>{const {state}=await import('/dashboard/core.js');return state.actions.get("+json.dumps(action_id)+")?.status==="+json.dumps(status)+"})()"
def click_action(text,double=False):
    b.evaluate("(()=>{const n=[...document.querySelectorAll('.action-card button')].find(n=>n.textContent==="+json.dumps(text)+");if(!n||n.disabled)throw Error('Decision button unavailable');n.click();"+('n.click();' if double else '')+"})()")
try:
    b.navigate('http://127.0.0.1:8000/dashboard/'); b.wait("document.querySelector('#service-status')?.textContent.includes('connected')")
    b.evaluate("for(const [id,value] of Object.entries("+json.dumps({'training-dataset':backend['dataset']['id'],'training-model':backend['model']['id']})+")){const n=document.getElementById(id);n.value=value;n.dispatchEvent(new Event('change',{bubbles:true}))}")
    b.evaluate("window.agentFetch=window.fetch;window.chatOutcomes=[];window.chatPosts=[];window.decisionPosts=[];window.dropChatReply=true;window.fetch=async function(input,init){const chat=String(input)==='/api/v1/chat'&&init?.method==='POST';const decision=String(input).endsWith('/decision')&&init?.method==='POST';if(chat)window.chatPosts.push(JSON.parse(init.body));if(decision)window.decisionPosts.push({path:String(input),body:JSON.parse(init.body)});const started=performance.now();const response=await window.agentFetch(input,init);if(chat){window.chatOutcomes.push({status:response.status,elapsed_seconds:(performance.now()-started)/1000,response:await response.clone().json()});if(window.dropChatReply){window.dropChatReply=false;throw new TypeError('Deliberately lost reply after real acceptance')}}return response}")
    prompt=f"Inspect experiment {backend['training']['id']}. Return a verified metrics.validation_f1 fact and guide my next pipeline step in one sentence."
    b.evaluate("document.querySelector('#chat-input').value="+json.dumps(prompt)+";document.querySelector('#chat-send').click()")
    b.wait("(async()=>{const {state}=await import('/dashboard/core.js');return !state.chatBusy&&state.pendingChat?.unknown})()",seconds=95)
    pending=js('return state.pendingChat'); assert not js('return state.conversation')
    step('lost_first_chat_reply_retains_original_request',pending)
    b.evaluate("document.querySelector('#chat-recovery button').click()")
    b.wait("(async()=>{const {state}=await import('/dashboard/core.js');return !state.chatBusy&&!state.pendingChat&&state.turns.length===1})()",seconds=95)
    first=js('return state.turns[0]'); posts=b.evaluate('window.chatPosts'); outcomes=b.evaluate('window.chatOutcomes')
    assert len(posts)==2 and posts[0]==posts[1] and outcomes[0]['response']==outcomes[1]['response']
    assert first['status']=='completed' and any(f['record_id']==backend['training']['id'] for f in first['facts'])
    assert all(o['elapsed_seconds']<=90 for o in outcomes)
    step('explicit_same_turn_replay_no_second_generation',{'turn':first,'identical_requests':posts})
    proposal_prompt=f"Train dataset {backend['dataset']['id']} with model {backend['model']['id']}. Per-trial runtime is 10 seconds. Do not submit it."
    proposed=send(proposal_prompt); action=proposed.get('pending_action')
    assert proposed['status']=='awaiting_confirmation' and action and action['tool']['name']=='create_experiment', proposed
    arguments=action['tool']['arguments']; assert arguments['dataset_id']==backend['dataset']['id'] and arguments['model_id']==backend['model']['id'] and arguments['config']['max_runtime_seconds']==10
    b.wait(action_status(action['action_id'],'pending_confirmation'))
    before=js('return state.experiments.filter(r=>r.dataset_id==='+json.dumps(backend['dataset']['id'])+').length')
    click_action('Reject'); b.wait(action_status(action['action_id'],'rejected'))
    b.wait("(async()=>{const {state}=await import('/dashboard/core.js');return state.mutations===0})()")
    assert js('return state.experiments.filter(r=>r.dataset_id==='+json.dumps(backend['dataset']['id'])+').length')==before
    step('rejected_proposal_creates_no_experiment',{'action_id':action['action_id'],'experiments':before})
    b.evaluate("document.querySelector('#new-chat').click()")
    proposed2=send(proposal_prompt); approved=proposed2.get('pending_action'); assert proposed2['status']=='awaiting_confirmation' and approved
    assert approved['action_id']!=action['action_id']
    b.wait(action_status(approved['action_id'],'pending_confirmation'))
    click_action('Approve action',double=True)
    b.wait(action_status(approved['action_id'],'succeeded'),seconds=40)
    b.wait("(async()=>{const {state}=await import('/dashboard/core.js');return state.mutations===0})()")
    decisions=b.evaluate('window.decisionPosts'); assert len(decisions)==2 and decisions[0]['body']['decision']=='reject' and decisions[1]['body']=={'decision':'approve','arguments_hash':approved['arguments_hash']}
    outcome=js('return state.actions.get('+json.dumps(approved['action_id'])+').outcome')
    approved_run_id=outcome['data']['id']
    b.wait("(async()=>{const {state}=await import('/dashboard/core.js');return state.experiments.find(r=>r.id==="+json.dumps(approved_run_id)+")?.status==='succeeded'})()",seconds=90)
    runs=js('return state.experiments.filter(r=>r.dataset_id==='+json.dumps(backend['dataset']['id'])+')')
    assert len(runs)==before+1
    step('double_click_exact_approval_creates_one_real_completed_run',{'decisions':decisions,'outcome':outcome,'runs':runs})
    b.screenshot('agent-confirmed-'+identity+'.png')
    b.evaluate("document.querySelector('#new-chat').click()")
    draft=send('Generate Python listing experiments, limit 50, offset 0. Do not execute.')
    assert draft['snippet']['status']=='validated' and draft['snippet']['review_required']
    assert 'Never executed here' in b.evaluate("document.querySelector('.snippet-card').textContent")
    b.screenshot('agent-draft-'+identity+'.png')
    b.evaluate('window.beforeDashboardReload=true'); b.command('Page.reload',{'ignoreCache':True})
    b.wait("!window.beforeDashboardReload&&document.querySelector('#service-status')?.textContent.includes('connected')")
    b.wait("document.querySelector('.snippet-card')?.textContent.includes('Never executed here')")
    restored=js('return state.turns'); assert restored[0]['turn_id']==draft['turn_id']
    step('reload_restores_saved_python_draft_and_review_requirement',{'turn_id':draft['turn_id']})
    assert not b.events,b.events
    report['status']='passed'; (OUT/'agent-latest.json').write_text(json.dumps({'path':evidence.name})+'\n')
except Exception as error:
    report['status']='failed'; report['failure']={'type':type(error).__name__,'message':str(error)}
    b.screenshot('agent-failure-'+identity+'.png'); raise
finally:
    report['page_exceptions']=b.events; report['finished_at']=datetime.now(UTC).isoformat(); save(); b.close()
