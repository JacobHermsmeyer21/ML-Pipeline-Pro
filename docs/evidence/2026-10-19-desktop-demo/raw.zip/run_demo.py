"""Capture existing demo commands without altering their acceptance conditions."""

import ctypes
import hashlib
import json
import os
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path

root = Path(__file__).resolve().parents[2]
os.chdir(root)
output = Path(__file__).resolve().parent
model = "mlpp-qwen2.5:7b-instruct-q4_K_M-json-tools-v1"
env = os.environ.copy()
env.update(MLPP_RUN_LOCAL_MODEL_EVAL="1", MLPP_CHAT_PROTOCOL="guided")
report = {
    "started_at": datetime.now(UTC).isoformat(),
    "revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
    "profile": "default",
    "code_execution": False,
    "commands": [],
    "source_hashes": {
        str(path).replace("\\", "/"): hashlib.sha256(path.read_bytes()).hexdigest()
        for pattern in ("src/ml_pipeline_pro/*.py", "examples/*.py", "evaluations/*.py")
        for path in root.glob(pattern)
    },
}


def save():
    (output / "execution.json").write_text(json.dumps(report, indent=2) + "\n")


def run(name, args):
    item = {"name": name, "args": args, "started_at": datetime.now(UTC).isoformat()}
    report["commands"].append(item)
    save()
    started = time.monotonic()
    print("Starting " + name, flush=True)
    with (output / (name + ".log")).open("w", encoding="utf-8") as log:
        result = subprocess.run([sys.executable, *args], env=env, stdout=log, stderr=subprocess.STDOUT)
    item.update(exit_code=result.returncode, elapsed_seconds=time.monotonic() - started)
    save()
    print(f"Finished {name}: exit {result.returncode}, {item['elapsed_seconds']:.3f}s", flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)


if not ctypes.windll.kernel32.SetThreadExecutionState(0x80000001):
    raise RuntimeError("Could not hold system awake for the demo")
try:
    run("warmup", ["examples/warm_local_model.py", "--model", model])
    run("conversation-gate", [
        "-m", "pytest", "evaluations/test_conversation_model.py", "--local-model", model,
        "--token-counter", "evaluations.qwen_counter:create_counter", "--eval-output",
        str(output / "conversation.json"), "--junitxml", str(output / "conversation.junit.xml"),
    ])
    run("snippet-gate", [
        "-m", "pytest", "evaluations/test_snippet_model.py", "--local-model", model,
        "--eval-output", str(output / "snippets.json"), "--junitxml",
        str(output / "snippets.junit.xml"),
    ])
    run("demo-warmup", ["examples/warm_local_model.py", "--model", model])
    run("walkthrough", [
        "examples/midterm_walkthrough.py", "--confirm-demo-proposal", "--output",
        str(output / "walkthrough"),
    ])
finally:
    report["finished_at"] = datetime.now(UTC).isoformat()
    save()
    ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
