"""Retain the existing commands' outputs and verify the demo evidence offline."""

import ast
import hashlib
import json
import re
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[2]
local = Path(__file__).resolve().parent
target = root / "docs/evidence/2026-10-19-desktop-demo"


def load(path):
    data = path.read_bytes()
    return json.loads(data.decode("utf-16" if data.startswith((b"\xff\xfe", b"\xfe\xff")) else "utf-8-sig"))


execution = load(local / "execution.json")
conversation = load(local / "conversation.json")
snippets = load(local / "snippets.json")
walkthrough = load(local / "walkthrough/results.json")
workload = load(local / "walkthrough/workload.json")
deployment = load(local / "deployed-source.json")
state = load(local / "final-containers.json")
capture = load(local / "capture-verification.json")
assert all(item["exit_code"] == 0 for item in execution["commands"])
assert conversation["status"] == "passed" and len(conversation["cases"]) == 10
assert all(item["status"] == "passed" for item in conversation["cases"])
assert len(snippets["cases"]) == 7 and all(item["passed"] for item in snippets["cases"])
assert walkthrough["saved_proposal_replay_equal"] and walkthrough["draft_replay_equal"]
assert walkthrough["confirmed_tuning"]["status"] == "succeeded"
assert walkthrough["confirmed_tuning"]["completed_trials"] == 2
assert len(workload["observations"]) == 20 and workload["same_sample_replay_equal"]
assert not walkthrough["code_execution"] and not snippets["code_execution"]
assert len(state) == 10 and all(item["status"] == "running" for item in state)
assert all(item["health"] == "healthy" for item in state if item["health"] is not None)
assert all(item["restart_count"] == 0 for item in state)
for name, digest in execution["source_hashes"].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
for domain in ("model-api", "tuning-api", "monitoring-api"):
    assert deployment[domain]["matches_checkout"]
draft = walkthrough["dialogue"][2]["snippet"]
assert draft["status"] == "validated" and draft["review_required"]
ast.parse(draft["code"])
(target / "generated-draft.txt").write_text(draft["code"], encoding="utf-8")
assert (target / "generated-draft.txt").read_text() == draft["code"]
measurement = walkthrough["monitoring"]["measurements"]
assert measurement["sample_count"] == 21 and measurement["seeded_count"] == 6
assert "inspect_seeded_delay" in walkthrough["monitoring"]["generated_advice"]["proposed_checks"]
issue = load(local / "prometheus-issue-corrected.json")
assert issue["body"]["data"]["result"][0]["value"][1] == "1"
alerts = load(local / "prometheus-alerts-final.json")
assert any(item["state"] == "firing" and item["labels"]["model_version_id"] == measurement["model_version_id"] for item in alerts["data"]["alerts"])
summary = {
    "source_revision": execution["revision"],
    "started_at": execution["started_at"],
    "finished_at": execution["finished_at"],
    "hardware": load(local / "hardware.json"),
    "timing_profile": "default",
    "application_timeouts_seconds": {"model": 20, "turn": 60, "client": 90},
    "fast_tests": {"passed": 647, "integration_deselected": 73, "coverage_percent_rounded": 81, "pytest_seconds": 59.48},
    "conversation_gate": {"scenarios": 10, "all_passed": True, "budget": conversation["budget"]},
    "snippet_gate": {"scenarios": 7, "all_passed": True, "budget": snippets["budget"]},
    "command_results": execution["commands"],
    "walkthrough": {
        "training_id": walkthrough["backend"]["training"]["id"],
        "training_validation_f1": walkthrough["backend"]["training"]["metrics"]["validation_f1"],
        "initial_tuning_trials": walkthrough["backend"]["tuning"]["completed_trials"],
        "confirmed_tuning_trials": walkthrough["confirmed_tuning"]["completed_trials"],
        "proposal_replay_equal": True,
        "draft_replay_equal": True,
        "generated_code_executed": False,
        "measurements": measurement,
        "human_usefulness_review": "not claimed",
    },
    "capture": capture,
    "source_modules_per_domain": len(deployment["model-api"]["files"]),
    "not_rerun": ["ordinary integration suite", "isolated recovery suite", "Kubernetes deployment", "remote CI"],
    "cpu_laptop_acceptance": "unchanged; desktop result is separate",
}

payloads = {}
for path in sorted(local.glob("*")):
    if path.is_file() and path.suffix in (".json", ".xml", ".log", ".py") and path.name not in ("ollama.stderr.log", "ollama.stdout.log"):
        payloads[path.name] = path.read_bytes()
for path in sorted((local / "walkthrough").glob("*.json")):
    payloads["walkthrough/" + path.name] = path.read_bytes()
manifest = {name: {"sha256": hashlib.sha256(data).hexdigest(), "size_bytes": len(data)} for name, data in payloads.items()}
with zipfile.ZipFile(target / "raw.zip", "w", zipfile.ZIP_DEFLATED) as archive:
    for name, data in payloads.items():
        archive.writestr(name, data)
    archive.writestr("manifest.json", json.dumps(manifest, indent=2) + "\n")
with zipfile.ZipFile(target / "raw.zip") as archive:
    assert archive.testzip() is None
    for name, item in manifest.items():
        data = archive.read(name)
        assert hashlib.sha256(data).hexdigest() == item["sha256"]
        if name.endswith(".json"):
            json.loads(data.decode("utf-16" if data.startswith((b"\xff\xfe", b"\xfe\xff")) else "utf-8-sig"))
summary["archive"] = {"file": "raw.zip", "payloads": len(payloads), "sha256": hashlib.sha256((target / "raw.zip").read_bytes()).hexdigest()}
(target / "results.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")

documents = [target / "README.md", target / "human-review.md", root / "docs/guides/midterm-walkthrough.md"]
links = 0
for doc in documents:
    content = doc.read_text(encoding="utf-8")
    for destination in re.findall(r"\]\(([^)]+)\)", content):
        if re.match(r"https?://", destination):
            continue
        filename, _, anchor = destination.partition("#")
        linked = (doc.parent / filename).resolve() if filename else doc
        assert linked.exists(), (doc, destination)
        if anchor:
            headings = re.findall(r"^#+\s+(.+)$", linked.read_text(encoding="utf-8"), re.MULTILINE)
            anchors = [re.sub(r"[^\w\- ]", "", item.lower()).replace(" ", "-") for item in headings]
            assert anchor in anchors, (doc, destination)
        links += 1
verification = {"documents": len(documents), "local_links_and_anchors": links, "payloads_hashed": len(payloads), "source_files_unchanged": len(execution["source_hashes"]), "json_archive_crc_sha256_draft_and_saved_assertions": "passed"}
(target / "verification.json").write_text(json.dumps(verification, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"verification": verification, "archive": summary["archive"]}, indent=2))
