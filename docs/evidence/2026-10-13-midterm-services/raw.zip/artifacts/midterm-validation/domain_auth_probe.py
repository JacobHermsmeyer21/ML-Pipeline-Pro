import json
from pathlib import Path

import httpx

headers = {
    "X-Project-ID": "domain-demo", "X-API-Key": "domain-demo-fixture-key",
    "X-Correlation-ID": "domain-auth-probe",
}
with httpx.Client(base_url="http://127.0.0.1:18001", timeout=10, trust_env=False) as client:
    for path in ("/api/v1/models", "/api/v1/tuning-jobs"):
        denied = client.get(path, headers={**headers, "X-API-Key": "wrong"})
        assert denied.status_code == 403
        assert denied.json()["error"]["correlation_id"] == "domain-auth-probe"
        assert denied.headers["X-Correlation-ID"] == "domain-auth-probe"
        accepted = client.get(path, headers=headers)
        assert accepted.status_code == 200
    model = client.post("/api/v1/models", headers=headers, json={"name": "auth-probe"})
    dataset = client.post("/api/v1/datasets", headers=headers, json={
        "name":"auth-probe", "version":"v1", "uri":"classification.csv",
        "feature_columns":["feature_1","feature_2"],
    })
    assert model.status_code == dataset.status_code == 201
    body = {"model_id":model.json()["id"],"dataset_id":dataset.json()["id"],
            "config":{"epochs":1,"max_runtime_seconds":5},
            "limits":{"max_trials":1,"max_runtime_seconds":20},
            "objective_metric":"validation_f1"}
    submission = {**headers,"Idempotency-Key":"domain-auth-submission"}
    first = client.post("/api/v1/tuning-jobs",headers=submission,json=body)
    second = client.post("/api/v1/tuning-jobs",headers=submission,json=body)
    assert first.status_code == second.status_code == 202
    assert first.json()["id"] == second.json()["id"]
    assert first.headers["X-Correlation-ID"] == "domain-auth-probe"
    altered = {**body,"config":{"epochs":1,"max_runtime_seconds":6}}
    conflict = client.post("/api/v1/tuning-jobs",headers=submission,json=altered)
    assert conflict.status_code == 409 and conflict.json()["error"]["code"] == "idempotency_conflict"
    foreign = {**submission,"X-Project-ID":"domain-foreign","X-API-Key":"domain-foreign-fixture-key"}
    denied_ref = client.post("/api/v1/tuning-jobs",headers=foreign,json=body)
    assert denied_ref.status_code == 404
    assert denied_ref.json()["error"]["code"] == "dataset_not_found"
result={"project_auth_both_domains":True,"same_key_same_id":True,"changed_body_conflict":True,
        "foreign_reference_rejected":True,"correlations_preserved":True,
        "queued_only_no_worker":True,"fixture_credentials":True}
Path("artifacts/midterm-validation/domain-auth.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))
