import ast
import hashlib
import json
import re
import subprocess
import tarfile
import zipfile
from pathlib import Path

from ml_pipeline_pro.config import Settings
from ml_pipeline_pro.main import create_app

root = Path.cwd()
out = root / 'artifacts/a2-validation'
uv = str(root / '.tools/uv/bin/uv.exe')
checks = {
    'sync-final': ['sync','--locked','--extra','training','--offline'],
    'lint-final':['run','--locked','--extra','training','ruff','check','.'],
    'format-final':['run','--locked','--extra','training','ruff','format','--check','.'],
    'pip-check-final':['pip','check'],
    'build-final':['build','--offline'],
}
results = {}
for name, args in checks.items():
    result = subprocess.run([uv, '--cache-dir', '.uv-cache', *args], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (out / (name+'.txt')).write_bytes(result.stdout)
    results[name] = result.returncode
    assert result.returncode == 0, name
result = subprocess.run([str(root / '.venv/Scripts/python.exe'), '.tools/check_methodology_docs.py'], capture_output=True)
(out / 'links-final.txt').write_bytes(result.stdout+result.stderr)
assert result.returncode == 0
results['links'] = json.loads(result.stdout)
documents = [Path('AGENTS.md'), Path('README.md'), Path('PLAN.md'), *Path('docs').rglob('*.md')]
python_count = ps_count = 0
for path in documents:
    for language, content in re.findall(r'^```(\w+)\n(.*?)^```', path.read_text(encoding='utf-8'), re.M|re.S):
        if language == 'python':
            ast.parse(content)
            python_count += 1
        elif language == 'powershell':
            script = out / 'example.ps1'
            script.write_text(content, encoding='utf-8')
            command = "$a2Tokens=$null; $a2Errors=$null; [System.Management.Automation.Language.Parser]::ParseFile('artifacts/a2-validation/example.ps1',[ref]$a2Tokens,[ref]$a2Errors) | Out-Null; if ($a2Errors.Count) { $a2Errors | ForEach-Object { $_.Message }; exit 1 }"
            parsed = subprocess.run(['powershell','-NoProfile','-NonInteractive','-Command',command], capture_output=True)
            assert parsed.returncode == 0, (str(path), parsed.stdout.decode(errors='replace'))
            ps_count += 1
script.unlink(missing_ok=True)
spec = create_app(Settings(_env_file=None)).openapi()
actual = {(method.upper(),re.sub(r'\{[^}]+\}','{id}',path)) for path, methods in spec['paths'].items() for method in methods if method in {'get','post','put','patch','delete'}}
documented = {(method,re.sub(r'\{[^}]+\}','{id}',path)) for method,path in re.findall(r'(GET|POST|PUT|PATCH|DELETE) (/api/v1/[^\s`]+)',Path('docs/reference/api.md').read_text())}
assert actual == documented
wheel = next(Path('dist').glob('*.whl'))
sdist = next(Path('dist').glob('*.tar.gz'))
expected = {p.name for p in Path('src/ml_pipeline_pro').glob('*.py')}
with zipfile.ZipFile(wheel) as archive:
    assert {Path(name).name for name in archive.namelist() if name.startswith('ml_pipeline_pro/') and name.endswith('.py')} == expected
with tarfile.open(sdist) as archive:
    assert not any(set(Path(name).parts) & {'.tools','.venv','.env','artifacts','.git','.uv-cache'} for name in archive.getnames())
results.update(python_examples=python_count, powershell_examples=ps_count, api_operations=len(actual), application_modules=len(expected), packages={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (wheel,sdist)})
(out/'final-checks.json').write_text(json.dumps(results, indent=2),encoding='utf-8')
print(json.dumps(results,indent=2))
