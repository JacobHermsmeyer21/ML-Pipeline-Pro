import hashlib
import importlib.metadata
import json
import platform
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

root = Path.cwd()
source = root/'artifacts/a2-validation'
out = root/'docs/evidence/2026-10-10-a2-snippets'
out.mkdir(parents=True,exist_ok=True)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')

def suite(name):
    suites=ET.parse(source/name).getroot()
    attributes=[item.attrib for item in suites.findall('testsuite')]
    return {key:sum(int(item.get(key,0)) for item in attributes) for key in ('tests','failures','errors','skipped')}

compose=['docker','compose','-p','mlpp-a2-validation','-f','compose.yaml','-f','.tools/validation-compose.yaml']
code="import hashlib,json; from pathlib import Path; import ml_pipeline_pro; p=Path(ml_pipeline_pro.__file__).parent; print(json.dumps({f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in p.glob('*.py')}))"
container=subprocess.run([*compose,'exec','-T','api','python','-c',code],capture_output=True,text=True,check=True)
container_hashes=json.loads(container.stdout)
application={p.name:sha(p) for p in Path('src/ml_pipeline_pro').glob('*.py')}
assert container_hashes==application
write(source/'container-source.json',container_hashes)
ps=subprocess.run([*compose,'ps','--format','json'],capture_output=True,text=True,check=True)
containers=[json.loads(line) for line in ps.stdout.splitlines() if line]
write(source/'containers.json',[{key:item.get(key) for key in ('Name','Service','Image','ID','Health','State')} for item in containers])
final=json.loads((source/'live-complete.json').read_text(encoding='utf-8'))
assert final['source_hashes']=={str(p).replace('\\','/'):sha(p) for p in sorted(Path('src/ml_pipeline_pro').glob('*.py'))}
report={
    'date':'2026-10-10',
    'source_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'native_exits':{'fast-complete':0,'ordinary-final':0,'recovery-final':0,'live':1,'live-refined':1,'live-final':1,'live-complete':1,'diagnostic':0},
    'working_tree':True,
    'platform':platform.platform(),
    'python':platform.python_version(),
    'application_source_sha256':application,
    'support_source_sha256':{str(p).replace('\\','/'):sha(p) for folder in ('tests','evaluations','examples') for p in sorted(Path(folder).rglob('*.py'))},
    'packages':{name:importlib.metadata.version(name) for name in ('langchain-core','langchain-ollama','ollama','pydantic','pymongo','httpx','tokenizers')},
    'model_provenance':final['model_provenance'],
    'fast':suite('fast-complete.xml'),
    'ordinary':suite('ordinary-final.xml'),
    'recovery':suite('recovery-final.xml'),
    'live_runs':{name:{'passed':sum(item['passed'] for item in json.loads((source/(name+'.json')).read_text())['cases']),'scenarios':7,'native_exit':1} for name in ('live','live-refined','live-final','live-complete')},
    'final_live_generation_calls':final['generation_calls'],
    'generation_budget':final['budget'],
    'code_execution':False,
    'original_A1_gate_rerun':False,
    'C7_closed':False,
    'independent_review':'unavailable; implementing-assistant self-review only',
    'human_usefulness_review':'pending',
    'clean_checkout_onboarding':'pending',
    'first_live_run_rejected_code_retained':False,
    'later_live_runs_redacted_model_steps_retained':True,
    'checks':json.loads((source/'final-checks.json').read_text()),
    'evidence_files':{},
}
from coverage import Coverage
coverage=Coverage()
coverage.load()
coverage.json_report(outfile=str(source/'coverage.json'))
report['host_coverage_percent']=json.loads((source/'coverage.json').read_text())['totals']['percent_covered']
recovery_dirs=[p for p in Path('artifacts/recovery-validation').glob('mlpp-recovery-*') if p.is_dir()]
recovery=sorted(recovery_dirs,key=lambda p:p.stat().st_mtime)[-2:]
report['recovery_projects']=[p.name for p in recovery]
files=[p for p in source.iterdir() if p.suffix in ('.json','.xml','.txt')]
files += [p for folder in recovery for p in folder.rglob('*') if p.is_file() and p.suffix in ('.json','.log')]
archive=out/'raw-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as bundle:
    for path in sorted(files):
        name=path.resolve().relative_to(root).as_posix()
        bundle.write(path,name)
        report['evidence_files'][name]=sha(path)
    for path in sorted(Path('.tools').glob('*a2*.py')):
        bundle.write(path,'support/'+path.name)
        report.setdefault('support_scripts_sha256',{})[path.name]=sha(path)
report['raw_archive']={'path':'raw-evidence.zip','sha256':sha(archive),'size_bytes':archive.stat().st_size}
write(out/'results.json',report)
print(json.dumps({key:report[key] for key in ('fast','ordinary','recovery','live_runs','host_coverage_percent','raw_archive')},indent=2))
