import asyncio
import json
from pathlib import Path

from ml_pipeline_pro.config import Settings
from ml_pipeline_pro.conversation_ollama import OllamaConversationModel
from ml_pipeline_pro.conversation_qwen_counter import QwenInputCounter, JSON_TOOLS_TAG
from ml_pipeline_pro.snippet_generation import snippet_messages
from ml_pipeline_pro.snippet_schemas import SnippetRequest
from ml_pipeline_pro.snippet_validation import validate_snippet

async def run():
    settings = Settings(_env_file=None, chat_model=JSON_TOOLS_TAG)
    async with OllamaConversationModel(settings) as inspection:
        counter = QwenInputCounter(inspection.provenance, Path('.tools/local-model-setup/tokenizer.json'))
    value = SnippetRequest(profile='list_experiments', inputs={'limit':50,'offset':0}).normalized()
    async with OllamaConversationModel(settings, count_input_tokens=counter) as native:
        step = await native.generate_snippet(snippet_messages(value, 'Generate a Python integration snippet listing experiments, limit 50, offset 0. Call generate_pipeline_snippet with profile list_experiments and inputs limit 50, offset 0. Do not execute it.'))
        report = {'diagnostic_only':True, 'step':step.model_dump(mode='json'), 'issues':validate_snippet(step.snippet.code, value), 'model_provenance':native.provenance}
    Path('artifacts/a2-validation/diagnostic.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(step.snippet.code)
    print(report['issues'])

asyncio.run(run())
