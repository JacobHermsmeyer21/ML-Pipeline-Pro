import json
from pathlib import Path

from ml_pipeline_pro.config import Settings
from ml_pipeline_pro.conversation_qwen_counter import QwenConversationModel
from ml_pipeline_pro.main import create_app as app_factory

counts={'routing':0,'snippet':0}
def save():
    Path('artifacts/midterm-validation/guided-http-calls.json').write_text(json.dumps(counts))

class Observed(QwenConversationModel):
    async def generate(self,messages):
        counts['routing']+=1
        save()
        return await super().generate(messages)
    async def generate_snippet(self,messages):
        counts['snippet']+=1
        save()
        return await super().generate_snippet(messages)

def create_app():
    save()
    return app_factory(Settings(chat_enabled=True,chat_protocol='guided',
        chat_model='mlpp-qwen2.5:7b-instruct-q4_K_M-json-tools-v1'),
        chat_model_factory=lambda settings:Observed(settings,Path('.tools/local-model-setup/tokenizer.json')))
