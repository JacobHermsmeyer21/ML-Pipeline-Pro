import json
from pathlib import Path
from uuid import uuid4

import httpx

project='midterm-guided-'+uuid4().hex[:10]
with httpx.Client(base_url='http://127.0.0.1:8001',headers={'X-Project-ID':project},
                  timeout=90,trust_env=False,follow_redirects=False) as client:
    body={'request_id':'draft','message':'Generate Python listing experiments, limit 50, offset 0. Do not execute.',
          'expected_revision':0}
    first=client.post('/api/v1/chat',json=body)
    first.raise_for_status()
    turn=first.json()
    assert turn['status']=='completed' and turn['snippet']['status']=='validated'
    assert turn['pending_action'] is None
    before=json.loads(Path('artifacts/midterm-validation/guided-http-calls.json').read_text())
    replay=client.post('/api/v1/chat',json=body)
    replay.raise_for_status()
    assert replay.json()==turn
    after=json.loads(Path('artifacts/midterm-validation/guided-http-calls.json').read_text())
    assert before==after=={'routing':1,'snippet':1}
    history=client.get('/api/v1/conversations/'+turn['conversation_id'])
    history.raise_for_status()
    assert history.json()['turns'][0]['snippet']==turn['snippet']
    foreign=client.get('/api/v1/conversations/'+turn['conversation_id'],headers={'X-Project-ID':'foreign'})
    assert foreign.status_code==404
    experiments=client.get('/api/v1/experiments').json()
    assert experiments['items']==[]
    Path('artifacts/midterm-validation/guided-http.json').write_text(json.dumps({
        'turn':turn,'replay_equal':True,'inference_counts':after,'history':history.json(),
        'foreign_status':foreign.status_code,'experiments':experiments},indent=2)+'\n')
print('Real local-model HTTP draft/replay/history/scope passed; no domain experiment created.')
