"""Read-only repository inventory and evidence checks for the October 18 audit."""

import ast
import hashlib
import json
import re
import subprocess
import zipfile
from pathlib import Path
from urllib.parse import unquote, urlsplit

from ml_pipeline_pro.config import Settings
from ml_pipeline_pro.main import create_model_app, create_monitoring_app, create_tuning_app

ROOT = Path.cwd()
OUT = ROOT / "artifacts/repo-audit-20261018"
OUT.mkdir(parents=True, exist_ok=True)
tracked = subprocess.check_output(["git", "ls-files"], text=True).splitlines()
documents = [ROOT / name for name in tracked if name.endswith(".md")]
documents += [path for path in (ROOT / "docs").rglob("*.md") if path not in documents]


def anchors(path):
    found, counts, fenced = set(), {}, False
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.startswith("```"):
            fenced = not fenced
        if fenced:
            continue
        match = re.match(r"^#{1,6}\s+(.+?)\s*#*\s*$", line)
        if match:
            slug = re.sub(r"[^\w -]", "", match.group(1).lower()).replace(" ", "-")
            count = counts.get(slug, 0)
            counts[slug] = count + 1
            found.add(slug + (f"-{count}" if count else ""))
    return found


errors, ps_blocks, link_count, py_fences = [], [], 0, 0
for document in documents:
    content = document.read_text(encoding="utf-8")
    for target in re.findall(r"\[[^\]]+\]\(([^)]+)\)", content):
        parsed = urlsplit(target.strip("<>"))
        if parsed.scheme or parsed.netloc:
            continue
        dest = (document.parent / unquote(parsed.path)).resolve() if parsed.path else document
        if not dest.exists():
            errors.append(f"Missing target: {document.relative_to(ROOT)} -> {target}")
        elif parsed.fragment and (not dest.is_file() or unquote(parsed.fragment) not in anchors(dest)):
            errors.append(f"Missing anchor: {document.relative_to(ROOT)} -> {target}")
        link_count += 1
    for match in re.finditer(r"^```([^\n]*)\n(.*?)^```", content, re.M | re.S):
        language, code = match.group(1).strip(), match.group(2)
        if language == "python":
            try:
                ast.parse(code)
            except SyntaxError as exc:
                errors.append(f"Python fence: {document.relative_to(ROOT)}: {exc}")
            py_fences += 1
        elif language in {"powershell", "pwsh"}:
            ps_blocks.append({"document": str(document.relative_to(ROOT)), "code": code})

python_files = [ROOT / name for name in tracked if name.endswith(".py")]
for path in python_files:
    ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))

settings = Settings(_env_file=None, environment="test")
factories = [create_model_app, create_tuning_app, create_monitoring_app]
operations = set()
domain_operations = {}
for factory in factories:
    spec = factory(settings).openapi()
    domain = {
        (method.upper(), re.sub(r"\{[^}]+\}", "{id}", path))
        for path, methods in spec["paths"].items()
        for method in methods
        if method in {"get", "post", "put", "patch", "delete"}
    }
    domain_operations[factory.__name__] = len(domain)
    operations |= domain
documented = {
    (method, re.sub(r"\{[^}]+\}", "{id}", path))
    for method, path in re.findall(
        r"(GET|POST|PUT|PATCH|DELETE) (/api/v1/[^\s`]+)",
        (ROOT / "docs/reference/api.md").read_text(encoding="utf-8"),
    )
}
if operations != documented:
    errors.append(f"API inventory mismatch: {sorted(operations ^ documented)}")

archives = []
for path in sorted((ROOT / "docs/evidence").rglob("*.zip")):
    if "2026-10-18-repo-audit" in path.parts:
        continue
    with zipfile.ZipFile(path) as archive:
        bad_member = archive.testzip()
        if bad_member:
            errors.append(f"ZIP CRC failure: {path.relative_to(ROOT)}: {bad_member}")
        archives.append({"path": str(path.relative_to(ROOT)), "members": len(archive.namelist())})

stack = json.loads((ROOT / "deploy/kubernetes/stack.json").read_text())
deployments = []
for item in stack["items"]:
    if item["kind"] != "Deployment":
        continue
    deployments.append({
        "name": item["metadata"]["name"],
        "replicas": item["spec"]["replicas"],
        "containers": [
            {"image": container["image"], "resources": container.get("resources", {}),
             "probes": [key for key in ("startupProbe", "readinessProbe", "livenessProbe") if key in container]}
            for container in item["spec"]["template"]["spec"]["containers"]
        ],
    })

hashes = {
    name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
    for name in tracked
    if name.startswith(("src/", "tests/", "evaluations/", "examples/", "scripts/", "deploy/", ".github/"))
    or name in {"uv.lock", "pyproject.toml", "Dockerfile"}
}
summary = {
    "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
    "documents": len(documents), "local_links_and_anchors": link_count,
    "python_fences": py_fences, "powershell_fences": len(ps_blocks),
    "python_files_parsed": len(python_files),
    "application_modules": len(list((ROOT / "src/ml_pipeline_pro").glob("*.py"))),
    "api_operations": len(operations), "domain_operations": domain_operations,
    "archives": archives, "kubernetes_deployments": deployments, "errors": errors,
}
(OUT / "inventory.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
(OUT / "source-hashes.json").write_text(json.dumps(hashes, indent=2) + "\n", encoding="utf-8")
(OUT / "powershell-fences.json").write_text(json.dumps(ps_blocks), encoding="utf-8")
print(json.dumps({key: value for key, value in summary.items() if key not in {"archives", "kubernetes_deployments"}}, indent=2))
print(f"ZIP CRC checked: {len(archives)}; Kubernetes deployments: {len(deployments)}")
raise SystemExit(bool(errors))
