"""Archive selected public audit results, excluding runtime secrets and snapshots."""

import hashlib
import json
import platform
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

ROOT = Path.cwd()
RUN = ROOT / "artifacts/repo-audit-20261018"
DEST = ROOT / "docs/evidence/2026-10-18-repo-audit"


def read_json(name):
    content = (RUN / name).read_bytes()
    return json.loads(content.decode("utf-16" if content.startswith((b"\xff\xfe", b"\xfe\xff")) else "utf-8-sig"))


def junit(name):
    tree = ET.parse(RUN / name)
    suites = tree.getroot()
    suites = [suites] if suites.tag == "testsuite" else list(suites)
    return {
        key: sum(float(suite.get(key, "0")) for suite in suites)
        for key in ("tests", "failures", "errors", "skipped", "time")
    }


selected = [
    "sync.txt", "lint.txt", "format.txt", "dependencies.txt", "unit.txt", "unit.xml",
    "integration.txt", "integration.xml", "integration-wrong-origin.txt",
    "integration-wrong-origin.xml", "recovery.txt", "recovery.xml", "compose-up.txt", "compose-down.txt",
    "compose-status.json", "routes.json", "smoke.json", "remote-ci.json",
    "remote-ci-jobs.json", "build.txt", "packages.json", "inventory.json",
    "source-hashes.json", "powershell-syntax.json", "workstation-source-match.json",
    "laptop-training-timings.json",
]
for name in selected:
    assert (RUN / name).is_file(), name
tests = {name: junit(name + ".xml") for name in ("unit", "integration", "recovery")}
for name, report in tests.items():
    assert report["failures"] == report["errors"] == report["skipped"] == 0, (name, report)
assert not read_json("inventory.json")["errors"]
assert not read_json("powershell-syntax.json")["errors"]

members = {}
with zipfile.ZipFile(DEST / "raw.zip", "w", zipfile.ZIP_DEFLATED) as archive:
    for name in selected:
        content = (RUN / name).read_bytes()
        archive.writestr(name, content)
        members[name] = hashlib.sha256(content).hexdigest()
    for name in ("repo_audit_20261018.py", "archive_repo_audit_20261018.py"):
        content = (ROOT / ".tools" / name).read_bytes()
        archive.writestr("audit-scripts/" + name, content)
        members["audit-scripts/" + name] = hashlib.sha256(content).hexdigest()
with zipfile.ZipFile(DEST / "raw.zip") as archive:
    assert archive.testzip() is None
    assert all(hashlib.sha256(archive.read(name)).hexdigest() == digest for name, digest in members.items())

results = {
    "audit_date": "2026-10-18",
    "source_revision": "cb67bb8b3937dbf4dbe7fe6ae2c9247ee37849d0",
    "working_branch": "person-a/conversation-foundation",
    "origin_sync_at_start": {"local_only": 0, "upstream_only": 0, "ahead_of_main": 35, "main_only": 0},
    "current_machine": "Ryzen 7 7800X3D / RX 9070 workstation",
    "presentation_target": "CPU laptop, confirmed by Jacob October 18",
    "python": platform.python_version(),
    "uv": subprocess.check_output([str(ROOT / ".tools/uv/bin/uv.exe"), "--version"], text=True).strip(),
    "application_or_test_assertions_changed": False,
    "checks": {"locked_offline_sync": "passed", "ruff_lint": "passed", "ruff_format": "passed", "installed_compatibility": "passed", "pytest": tests},
    "pytest_commands": {
        "unit": "uv run --locked --extra training --offline pytest -m 'not integration' --cov --junitxml=artifacts/repo-audit-20261018/unit.xml --basetemp=artifacts/repo-audit-20261018/pytest-temp",
        "integration": "MLPP_RUN_INTEGRATION=1 MLPP_RUN_WORKER_INTEGRATION=1 MLPP_TEST_API_BASE_URL=http://127.0.0.1:18000/api/v1 MLPP_TEST_MONGODB_URI=mongodb://127.0.0.1:37017/?directConnection=true MLPP_TEST_REDIS_URL=redis://127.0.0.1:16379/0 uv run --locked --extra training --offline pytest -m 'integration and not recovery' --junitxml=artifacts/repo-audit-20261018/integration.xml --basetemp=artifacts/repo-audit-20261018/integration-correct-origin-temp",
        "recovery": "MLPP_RUN_RECOVERY_INTEGRATION=1 uv run --locked --extra training --offline pytest -m recovery --junitxml=artifacts/repo-audit-20261018/recovery.xml --basetemp=artifacts/repo-audit-20261018/recovery-temp",
    },
    "initial_integration_invocation_error": {"api_base_missing_prefix": "/api/v1", "result": junit("integration-wrong-origin.xml"), "corrected_without_test_changes": True},
    "domain_compose": {"project": "mlpp-audit-20261018", "rebuilt": True, "services": 10, "routing": "passed", "actual_backend_smoke": "passed", "smoke_telemetry": "synthetic", "containers_removed_after_audit": True, "volumes_preserved": True},
    "packages": read_json("packages.json"),
    "documentation_and_inventory": read_json("inventory.json"),
    "powershell_syntax": read_json("powershell-syntax.json"),
    "workstation_source_match": read_json("workstation-source-match.json"),
    "historical_laptop_classifier_training": read_json("laptop-training-timings.json"),
    "remote_ci": read_json("remote-ci.json"),
    "limits": ["No new laptop or live-model gate", "No new local Kubernetes rollout; exact baseline remote CI passes", "No new independent review or security-advisory scan", "Classifier timings are historical, exclude service startup, and do not measure Qwen", "Source-package hygiene fails on one nested public .env.example; no private .env, weights or cache contents found", "Not an exhaustive security/concurrency audit"],
    "raw_archive_sha256": hashlib.sha256((DEST / "raw.zip").read_bytes()).hexdigest(),
    "raw_members_sha256": members,
}
(DEST / "results.json").write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"tests": tests, "raw_members": len(members), "raw_bytes": (DEST / "raw.zip").stat().st_size}, indent=2))
