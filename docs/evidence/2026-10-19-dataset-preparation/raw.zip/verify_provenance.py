import hashlib
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
local = Path("src/ml_pipeline_pro")
expected = {p.relative_to(local).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in local.rglob("*.py")}
code = "import json,hashlib;from pathlib import Path;import ml_pipeline_pro;r=Path(ml_pipeline_pro.__file__).parent;print(json.dumps({p.relative_to(r).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in r.rglob('*.py')}))"
report = {"python_source_files": len(expected), "images": {}}
for role in ["model-api", "worker"]:
    container = "mlpp-rx9070-walkthrough-20261014-" + role + "-1"
    result = subprocess.run(["docker", "exec", container, "python", "-c", code], capture_output=True, text=True, check=True)
    actual = json.loads(result.stdout)
    assert actual == expected, role
    image = subprocess.check_output(["docker", "inspect", "--format", "{{.Image}}", container], text=True).strip()
    report["images"][role] = image
    report[role + "_python_matches"] = True
report["api_preparation_js_matches"] = hashlib.sha256(subprocess.check_output(["docker", "exec", "mlpp-rx9070-walkthrough-20261014-model-api-1", "cat", "/app/src/ml_pipeline_pro/dashboard/preparation.js"])).hexdigest() == hashlib.sha256((local / "dashboard/preparation.js").read_bytes()).hexdigest()
assert report["api_preparation_js_matches"]
(OUT / "deployed-source.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report))
