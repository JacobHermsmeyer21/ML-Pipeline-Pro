"""Verify original-file preparation, editable encoding, and real worker training in Chrome."""
import hashlib
import io
import json
import sys
from datetime import UTC, datetime
from pathlib import Path

OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(OUT.parent / "dashboard-implementation"))
import browser_control

browser_control.OUT = OUT
browser = browser_control.Browser(port=9242)
original = Path.home() / "Downloads" / "drug200.csv"
source_sha = hashlib.sha256(original.read_bytes()).hexdigest()
report = {"started_at": datetime.now(UTC).isoformat(), "source_sha256": source_sha, "steps": []}
stamp = datetime.now(UTC).strftime("%H%M%S")


def step(name, result=True):
    report["steps"].append({"name": name, "result": result})
    (OUT / "browser.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(name, flush=True)


def fill(values):
    browser.evaluate("(()=>{for(const [id,value] of Object.entries(" + json.dumps(values) + ")){const n=document.getElementById(id);n.value=value;n.dispatchEvent(new Event('input',{bubbles:true}));n.dispatchEvent(new Event('change',{bubbles:true}));}return true})()")


def js(source):
    return browser.evaluate("(async()=>{const {state}=await import('/dashboard/core.js');" + source + "})()")


def preview():
    browser.evaluate("document.querySelector('#upload-submit').click()")
    browser.wait("!document.querySelector('#prepare-save').disabled && !document.querySelector('#encoding-review').hidden", seconds=90)


def save():
    expected_version = browser.evaluate("document.querySelector('#dataset-version').value")
    browser.evaluate("document.querySelector('#prepare-save').click();document.querySelector('#prepare-save').click()")
    browser.wait("(async()=>{const {state}=await import('/dashboard/core.js');return state.mutations===0 && state.datasets.find(d=>d.id===state.selectedDataset)?.version===" + json.dumps(expected_version) + " && document.querySelector('#upload-result').textContent.includes('Dataset verified and saved')})()", seconds=90)
    return js("return state.datasets.find(d=>d.id===state.selectedDataset)")


try:
    assert source_sha == "10caebf3b055e149ef1e7494042031e510b47ba644f3c304bbb86c428fe89b66"
    browser.navigate("http://127.0.0.1:8000/dashboard/")
    browser.wait("document.querySelector('#service-status').textContent.includes('connected')")
    browser.evaluate("document.querySelector('[data-view=datasets]').click()")
    browser.upload("#dataset-file", original)
    browser.wait("document.querySelector('#dataset-target').value==='Drug'")
    fill({"dataset-name": "drug200_raw", "dataset-version": "raw_" + stamp, "dataset-target": "Drug"})
    assert browser.evaluate("document.querySelector('#dataset-split').value") == ""
    preview()
    summary = browser.evaluate("document.querySelector('#encoding-summary').textContent")
    assert "140 training / 30 validation / 30 test" in summary and "9 encoded features" in summary
    step("original_csv_default_preview", summary)
    browser.evaluate("document.querySelector('#encoding-review').scrollIntoView({block:'start'})")
    browser.screenshot("default-encoding.png")
    dataset = save()
    assert dataset["name"] == "drug200_raw" and dataset["preparation"]["source"]["sha256"] == source_sha
    assert dataset["row_counts"] == {"train": 140, "validation": 30, "test": 30}
    assert len(dataset["feature_columns"]) == 9
    report["dataset"] = dataset
    step("reviewed_default_saved_once", dataset["id"])
    browser.evaluate("document.querySelector('[data-view=runs]').click();document.querySelector('#model-create-open').click()")
    fill({"model-name": "drug200_raw_classifier_" + stamp})
    browser.evaluate("document.querySelector('#model-form button[type=submit]').click()")
    browser.wait("!document.querySelector('#model-dialog').open && document.querySelector('#training-model').selectedOptions[0]?.textContent.includes('drug200_raw_classifier_')")
    model = js("return state.models.find(m=>m.id===state.selectedModel)")
    browser.evaluate("document.querySelector('#train-submit').click()")
    browser.wait("document.querySelector('#review-dialog').open")
    browser.evaluate("document.querySelector('#review-confirm').click();document.querySelector('#review-confirm').click()")
    browser.wait("document.querySelector('#run-detail').textContent.includes('Register this completed model version')", seconds=90)
    run = js("return state.experiments.find(r=>r.dataset_id===" + json.dumps(dataset["id"]) + "&&r.model_id===" + json.dumps(model["id"]) + ")")
    assert run["status"] == "succeeded" and run["test_evaluated"]
    report["training"] = run
    for artifact in run["artifacts"]:
        response = browser.client.get(f"http://127.0.0.1:8000/api/v1/experiments/{run['id']}/artifacts/{artifact['name']}", headers={"X-Project-ID": "demo"}, timeout=15)
        response.raise_for_status()
        assert len(response.content) == artifact["size_bytes"]
        assert hashlib.sha256(response.content).hexdigest() == artifact["sha256"]
        if artifact["name"] == "model.pt":
            import torch
            recipe = torch.load(io.BytesIO(response.content), weights_only=True)["preparation"]
            assert recipe["source_sha256"] == source_sha
            assert recipe["columns"][1]["treatment"] == "one_hot"
    step("raw_file_trained_and_artifact_provenance_verified", run["metrics"])
    browser.screenshot("trained.png")
    browser.evaluate("document.querySelector('#run-detail form button[type=submit]').click()")
    browser.wait("document.querySelector('#global-message').textContent.includes('Model version registered')")
    report["version"] = js("return state.versions.find(v=>v.id===state.selectedVersion)")
    step("trained_model_version_registered")
    browser.evaluate("document.querySelector('[data-view=datasets]').click()")
    fill({"dataset-version": "custom_" + stamp})
    browser.upload("#dataset-file", original)
    browser.wait("document.querySelector('#dataset-target').value==='Drug'")
    preview()
    browser.evaluate("(()=>{const n=document.querySelector('[aria-label=\"Encoding for BP\"]');n.value='mapping';n.dispatchEvent(new Event('change',{bubbles:true}));return true})()")
    assert browser.evaluate("document.querySelector('#prepare-save').disabled")
    for label, value in {"BP: HIGH": 3, "BP: LOW": 1, "BP: NORMAL": 2, "Class ID for DrugY": 4, "Class ID for drugA": 0, "Class ID for drugB": 1, "Class ID for drugC": 2, "Class ID for drugX": 3}.items():
        browser.evaluate("(()=>{const n=document.querySelector('[aria-label=" + json.dumps(label) + "]');n.value=" + str(value) + ";n.dispatchEvent(new Event('input',{bubbles:true}));return true})()")
    preview()
    assert "7 encoded features" in browser.evaluate("document.querySelector('#encoding-summary').textContent")
    browser.evaluate("document.querySelector('#encoding-review').scrollIntoView({block:'start'})")
    browser.screenshot("custom-encoding.png")
    custom = save()
    assert len(custom["feature_columns"]) == 7
    report["custom_dataset"] = custom
    step("user_changed_category_mapping_and_class_ids_then_saved_review", custom["id"])
    # Train the reviewed custom recipe with the same existing model through real controls.
    browser.evaluate("document.querySelector('[data-view=runs]').click()")
    browser.evaluate("document.querySelector('#train-submit').click()")
    browser.wait("document.querySelector('#review-dialog').open")
    browser.evaluate("document.querySelector('#review-confirm').click()")
    browser.wait("(async()=>{const {state}=await import('/dashboard/core.js');return state.experiments.some(r=>r.dataset_id===" + json.dumps(custom["id"]) + "&&r.status==='succeeded')})()", seconds=90)
    custom_run = js("return state.experiments.find(r=>r.dataset_id===" + json.dumps(custom["id"]) + ")")
    manifest = browser.client.get(f"http://127.0.0.1:8000/api/v1/experiments/{custom_run['id']}/artifacts/manifest.json", headers={"X-Project-ID": "demo"}).raise_for_status().json()
    assert manifest["preparation"]["columns"][2]["mapping"] == {"HIGH": 3, "LOW": 1, "NORMAL": 2}
    assert manifest["preparation"]["label_mapping"] == {"DrugY": 4, "drugA": 0, "drugB": 1, "drugC": 2, "drugX": 3}
    report["custom_training"] = custom_run
    step("custom_recipe_trained_without_external_preprocessing")
    browser.command("Page.reload", {"ignoreCache": True})
    browser.wait("document.querySelector('#service-status')?.textContent.includes('connected')")
    assert js("return state.datasets.some(d=>d.id===" + json.dumps(custom["id"]) + ")")
    step("saved_records_survive_reload")
    browser.evaluate("document.querySelector('[data-view=datasets]').click()")
    browser.upload("#dataset-file", original)
    browser.wait("document.querySelector('#dataset-target').value==='Drug'")
    fill({"dataset-name": "preview_only", "dataset-version": "v1"})
    preview()
    browser.command("Emulation.setDeviceMetricsOverride", {"width": 1280, "height": 800, "deviceScaleFactor": 1, "mobile": False})
    browser.evaluate("document.querySelector('#encoding-review').scrollIntoView({block:'start'})")
    assert not browser.evaluate("document.documentElement.scrollWidth>innerWidth")
    browser.screenshot("encoding-1280.png")
    browser.command("Emulation.setDeviceMetricsOverride", {"width": 1440, "height": 900, "deviceScaleFactor": 1, "mobile": False})
    assert not browser.evaluate("document.documentElement.scrollWidth>innerWidth")
    browser.screenshot("encoding-1440.png")
    step("both_desktop_sizes_fit")
    assert not browser.events, browser.events
    assert hashlib.sha256(original.read_bytes()).hexdigest() == source_sha
    report["status"] = "passed"
except Exception as exc:
    report["status"] = "failed"
    report["error"] = {"type": type(exc).__name__, "message": str(exc)}
    browser.screenshot("failure.png")
    raise
finally:
    report["page_exceptions"] = browser.events
    report["finished_at"] = datetime.now(UTC).isoformat()
    (OUT / "browser.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    browser.close()
