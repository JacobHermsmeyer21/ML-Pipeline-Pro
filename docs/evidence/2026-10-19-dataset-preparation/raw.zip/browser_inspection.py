"""Inspect the completed drug200 demo using the local agent and actual graphs."""

import json
import sys
from datetime import UTC, datetime
from pathlib import Path

OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(OUT.parent / "dashboard-implementation"))
import browser_control

browser_control.OUT = OUT
demo = json.loads((OUT / "browser.json").read_text())
graphs_only = "--graphs-only" in sys.argv
report = {"started_at": datetime.now(UTC).isoformat(), "steps": [], "graphs_only": graphs_only}
report_path = OUT / ("browser-graphs.json" if graphs_only else "browser-inspection.json")
b = browser_control.Browser(port=9236)


def step(name, details):
    report["steps"].append({"name": name, "details": details})
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    print(name, flush=True)


def js(source):
    return b.evaluate("(async()=>{const {state}=await import('/dashboard/core.js');" + source + "})()")


try:
    b.navigate("http://127.0.0.1:8000/dashboard/")
    b.wait("document.querySelector('#service-status')?.textContent.includes('connected')")
    values = {"training-dataset": demo["dataset"]["id"], "training-model": demo["training"]["model_id"]}
    b.evaluate("for(const [id,value] of Object.entries(" + json.dumps(values) + ")){const n=document.getElementById(id);n.value=value;n.dispatchEvent(new Event('change',{bubbles:true}))}")
    if not graphs_only:
        b.evaluate("document.querySelector('#new-chat').click()")
        prompt = f"Inspect experiment {demo['training']['id']}. Return a verified metrics.validation_f1 fact and guide my next pipeline step in one sentence."
        b.evaluate("document.querySelector('#chat-input').value=" + json.dumps(prompt) + ";document.querySelector('#chat-send').click()")
        b.wait("(async()=>{const {state}=await import('/dashboard/core.js');return !state.chatBusy&&!state.pendingChat&&state.turns.length===1})()", seconds=95)
        turn = js("return state.turns[0]")
        assert turn["status"] == "completed"
        assert any(f["record_id"] == demo["training"]["id"] for f in turn["facts"])
        assert not turn.get("pending_action")
        step("local_agent_verified_experiment_inspection", turn)
        b.screenshot("drug200-agent.png")
    b.wait("(async()=>{const {state}=await import('/dashboard/core.js');return state.selectedVersion===" + json.dumps(demo["version"]["id"]) + "})()")
    b.evaluate("document.querySelector('[data-view=monitoring]').click()")
    b.wait("document.querySelector('#monitor-summary').textContent.includes('20 observations')")
    b.wait("document.querySelectorAll('#grafana-panels iframe').length===3")
    # Inspect actual iframe rendering; a load event is insufficient evidence.
    import time
    for index in range(3):
        b.evaluate(f"document.querySelectorAll('#grafana-panels iframe')[{index}].scrollIntoView({{block:'center'}})")
        time.sleep(1)
    deadline = time.monotonic() + 45
    while time.monotonic() < deadline:
        frames = b.command("Page.getFrameTree")["frameTree"].get("childFrames", [])
        canvas_counts = []
        for frame in frames:
            frame_id = frame["frame"]["id"]
            world = b.command("Page.createIsolatedWorld", {"frameId": frame_id, "worldName": "drug200-graph-check"})
            result = b.command("Runtime.evaluate", {"expression": "document.body.innerText.includes('No data') ? 0 : document.querySelectorAll('canvas').length", "contextId": world["executionContextId"], "returnByValue": True})
            canvas_counts.append(result["result"].get("value", 0))
        if len(canvas_counts) == 3 and all(count > 0 for count in canvas_counts):
            break
        time.sleep(.5)
    assert len(canvas_counts) == 3 and all(count > 0 for count in canvas_counts), canvas_counts
    step("three_real_grafana_panels_rendered", {"canvases": canvas_counts, "summary": b.evaluate("document.querySelector('#monitor-summary').textContent")})
    queries = {}
    for metric in ["mlpp_workload_labeled_accuracy", "mlpp_workload_seeded_count", "mlpp_workload_max_latency_ms"]:
        query = metric + '{model_version_id="' + demo["version"]["id"] + '"}'
        result = b.client.get("http://127.0.0.1:9090/api/v1/query", params={"query": query}).raise_for_status().json()
        assert result["data"]["result"]
        queries[metric] = result
    assert float(queries["mlpp_workload_seeded_count"]["data"]["result"][0]["value"][1]) == 5
    step("version_specific_prometheus_queries", queries)
    b.screenshot("drug200-monitoring.png")
    assert not b.events
    report["status"] = "passed"
except Exception as exc:
    report["status"] = "failed"
    report["error"] = {"type": type(exc).__name__, "message": str(exc)}
    b.screenshot("inspection-failure.png")
    raise
finally:
    report["finished_at"] = datetime.now(UTC).isoformat()
    report["page_exceptions"] = b.events
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    b.close()
