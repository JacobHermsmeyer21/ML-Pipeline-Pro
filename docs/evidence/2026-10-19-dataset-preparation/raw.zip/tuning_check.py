import hashlib
import json
import time
from pathlib import Path

import httpx

OUT = Path(__file__).resolve().parent
demo = json.loads((OUT / "browser.json").read_text())
body = {
    "dataset_id": demo["custom_dataset"]["id"], "model_id": demo["training"]["model_id"],
    "config": {"epochs": 3, "max_runtime_seconds": 10},
    "limits": {"max_trials": 3, "max_runtime_seconds": 60},
    "search_space": {"learning_rate": {"low": 0.005, "high": 0.02}, "batch_size": {"choices": [8, 16]}, "hidden_units": {"low": 8, "high": 16, "step": 8}},
}
with httpx.Client(base_url="http://127.0.0.1:8000/api/v1", headers={"X-Project-ID": "demo"}, timeout=30) as client:
    response = client.post("/tuning-jobs", json=body, headers={"Idempotency-Key": "prepared-tuning-" + demo["custom_dataset"]["id"]})
    assert response.status_code == 202, response.text
    job = response.json()
    deadline = time.monotonic() + 90
    while time.monotonic() < deadline:
        job = client.get("/tuning-jobs/" + job["id"]).raise_for_status().json()
        if job["status"] not in {"queued", "running"}: break
        time.sleep(.2)
    assert job["status"] == "succeeded" and job["final_evaluation"] == "succeeded", job
    trials = client.get("/tuning-jobs/" + job["id"] + "/trials").raise_for_status().json()["items"]
    assert len(trials) == 3 and all(t["status"] == "succeeded" for t in trials)
    winner = client.get("/experiments/" + job["best_experiment_id"]).raise_for_status().json()
    assert winner["test_evaluated"]
    for artifact in winner["artifacts"]:
        data = client.get(f"/experiments/{winner['id']}/artifacts/{artifact['name']}").raise_for_status().content
        assert len(data) == artifact["size_bytes"] and hashlib.sha256(data).hexdigest() == artifact["sha256"]
        if artifact["name"] == "manifest.json":
            manifest = json.loads(data)
            assert manifest["preparation"]["columns"][2]["mapping"] == {"HIGH": 3, "LOW": 1, "NORMAL": 2}
            assert manifest["preparation"]["label_mapping"]["DrugY"] == 4
    for artifact in demo["training"]["artifacts"]:
        data = client.get(f"/experiments/{demo['training']['id']}/artifacts/{artifact['name']}").raise_for_status().content
        assert len(data) == artifact["size_bytes"] and hashlib.sha256(data).hexdigest() == artifact["sha256"]
    report = {"job": job, "trials": trials, "winner": winner, "original_training_artifacts_preserved": True, "custom_recipe_in_final_manifest": True}
    (OUT / "tuning.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"tuning_id": job["id"], "completed_trials": job["completed_trials"], "final_evaluation": job["final_evaluation"], "recipe_preserved": True}))
