import json
import sys
from datetime import UTC, datetime
from pathlib import Path

OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(OUT.parent / "dashboard-implementation"))
import browser_control

browser_control.OUT = OUT
b = browser_control.Browser(port=9243)
report = {"started_at": datetime.now(UTC).isoformat(), "steps": []}
stamp = datetime.now(UTC).strftime("%H%M%S")


def step(name):
    report["steps"].append(name)
    print(name, flush=True)


def fill(values):
    b.evaluate("for(const [id,value] of Object.entries(" + json.dumps(values) + ")){const n=document.getElementById(id);n.value=value;n.dispatchEvent(new Event('input',{bubbles:true}));n.dispatchEvent(new Event('change',{bubbles:true}));}")


try:
    b.navigate("http://127.0.0.1:8000/dashboard/")
    b.wait("document.querySelector('#service-status').textContent.includes('connected')")
    b.evaluate("document.querySelector('[data-view=datasets]').click()")
    b.evaluate("(async()=>{const {state}=await import('/dashboard/core.js');window.readyConfig=state.config;state.config=null})()")
    b.upload("#dataset-file", Path.home() / "Downloads" / "drug200.csv")
    b.wait("document.querySelector('#dataset-target').value==='Drug'")
    assert not b.evaluate("document.querySelector('#upload-result').textContent.includes('Cannot read')")
    b.evaluate("(async()=>{const {state}=await import('/dashboard/core.js');state.config=window.readyConfig;document.querySelector('#upload-submit').disabled=false})()")
    step("file_selection_before_configuration_arrives_is_safe")
    fill({"dataset-name": "drug200_recovery", "dataset-version": "v_" + stamp})
    b.evaluate("document.querySelector('#upload-submit').click()")
    b.wait("!document.querySelector('#prepare-save').disabled", seconds=90)
    b.evaluate("window.originalFetch=window.fetch;window.saveAttempts=[];window.dropSave=true;window.fetch=async function(url,options){if(String(url)==='/api/v1/datasets/prepare'){window.saveAttempts.push(options.body.get('settings'));const result=await window.originalFetch(url,options);if(window.dropSave){window.dropSave=false;throw new TypeError('Simulated lost save acknowledgement');}return result;}return window.originalFetch(url,options);}")
    b.evaluate("document.querySelector('#prepare-save').click()")
    b.wait("document.querySelector('#prepare-save').textContent.includes('retry same save')&&!document.querySelector('#prepare-save').disabled", seconds=90)
    assert b.evaluate("document.querySelector('#dataset-target').disabled&&document.querySelector('#dataset-file').disabled")
    b.evaluate("document.querySelector('#prepare-save').click()")
    b.wait("document.querySelector('#prepare-save').textContent==='Dataset saved'", seconds=90)
    assert b.evaluate("window.saveAttempts.length===2&&window.saveAttempts[0]===window.saveAttempts[1]")
    b.wait("(async()=>{const {state}=await import('/dashboard/core.js');return state.mutations===0})()")
    step("lost_save_acknowledgement_retries_identical_reviewed_settings")
    b.evaluate("document.querySelector('#prepared-upload').checked=true;document.querySelector('#prepared-upload').dispatchEvent(new Event('change',{bubbles:true}))")
    b.upload("#dataset-file", Path('examples/data/classification.csv'))
    b.wait("document.querySelector('#dataset-features').value==='feature_1, feature_2'")
    fill({"dataset-name": "legacy_browser", "dataset-version": "v_" + stamp})
    b.evaluate("document.querySelector('#upload-submit').click()")
    b.wait("(async()=>{const {state}=await import('/dashboard/core.js');return state.datasets.find(d=>d.id===state.selectedDataset)?.name==='legacy_browser'})()", seconds=45)
    step("legacy_numeric_upload_preserves_existing_contract")
    b.evaluate("document.querySelector('#prepared-upload').checked=false;document.querySelector('#prepared-upload').dispatchEvent(new Event('change',{bubbles:true}))")
    b.upload("#dataset-file", Path.home() / "Downloads" / "drug200.csv")
    b.wait("document.querySelector('#dataset-target').value==='Drug'")
    fill({"dataset-name": "unsaved", "dataset-version": "v1"})
    b.evaluate("window.failPreview=true;window.fetch=async function(url,options){if(String(url)==='/api/v1/datasets/preview'&&window.failPreview)return new Response(JSON.stringify({error:{code:'service_unavailable',message:'Preview unavailable',correlation_id:'ui-test'}}),{status:503,headers:{'Content-Type':'application/json'}});return window.originalFetch(url,options);};document.querySelector('#upload-submit').click()")
    b.wait("document.querySelector('#upload-result').textContent.includes('Preview unavailable')")
    assert b.evaluate("document.querySelector('#prepare-save').disabled")
    step("unavailable_preview_never_enables_save")
    b.evaluate("document.querySelector('#connection-open').click()")
    fill({"connection-project": "empty_preparation_" + stamp})
    b.evaluate("document.querySelector('#connection-form button[type=submit]').click()")
    b.wait("document.querySelector('#project-label').textContent.startsWith('empty_preparation_')")
    assert b.evaluate("document.querySelector('#dataset-file').files.length===0&&document.querySelector('#encoding-review').hidden&&document.querySelector('#encoding-columns').children.length===0&&document.querySelector('#dataset-target').options.length===1")
    step("project_change_clears_raw_file_and_encoding_context")
    assert not b.events, b.events
    report["status"] = "passed"
except Exception as error:
    report["status"] = "failed"
    report["error"] = str(error)
    b.screenshot("boundary-failure.png")
    raise
finally:
    report["finished_at"] = datetime.now(UTC).isoformat()
    report["page_exceptions"] = b.events
    (OUT / "browser-boundaries.json").write_text(json.dumps(report, indent=2) + "\n")
    b.close()
