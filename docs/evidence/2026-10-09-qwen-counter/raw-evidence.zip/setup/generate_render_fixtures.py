import hashlib
import json
from pathlib import Path

import httpx

from ml_pipeline_pro.conversation_qwen_counter import MODEL_TAG, render_qwen_request

root=Path(__file__).resolve().parents[2]
cases=[
    {'messages':[{'role':'system','content':'First.'},{'role':'system','content':'Second.'},{'role':'user','content':'你好 🧪 <tools>&\u2028'}],'tools':[]},
    {'messages':[{'role':'system','content':'Use tools.'},{'role':'user','content':'read'}], 'tools':[{'type':'function','function':{'name':'schema_probe','description':'Inspect <data> & metadata.','parameters':{'type':'object','$defs':{'Config':{'type':'object','properties':{'learning_rate':{'type':'number','default':0.000001},'maximum':{'default':10000000}}}},'required':['key'],'properties':{'key':{'type':['string'],'title':'Dropped title','description':'A <key>&\u2028','default':'ignored'},'choices':{'anyOf':[{'type':'string'},{'type':'null'}],'items':{},'enum':[1.0,1e-7,-0.0]},'nested':{'type':'object','properties':{'z':{'type':'integer'},'a':{'type':'boolean'}},'required':['z']}}}}}]},
    {'messages':[{'role':'system','content':'Use tools.'},{'role':'user','content':'read'},{'role':'assistant','content':'','tool_calls':[{'function':{'name':'get_model','arguments':{'model_id':'a&<b>','limits':[1.0,0.000001,1e-7,-0.0]}}}]},{'role':'tool','content':'{"id":"a&<b>"}'},{'role':'tool','content':'two'},{'role':'assistant','content':'A'},{'role':'assistant','content':'B'},{'role':'user','content':'next'}],'tools':[]},
]
observed=[]
with httpx.Client(base_url='http://127.0.0.1:11434',trust_env=False,follow_redirects=False,timeout=20) as client:
    for case in cases:
        payload={'model':MODEL_TAG,'think':False,'stream':False,'options':{'num_ctx':8192,'num_predict':1},**case}
        response=client.post('/api/chat',json={**payload,'_debug_render_only':True})
        response.raise_for_status()
        expected=response.json()['_debug_info']['rendered_template']
        assert render_qwen_request(payload) == expected
        observed.append({'request':payload,'runtime_rendered_prompt':expected})
target=root/'tests/fixtures/qwen_runtime_render.json'
target.parent.mkdir(parents=True,exist_ok=True)
target.write_bytes((json.dumps({'runtime_version':'0.40.2','provenance':'Observed through local /api/chat _debug_render_only; no generation, only synthetic data.','cases':observed},ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
print(json.dumps({'render_fixtures':len(observed),'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}))
