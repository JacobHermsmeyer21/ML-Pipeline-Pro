import hashlib
import json
import sys
import time
from pathlib import Path

import httpx
from tokenizers import Tokenizer

root = Path(__file__).resolve().parent
project = root.parents[1]
sys.path.insert(0, str(project/'src'))
sys.path.append(str(project/'.venv/Lib/site-packages'))
from ml_pipeline_pro.conversation_model import model_tools
from qwen_counter_candidate import render

tokenizer = Tokenizer.from_file(str(root/'tokenizer.json'))
tokenizer.no_truncation()
tokenizer.no_padding()
messages = [
    [{'role':'system','content':'Use tools.'},{'role':'user','content':'Hello'}],
    [{'role':'system','content':'First.'},{'role':'system','content':'Second.'},{'role':'user','content':'你好 🧪 <tools>&\u2028'}],
    [{'role':'system','content':'Use tools.'},{'role':'user','content':'read'},{'role':'assistant','content':'','tool_calls':[{'function':{'name':'get_model','arguments':{'model_id':'a&<b>','limits':[1.0,0.000001,1e-7,-0.0]}}}]},{'role':'tool','content':'{"id":"a&<b>"}'}],
    [{'role':'system','content':'Use tools.'},{'role':'user','content':'read'},{'role':'assistant','content':'A'},{'role':'assistant','content':'B'},{'role':'user','content':'next'}],
]
cases=[]
with httpx.Client(base_url='http://127.0.0.1:11434',trust_env=False,follow_redirects=False,timeout=120) as client:
    for index, entries in enumerate(messages):
        for tools in ([],model_tools()):
            payload={'model':'qwen2.5:7b-instruct-q4_K_M','messages':entries,'tools':tools,'think':False,'stream':False,'options':{'num_ctx':8192,'num_predict':1}}
            started=time.monotonic()
            response=client.post('/api/chat',json={**payload,'_debug_render_only':True})
            response.raise_for_status()
            runtime=response.json()['_debug_info']['rendered_template']
            candidate=render(payload)
            if runtime != candidate:
                (root/'render-mismatch.json').write_bytes(json.dumps({'runtime':runtime,'candidate':candidate},ensure_ascii=False,indent=2).encode())
            assert runtime == candidate, f'Render mismatch case {index}, tools={bool(tools)}'
            response=client.post('/api/chat',json=payload)
            response.raise_for_status()
            reported=response.json()['prompt_eval_count']
            counted=len(tokenizer.encode(candidate,add_special_tokens=False).ids)
            item={'case':index,'tools':bool(tools),'prompt_sha256':hashlib.sha256(candidate.encode()).hexdigest(),'offline_count':counted,'runtime_count':reported,'elapsed_seconds':time.monotonic()-started}
            cases.append(item)
            print(json.dumps(item),flush=True)
            assert counted == reported, item
(root/'candidate-verification.json').write_bytes((json.dumps(cases,indent=2)+'\n').encode())
