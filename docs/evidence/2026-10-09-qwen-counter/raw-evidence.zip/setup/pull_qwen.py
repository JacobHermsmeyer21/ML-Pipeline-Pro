import json
import sys
import time
from pathlib import Path

import httpx

root = Path(__file__).resolve().parent
tag = sys.argv[1] if len(sys.argv)>1 else 'qwen2.5:7b-instruct-q4_K_M'
output_root = root if len(sys.argv)==1 else root/'qwen14b'
output_root.mkdir(exist_ok=True)
started = time.monotonic()
observed = []
progress_mark = -1
with httpx.Client(base_url='http://127.0.0.1:11434', trust_env=False,
                  follow_redirects=False, timeout=1800) as client:
    with client.stream('POST', '/api/pull', json={'model': tag, 'stream': True}) as response:
        response.raise_for_status()
        for line in response.iter_lines():
            if not line:
                continue
            item = json.loads(line)
            if 'error' in item:
                raise RuntimeError(item['error'])
            mark = item.get('completed', 0) // (256 * 1024 * 1024)
            if mark > progress_mark or 'completed' not in item:
                print(json.dumps(item), flush=True)
                observed.append(item)
                progress_mark = mark
    for name, method, path, body in [
        ('model-tags.json', 'GET', '/api/tags', None),
        ('model-show.json', 'POST', '/api/show', {'model': tag, 'verbose': True}),
        ('runtime-version.json', 'GET', '/api/version', None),
    ]:
        response = client.request(method, path, json=body)
        response.raise_for_status()
        (output_root/name).write_bytes((json.dumps(response.json(), ensure_ascii=False, indent=2)+'\n').encode('utf-8'))
result = {'tag': tag, 'elapsed_seconds': time.monotonic()-started, 'observations': observed}
(output_root/'pull-result.json').write_bytes((json.dumps(result, indent=2)+'\n').encode('utf-8'))
print(json.dumps({'installed_tag': tag, 'elapsed_seconds': result['elapsed_seconds']}))
