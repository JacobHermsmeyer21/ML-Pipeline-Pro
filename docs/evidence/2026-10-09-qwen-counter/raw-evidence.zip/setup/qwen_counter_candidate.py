"""Investigation only: reproduce the pinned Ollama Qwen template offline."""

import copy
import json
import math
from decimal import Decimal

TOOLS_PREFIX = (
    '\n\n# Tools\n\nYou may call one or more functions to assist with the user query.'
    '\n\nYou are provided with function signatures within <tools></tools> XML tags:\n<tools>'
)
TOOLS_SUFFIX = (
    '\n</tools>\n\nFor each function call, return a json object with function name and '
    'arguments within <tool_call></tool_call> XML tags:\n<tool_call>\n'
    '{"name": <function-name>, "arguments": <args-json-object>}\n</tool_call>'
)


def dynamic(value):
    if isinstance(value, dict):
        return {key: dynamic(value[key]) for key in sorted(value)}
    if isinstance(value, list):
        return [dynamic(item) for item in value]
    return value


def go_json(value):
    if isinstance(value, str):
        return (json.dumps(value, ensure_ascii=False).replace('<', '\\u003c')
                .replace('>', '\\u003e').replace('&', '\\u0026')
                .replace('\u2028', '\\u2028').replace('\u2029', '\\u2029'))
    if isinstance(value, dict):
        return '{' + ','.join(go_json(key)+':'+go_json(item) for key, item in value.items()) + '}'
    if isinstance(value, list):
        return '[' + ','.join(go_json(item) for item in value) + ']'
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError('Nonfinite JSON number')
        if value == 0:
            return '-0' if math.copysign(1, value) < 0 else '0'
        text = repr(value)
        if 1e-6 <= abs(value) < 1e21:
            return format(Decimal(text), 'f').rstrip('0').rstrip('.') if '.' in format(Decimal(text), 'f') else format(Decimal(text), 'f')
        mantissa, exponent = text.lower().split('e')
        return mantissa.removesuffix('.0') + 'e' + ('+' if int(exponent) >= 0 else '-') + str(abs(int(exponent)))
    return json.dumps(value, separators=(',', ':'), allow_nan=False)


def property_shape(value):
    result = {}
    for name in ('anyOf', 'type', 'items', 'description', 'enum', 'properties', 'required'):
        item = value.get(name)
        if item is None or (name not in ('items', 'properties') and not item):
            continue
        if name == 'anyOf':
            item = [property_shape(child) for child in item]
        elif name == 'properties':
            item = {key: property_shape(child) for key, child in item.items()}
        elif name == 'type' and isinstance(item, list) and len(item) == 1:
            item = item[0]
        elif name in ('items', 'enum'):
            item = dynamic(item)
        result[name] = item
    return result


def go_value(value):
    if value is None:
        return '<nil>'
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        return 'map[' + ' '.join(key + ':' + go_value(value[key]) for key in sorted(value)) + ']'
    if isinstance(value, list):
        return '[' + ' '.join(go_value(item) for item in value) + ']'
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        value = float(value)
        if value == 0:
            return '-0' if math.copysign(1,value) < 0 else '0'
        if abs(value) < 1e-4 or abs(value) >= 1e6:
            mantissa, exponent = format(Decimal(repr(value)), 'e').split('e')
            return mantissa.rstrip('0').rstrip('.') + 'e' + ('+' if int(exponent)>=0 else '-') + str(abs(int(exponent))).zfill(2)
        return go_json(value)
    return go_json(value)


def function_shape(tool):
    function = tool['function']
    params = function.get('parameters') or {}
    shaped = {'type': params.get('type', '')}
    for name in ('$defs', 'items', 'required'):
        if params.get(name) is not None and (name != 'required' or params[name]):
            shaped[name] = dynamic(params[name])
    properties = params.get('properties')
    shaped['properties'] = (
        {key: property_shape(properties[key]) for key in sorted(properties)}
        if properties is not None else {}
    )
    # Ollama v0.40.2's templateToolFunction is a struct without String().
    # Go therefore renders its fields with fmt's struct representation.
    parameters = ('{' + shaped['type'] + ' ' + go_value(shaped.get('$defs')) + ' '
                  + go_value(shaped.get('items')) + ' ' + go_value(shaped.get('required', []))
                  + ' ' + go_json(shaped['properties']) + '}')
    return '{' + function.get('name', '') + ' ' + function.get('description', '') + ' ' + parameters + '}'


def render(payload):
    messages = copy.deepcopy(payload['messages'])
    if not messages or messages[0]['role'] != 'system':
        raise ValueError('Profile requires explicit initial system instructions')
    if any(message.get('images') or message.get('thinking') for message in messages):
        raise ValueError('Text-only nonthinking profile')
    system = '\n\n'.join(message.get('content', '') for message in messages if message['role'] == 'system')
    collated = []
    for message in messages:
        if collated and collated[-1]['role'] == message['role'] and message['role'] != 'tool':
            collated[-1]['content'] = collated[-1].get('content', '') + '\n\n' + message.get('content', '')
        else:
            collated.append(message)
    tools = payload.get('tools') or []
    output = ''
    if system or tools:
        output = '<|im_start|>system'
        if system:
            output += '\n' + system
        if tools:
            output += TOOLS_PREFIX
            for tool in tools:
                output += '\n{"type": "function", "function": ' + function_shape(tool) + '}'
            output += TOOLS_SUFFIX
        output += '<|im_end|>\n'
    for index, message in enumerate(collated):
        role, content = message['role'], message.get('content', '')
        last = index == len(collated)-1
        if role == 'user':
            output += '<|im_start|>user\n' + content + '<|im_end|>\n'
        elif role == 'assistant':
            output += '<|im_start|>assistant\n'
            if content:
                output += content
            elif message.get('tool_calls'):
                output += '<tool_call>\n'
                for call in message['tool_calls']:
                    function = call['function']
                    output += '{"name": "' + function['name'] + '", "arguments": ' + go_json(dynamic(function['arguments'])) + '}\n'
                output += '</tool_call>'
            if not last:
                output += '<|im_end|>\n'
        elif role == 'tool':
            output += '<|im_start|>user\n<tool_response>\n' + content + '\n</tool_response><|im_end|>\n'
        elif role != 'system':
            raise ValueError('Unsupported message role')
        if role != 'assistant' and last:
            output += '<|im_start|>assistant\n'
    return output
