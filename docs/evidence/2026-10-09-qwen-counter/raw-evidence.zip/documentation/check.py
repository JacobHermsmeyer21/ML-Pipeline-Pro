"""Validate local Markdown links/anchors, Python examples, and API coverage."""

import ast
import json
import posixpath
import re
import subprocess
import sys
from pathlib import Path
from urllib.parse import unquote, urlsplit

ROOT = Path(__file__).resolve().parents[2]
OUTPUT = ROOT / "artifacts/docs-reorganization"
VIEW = sys.argv[1]
if VIEW == "working":
    documents = {p.relative_to(ROOT).as_posix(): p.read_text(encoding="utf-8-sig")
                 for p in [ROOT / "AGENTS.md", ROOT / "README.md", ROOT / "PLAN.md", *(ROOT / "docs").rglob("*.md")]}
    paths = set(subprocess.check_output(["git", "ls-files"], cwd=ROOT).decode().splitlines()) | set(documents)
    source = lambda p: (ROOT / p).read_text(encoding="utf-8-sig")
elif VIEW == "index":
    tracked = subprocess.check_output(["git", "ls-files", "*.md"], cwd=ROOT).decode().splitlines()
    documents = {p: subprocess.check_output(["git", "show", ":" + p], cwd=ROOT).decode() for p in tracked}
    paths = set(subprocess.check_output(["git", "ls-files"], cwd=ROOT).decode().splitlines())
    source = lambda p: subprocess.check_output(["git", "show", ":" + p], cwd=ROOT).decode()
else:
    documents = json.loads((OUTPUT / "staged-docs.json").read_text(encoding="utf-8"))
    snapshot = json.loads((OUTPUT / "snapshot.json").read_text(encoding="utf-8"))
    tracked = subprocess.check_output(["git", "ls-tree", "-r", "--name-only", snapshot["head"]], cwd=ROOT).decode().splitlines()
    paths = (set(tracked) - set(snapshot["baseline"])) | set(documents)
    source = lambda p: subprocess.check_output(["git", "show", snapshot["head"] + ":" + p], cwd=ROOT).decode()

def prose(text):
    return re.sub(r"(?ms)^(```|~~~)[^\n]*\n.*?^\1[^\n]*$", "", text)

def anchors(text):
    seen = {}
    result = set()
    for heading in re.findall(r"(?m)^#{1,6}\s+(.+?)\s*#*\s*$", prose(text)):
        heading = re.sub(r"\[([^]]+)\]\([^)]*\)", r"\1", heading)
        heading = re.sub(r"<[^>]*>", "", heading)
        slug = re.sub(r"[^\w\- ]", "", heading.lower()).replace(" ", "-")
        number = seen.get(slug, 0)
        seen[slug] = number + 1
        result.add(slug if number == 0 else f"{slug}-{number}")
    result.update(re.findall(r'<a\s+(?:id|name)=["\']([^"\']+)', text))
    return result

failures = []
links = 0
python_blocks = 0
ps_blocks = []
anchor_map = {path: anchors(content) for path, content in documents.items()}
for path, content in documents.items():
    for target in re.findall(r"\]\(([^)\s]+)\)", prose(content)):
        parsed = urlsplit(target)
        if parsed.scheme or parsed.netloc:
            continue
        links += 1
        resolved = posixpath.normpath(posixpath.join(posixpath.dirname(path), unquote(parsed.path))) if parsed.path else path
        if resolved not in paths and not any(p.startswith(resolved.rstrip("/") + "/") for p in paths):
            failures.append(f"{path}: missing {target} -> {resolved}")
        elif parsed.fragment and resolved in documents and unquote(parsed.fragment) not in anchor_map[resolved]:
            failures.append(f"{path}: missing anchor {target}")
    for number, (language, block) in enumerate(re.findall(r"(?ms)^```([^\n]*)\n(.*?)^```\s*$", content), 1):
        if language.strip() == "python":
            python_blocks += 1
            try:
                compile(block, path, "exec", ast.PyCF_ALLOW_TOP_LEVEL_AWAIT)
            except SyntaxError as exc:
                failures.append(f"{path}: Python block {number}: {exc}")
        if language.strip() == "powershell":
            ps_blocks.append({"path": path, "block": number, "code": block})

def route_inventory(path):
    tree = ast.parse(source(path))
    prefix = ""
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "APIRouter":
            for keyword in node.keywords:
                if keyword.arg == "prefix":
                    prefix = ast.literal_eval(keyword.value)
    routes = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for decorator in node.decorator_list:
                if isinstance(decorator, ast.Call) and isinstance(decorator.func, ast.Attribute) and decorator.func.attr in {"get", "post"}:
                    routes.add((decorator.func.attr.upper(), prefix + ast.literal_eval(decorator.args[0])))
    return routes

api_files = ["src/ml_pipeline_pro/main.py", "src/ml_pipeline_pro/api.py", "src/ml_pipeline_pro/tuning_api.py"]
if "src/ml_pipeline_pro/conversation_api.py" in paths:
    api_files.append("src/ml_pipeline_pro/conversation_api.py")
actual = set().union(*(route_inventory(p) for p in api_files))
normalize = lambda routes: {(method, re.sub(r"\{[^}]+\}", "{}", path)) for method, path in routes}
documented = set(re.findall(r"`(GET|POST) (/api/v1[^`\s]*)`", documents["docs/reference/api.md"]))
for method, path in sorted(normalize(actual) - normalize(documented)):
    failures.append(f"API reference misses {method} {path}")
for method, path in sorted(normalize(documented) - normalize(actual)):
    failures.append(f"API reference lists unimplemented {method} {path}")

result = {"view": VIEW, "documents": len(documents), "local_links": links,
          "python_blocks": python_blocks, "powershell_blocks": len(ps_blocks),
          "api_operations": len(actual), "failures": failures}
(OUTPUT / f"{VIEW}-powershell.json").write_text(json.dumps(ps_blocks), encoding="utf-8")
(OUTPUT / f"{VIEW}-checks.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
print(json.dumps(result, indent=2))
sys.exit(bool(failures))
