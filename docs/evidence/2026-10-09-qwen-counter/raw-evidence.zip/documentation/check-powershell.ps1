param([string]$View = 'working')
$ErrorActionPreference = 'Stop'
$blocks = Get-Content -Raw "artifacts/docs-reorganization/$View-powershell.json" | ConvertFrom-Json
$failures = @()
foreach ($block in $blocks) {
    $parseTokens = $null
    $parseErrors = $null
    [System.Management.Automation.Language.Parser]::ParseInput($block.code, [ref]$parseTokens, [ref]$parseErrors) | Out-Null
    foreach ($parseError in $parseErrors) {
        $failures += "$($block.path), block $($block.block): $($parseError.Message)"
    }
}
$result = @{ view = $View; blocks = @($blocks).Count; failures = $failures }
$result | ConvertTo-Json -Depth 3 | Set-Content -Encoding UTF8 "artifacts/docs-reorganization/$View-powershell-checks.json"
$result | ConvertTo-Json -Depth 3
if ($failures.Count) { exit 1 }
