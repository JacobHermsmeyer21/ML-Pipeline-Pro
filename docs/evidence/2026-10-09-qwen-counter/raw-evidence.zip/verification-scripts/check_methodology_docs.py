"""Check local Markdown links and fenced examples for the methodology adoption."""

import json
import re
from pathlib import Path
from urllib.parse import unquote, urlsplit

root = Path.cwd()
documents = [root / name for name in ("AGENTS.md", "README.md", "PLAN.md")]
documents.extend(sorted((root / "docs").rglob("*.md")))


def anchors(path):
    result = set()
    seen = {}
    fenced = False
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.startswith("```"):
            fenced = not fenced
            continue
        if fenced:
            continue
        match = re.match(r"^#{1,6}\s+(.+?)\s*#*\s*$", line)
        if match:
            heading = re.sub(r"[^\w -]", "", match.group(1).lower()).replace(" ", "-")
            count = seen.get(heading, 0)
            seen[heading] = count + 1
            result.add(heading + (f"-{count}" if count else ""))
    return result


link_count = 0
for document in documents:
    content = document.read_text(encoding="utf-8")
    assert content.count("```") % 2 == 0, f"Unclosed code block: {document}"
    for target in re.findall(r"\[[^\]]+\]\(([^)]+)\)", content):
        parsed = urlsplit(target)
        if parsed.scheme or parsed.netloc:
            continue
        destination = (document.parent / unquote(parsed.path)).resolve() if parsed.path else document
        assert destination.exists(), f"Broken link in {document.relative_to(root)}: {target}"
        if parsed.fragment:
            assert destination.is_file(), f"Directory anchor in {document.relative_to(root)}: {target}"
            assert unquote(parsed.fragment) in anchors(destination), (
                f"Broken anchor in {document.relative_to(root)}: {target}"
            )
        link_count += 1

summary = {"documents": len(documents), "local_links_and_anchors": link_count}
print(json.dumps(summary))
