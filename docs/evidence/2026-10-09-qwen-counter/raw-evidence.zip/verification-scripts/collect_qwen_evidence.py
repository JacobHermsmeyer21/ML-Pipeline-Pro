"""Retain synthetic-run evidence without packaging model files or credentials."""

import hashlib
import importlib.metadata
import json
import platform
import subprocess
import tarfile
import xml.etree.ElementTree as ET
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path.cwd()
SETUP = ROOT / '.tools/local-model-setup'
VALIDATION = ROOT / 'artifacts/qwen-counter-validation'
OUT = ROOT / 'docs/evidence/2026-10-09-qwen-counter'
OUT.mkdir(parents=True, exist_ok=True)

def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, data):
    path.write_bytes((json.dumps(data, ensure_ascii=False, indent=2) + '\n').encode())

tokenizer = load(SETUP / 'tokenizer.json')
vocab = {**tokenizer['model']['vocab'], **{t['content']: t['id'] for t in tokenizer['added_tokens']}}
merges = [m if isinstance(m, str) else ' '.join(m) for m in tokenizer['model']['merges']]
tokenizer_checks = {}
for name, show_path in [('7b', SETUP/'model-show.json'), ('14b', SETUP/'qwen14b/model-show.json')]:
    info = load(show_path)['model_info']
    tokens = info['tokenizer.ggml.tokens']
    types = info['tokenizer.ggml.token_type']
    assert all(tokens[i] == token for token, i in vocab.items())
    assert info['tokenizer.ggml.merges'] == merges
    assert all(types[i] == 5 and tokens[i] == f'[PAD{i}]' for i in range(len(vocab),len(tokens)))
    assert info['tokenizer.ggml.add_bos_token'] is False
    tokenizer_checks[name] = {'available_entries_match': len(vocab), 'merges_match': len(merges),
                             'unused_padding_entries': len(tokens)-len(vocab), 'add_bos_token': False,
                             'bos_token_id': info['tokenizer.ggml.bos_token_id'],
                             'eos_token_id': info['tokenizer.ggml.eos_token_id'],
                             'installed_show_sha256': digest(show_path)}
write(VALIDATION/'tokenizer-equivalence.json', {'tokenizer_sha256': digest(SETUP/'tokenizer.json'),
                                              'checks': tokenizer_checks})

wheel = ROOT/'dist/ml_pipeline_pro-0.1.0-py3-none-any.whl'
sdist = ROOT/'dist/ml_pipeline_pro-0.1.0.tar.gz'
with zipfile.ZipFile(wheel) as z:
    modules = sorted(p for p in z.namelist() if p.startswith('ml_pipeline_pro/') and p.endswith('.py'))
    assert 'ml_pipeline_pro/conversation_qwen_counter.py' in modules
with tarfile.open(sdist) as t:
    names = t.getnames()
    assert not any(part in {'.git','.venv','.tools','.uv-cache','.env','artifacts'} for name in names for part in Path(name).parts)
write(VALIDATION/'package-check.json', {'wheel_sha256': digest(wheel), 'sdist_sha256': digest(sdist),
                                      'canonical_python_modules': len(modules), 'modules': modules,
                                      'excluded_private_cache_model_paths': True})

attempts = []
raw_files = {}
for n in range(1,7):
    folder = ROOT/f'artifacts/local-model-evaluation/2026-10-09-attempt-{n}'
    report = load(folder/'results.json')
    cases = report.get('cases',[])
    suite = ET.parse(folder/'junit.xml').getroot().find('testsuite')
    attempts.append({'attempt': n, 'model_tag': report.get('model_provenance',{}).get('model_tag'),
                     'status': report['status'], 'passed_scenarios': sum(c['status']=='passed' for c in cases),
                     'failed_scenarios': [c['scenario'] for c in cases if c['status']=='failed'],
                     'executed_scenarios': len(cases), 'generation_calls': len(report.get('calls',[])),
                     'reserved_tokens': report.get('reserved_tokens',0), 'elapsed_junit_seconds': float(suite.get('time')),
                     'native_pytest_exit_code': None if n==1 else 1,
                     'notes': 'Counter identity failed before inference; wrapper exit 0, native pytest exit not captured.' if n==1 else
                              ('Counter module was extended with the lazy API wrapper after this run; report pins instruction and factory hashes, but no pre-extension full counter snapshot was retained.' if n==6 else 'Pre-subsequent-change source hashes are retained alongside the raw run.')})
    for path in sorted(folder.glob('*')):
        if path.is_file(): raw_files[f'live/attempt-{n}/{path.name}'] = path

for path in sorted(VALIDATION.glob('*')):
    if path.is_file(): raw_files[f'validation/{path.name}'] = path
for name in ['collect_qwen_evidence.py','final_qwen_checks.ps1','check_methodology_docs.py']:
    raw_files[f'verification-scripts/{name}'] = ROOT/'.tools'/name
for name in ['check.py','check-powershell.ps1','working-checks.json','working-powershell-checks.json','working-powershell.json']:
    raw_files[f'documentation/{name}'] = ROOT/'artifacts/docs-reorganization'/name

setup_names = ['candidate-verification.json','overflow-verification.json','custom-profile-identity.json',
               'custom-profile-show.json','model-show.json','model-tags.json','runtime-version.json','pull-result.json',
               'diagnostic-read.json','diagnostic-missing_runtime.json','render-mismatch.json',
               'tokenizer_config.json','verify_counter_candidate.py','verify_overflow.py','diagnose_live_reply.py',
               'qwen_counter_candidate.py','generate_render_fixtures.py','pull_qwen.py']
for name in setup_names:
    path=SETUP/name
    if path.is_file(): raw_files[f'setup/{name}']=path
for path in sorted((SETUP/'qwen14b').glob('*')):
    if path.is_file(): raw_files[f'setup/qwen14b/{path.name}']=path

recovery = max((ROOT/'artifacts/recovery-validation').glob('mlpp-recovery-*'),key=lambda p:p.stat().st_mtime)
for path in sorted(recovery.rglob('*')):
    if path.is_file(): raw_files[f'recovery/{recovery.name}/{path.relative_to(recovery).as_posix()}'] = path

source_paths = sorted(p for directory in ['src','tests','evaluations','examples'] for p in (ROOT/directory).rglob('*')
                      if p.is_file() and '__pycache__' not in p.parts and p.suffix in {'.py','.json','.gotmpl'})
source_paths += [ROOT/name for name in ['pyproject.toml','uv.lock','Dockerfile','compose.yaml','tests/integration/compose.recovery.yaml']]
for path in source_paths:
    raw_files[f'verified-source/{path.relative_to(ROOT).as_posix()}']=path

archive = OUT/'raw-evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,path in sorted(raw_files.items()): z.writestr(name,path.read_bytes())

suites = {}
for name, expected in [('unit',420),('integration',56),('recovery',10)]:
    suite = ET.parse(VALIDATION/f'{name}.xml').getroot().find('testsuite')
    data = {key:int(suite.get(key)) for key in ['tests','failures','errors','skipped']}
    assert data == {'tests':expected,'failures':0,'errors':0,'skipped':0},data
    suites[name] = {**data,'elapsed_seconds':float(suite.get('time')),'native_exit_code':0}

report = {
    'recorded_at_utc':datetime.now(timezone.utc).isoformat(),
    'source_baseline':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'branch':subprocess.check_output(['git','branch','--show-current'],text=True).strip(),
    'working_tree':True, 'platform':platform.platform(),'python':platform.python_version(),
    'source_files_sha256':{p.relative_to(ROOT).as_posix():digest(p) for p in source_paths},
    'package_versions':{d.metadata['Name']:d.version for d in importlib.metadata.distributions()},
    'verification':suites, 'final_check_exits':load(VALIDATION/'final-check-exits.json'),
    'coverage_percent':load(VALIDATION/'coverage.json')['totals']['percent_covered'],
    'packages':load(VALIDATION/'package-check.json'), 'tokenizer_equivalence':load(VALIDATION/'tokenizer-equivalence.json'),
    'live_attempts':attempts,
    'archive':{'path':'raw-evidence.zip','sha256':digest(archive),'bytes':archive.stat().st_size,
               'entries_sha256':{name:digest(path) for name,path in sorted(raw_files.items())}},
    'limits':['All live acceptance attempts failed; C3/C5 and A1/F6 remain outstanding.',
              'Independent review and a complete clean-checkout conversation tutorial were unavailable.',
              'Synthetic fixture metrics are not training measurements; timings are observations, not capacity claims.',
              'The stock 7B token overflow probe is admission evidence, not successful model-quality acceptance.',
              'The final source snapshot applies to the passing host gates; failed live attempts use their own retained provenance.',
              'No remote CI run is claimed. No models, tokenizer data or secrets are archived.'],
    'review':{'reviewer':'implementing assistant','scope':'Pinned runtime rendering, token admission, lifecycle, live failures and verification provenance',
              'independent':False,'independent_review_status':'unavailable; outstanding'},
}
write(OUT/'results.json',report)
print(json.dumps({'suites':suites,'live_attempts':[(a['attempt'],a['passed_scenarios'],a['executed_scenarios']) for a in attempts],
                  'archive_bytes':archive.stat().st_size,'raw_files':len(raw_files)}))
