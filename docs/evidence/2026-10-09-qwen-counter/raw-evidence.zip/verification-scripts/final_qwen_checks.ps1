$ErrorActionPreference = 'Stop'
$uvPath = Join-Path (Get-Location) '.tools/uv/bin/uv.exe'
$outRoot = Join-Path (Get-Location) 'artifacts/qwen-counter-validation'
$checks = @(
    @{ Name = 'sync'; Args = @('sync', '--locked', '--extra', 'training', '--offline') },
    @{ Name = 'lint'; Args = @('run', '--locked', '--extra', 'training', 'ruff', 'check', '.') },
    @{ Name = 'format'; Args = @('run', '--locked', '--extra', 'training', 'ruff', 'format', '--check', '.') },
    @{ Name = 'pip-check'; Args = @('pip', 'check') },
    @{ Name = 'build'; Args = @('build', '--offline') }
)
$outcomes = @{}
foreach ($check in $checks) {
    $arguments = $check.Args
    $ErrorActionPreference = 'Continue'
    & $uvPath --cache-dir .uv-cache @arguments *> (Join-Path $outRoot ($check.Name + '.txt'))
    $checkExit = $LASTEXITCODE
    $ErrorActionPreference = 'Stop'
    $outcomes[$check.Name] = $checkExit
    if ($checkExit -ne 0) { throw ('Failed check: ' + $check.Name) }
}
$outcomes | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $outRoot 'final-check-exits.json') -Encoding UTF8
$outcomes | ConvertTo-Json
