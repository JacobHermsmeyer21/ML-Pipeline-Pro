"""Record a user-requested fresh original gate; no automatic retries or output repair."""
import argparse
import hashlib
import json
import os
import re
import runpy
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path

import httpx

ROOT=Path.cwd()
OUT=ROOT/'artifacts/laptop-five-minute-awake-gates'
RUNTIME=ROOT/'.tools/test-prerequisites'
MODEL='mlpp-qwen2.5:7b-instruct-q4_K_M-json-tools-v1'
POWER=runpy.run_path(str(ROOT/'artifacts/laptop-five-minute-validation/run_command.py'))['power']
LOG_NAMES=['ollama-stderr.log','ollama-stdout.log']


def state(lines):
    states=[line for line in lines if re.search('all slots are idle|new prompt|cancel task|stop processing',line)]
    return states[-1] if states else None


def write(name,data):
    (OUT/name).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('phase',choices=['warmup','conversation','snippets'])
    args=parser.parse_args()
    phase=args.phase
    OUT.mkdir(parents=True,exist_ok=True)
    assert not (OUT/(phase+'-execution.json')).exists(),'Do not overwrite a prior run'
    assert POWER()['ac_line_status']==1,'AC power is required'
    previous=state((RUNTIME/LOG_NAMES[0]).read_text(encoding='utf-8',errors='replace').splitlines())
    assert previous and 'all slots are idle' in previous,'Actual runner-idle evidence required'
    with httpx.Client(base_url='http://127.0.0.1:11434',timeout=8,trust_env=False,follow_redirects=False) as client:
        version=client.get('/api/version');version.raise_for_status()
        tags=client.get('/api/tags');tags.raise_for_status()
        model=next(item for item in tags.json()['models'] if item['name']==MODEL)
        assert version.json()['version']=='0.40.2'
        assert model['digest'].removeprefix('sha256:')=='abadc4bf8517d77dcc8db312ca98cd7cb43488243048c41f1b5746e031427779'
    source_paths=[*Path('src/ml_pipeline_pro').glob('*.py'),*Path('evaluations').glob('*.py'),Path('uv.lock'),Path('examples/warm_local_model.py'),Path(__file__)]
    pre={'started_utc':datetime.now(UTC).isoformat(),'phase':phase,'source_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'working_tree':subprocess.check_output(['git','status','--porcelain'],text=True),'source_sha256':{p.relative_to(ROOT).as_posix() if p.is_absolute() else p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in source_paths},'power_before':POWER(),'runtime_version':version.json(),'model':{'name':model['name'],'digest':model['digest']},'runner_state_before':previous,'user_requested_fresh_full_gate':True,'prior_interrupted_run':'docs/evidence/2026-10-19-laptop-five-minute/README.md','automatic_retries':0,'generated_code_execution':False}
    offsets={name:(RUNTIME/name).stat().st_size for name in LOG_NAMES}
    write(phase+'-preflight.json',pre)
    if phase=='warmup':
        command=[sys.executable,'examples/warm_local_model.py','--model',MODEL]
        safety=150
    else:
        file='evaluations/test_conversation_model.py' if phase=='conversation' else 'evaluations/test_snippet_model.py'
        command=[str(ROOT/'.tools/bin/uv/uv.exe'),'run','--offline','--locked','--extra','training','pytest',file,'--timing-profile','laptop-five-minute','--local-model',MODEL,'--eval-output',str(OUT/(phase+'.json')),'--junitxml='+str(OUT/(phase+'.xml')),'--basetemp',str(OUT/(phase+'-temp')),'-o','cache_dir='+str(OUT/'pytest-cache')]
        if phase=='conversation':command.extend(['--token-counter','evaluations.qwen_counter:create_counter'])
        safety=3450 if phase=='conversation' else 2550
    env=os.environ.copy()
    env.update(MLPP_RUN_LOCAL_MODEL_EVAL='1',MLPP_CHAT_PROTOCOL='guided',UV_CACHE_DIR=str(ROOT/'.uv-cache'))
    result=None
    try:
        result=subprocess.run([sys.executable,'artifacts/laptop-five-minute-validation/run_command.py','--phase',phase,'--timeout',str(safety),'--output',str(OUT),'--',*command],env=env,creationflags=subprocess.CREATE_NO_WINDOW)
    finally:
        for name,offset in offsets.items():
            with (RUNTIME/name).open('rb') as source:
                source.seek(offset);raw=source.read()
            lines=raw.decode('utf-8',errors='replace').splitlines()
            selected=[line for line in lines if re.search(r'all slots are idle|prompt eval time|eval time|total time|cached n_tokens|cancel task|stop processing|new prompt|/api/chat',line,re.I)]
            (OUT/(phase+'-'+name.replace('.log','-filtered.log'))).write_text('\n'.join(selected)+'\n',encoding='utf-8')
            pre.setdefault('runtime_slices',{})[name]={'source_offset_bytes':offset,'slice_size_bytes':len(raw),'slice_sha256':hashlib.sha256(raw).hexdigest(),'selection':'Payload-free timing/state and /api/chat rows in exact recorded byte slice.'}
            if name==LOG_NAMES[0]:
                final=state(lines)
                pre['runner_final_state']=final
                pre['runner_idle_after']=bool(final and 'all slots are idle' in final)
        pre.update(ended_utc=datetime.now(UTC).isoformat(),power_after=POWER())
        write(phase+'-observation.json',pre)
    raise SystemExit(result.returncode if result is not None else 1)


if __name__=='__main__':main()
