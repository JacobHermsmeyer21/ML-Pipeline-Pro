"""Check retained results, original gate source, saved outputs and archive without execution."""
import ast
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

root=Path.cwd()
base=root/'artifacts/laptop-five-minute-awake-gates'
target=root/'docs/evidence/2026-10-19-laptop-awake-gates'
result=json.loads((target/'results.json').read_text())
archive=target/'raw.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==result['archive_sha256']
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    manifest=json.loads(bundle.read('manifest.json'))
    assert set(bundle.namelist())==set(manifest)|{'manifest.json'}
    for name,item in manifest.items():
        data=bundle.read(name)
        assert len(data)==item['size_bytes'] and hashlib.sha256(data).hexdigest()==item['sha256'],name
        assert 'kubeconfig' not in name.lower() and not name.endswith('.env'),name
        assert not re.search(rb'(?:gh[pousr]_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{20,}|-----BEGIN [A-Z ]*PRIVATE KEY-----)',data),name
        if name.startswith('source/'):
            assert data==(root/name.removeprefix('source/')).read_bytes(),name
    for name,expected,variable in [('conversation',10,'PROMPTS'),('snippets',7,'CASES')]:
        raw=json.loads(bundle.read('runs/'+name+'.json'))
        execution=json.loads(bundle.read('runs/'+name+'-execution.json'))
        source=root/('evaluations/test_conversation_model.py' if name=='conversation' else 'evaluations/test_snippet_model.py')
        tree=ast.parse(source.read_text())
        scenarios=next(ast.literal_eval(node.value) for node in tree.body if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id==variable for t in node.targets))
        assert list(scenarios)==[case['scenario'] for case in raw['cases']]
        summary=result['gates'][name]
        assert summary['status']=='passed' and summary['passed_cases']==expected and not summary['unrun_scenarios']
        assert all(case.get('status')=='passed' or case.get('passed') is True for case in raw['cases'])
        assert all(case['elapsed_seconds']<=300 for case in raw['cases'])
        assert summary['max_complete_reply_seconds']==max(case['elapsed_seconds'] for case in raw['cases'])
        assert summary['recorded_sleep_intersecting_execution']==[] and summary['runner_idle_after'] is True
        assert execution['exit_code']==0 and execution['working_tree']==''
        assert execution['power_before']['ac_line_status']==execution['power_after']['ac_line_status']==1
        suites=ET.fromstring(bundle.read('runs/'+name+'.xml'))
        for suite in suites.iter('testsuite'):
            assert int(suite.get('tests'))==1
            assert all(int(suite.get(key,'0'))==0 for key in ['errors','failures','skipped'])
        observation=json.loads(bundle.read('runs/'+name+'-observation.json'))
        for path,value in observation['source_sha256'].items():
            assert hashlib.sha256((root/path).read_bytes()).hexdigest()==value,path
        states=bundle.read('runs/'+name+'-ollama-stderr-filtered.log').decode().splitlines()
        assert 'all slots are idle' in states[-1]
human=(target/'human-review.md').read_text()
drafts=re.findall(r'```python\n(.*?)\n```',human,re.S)
snippets=json.loads((base/'snippets.json').read_text())
raw_codes=[case['turn']['snippet']['code'] for case in snippets['cases'] if case['turn'].get('snippet')]
assert drafts==raw_codes and len(drafts)==5
for code in drafts:
    ast.parse(code)
    assert hashlib.sha256(code.encode()).hexdigest() in human
assert 'pending human review' in human
assert result['new_deployment_demo_execution'] is False
for name in ['raw.zip','results.json','verification.json']:
    path=Path('docs/evidence/2026-10-19-laptop-five-minute')/name
    assert subprocess.check_output(['git','show','HEAD:'+path.as_posix()])==(root/path).read_bytes()
for path in target.glob('*.json'):json.loads(path.read_text())
report={'archive_crc_manifest_sizes_hashes':'pass','source_equality':'pass','original_scenario_order_counts_asserted':'10/10 and7/7','raw_call_counts':{'conversation':18,'snippets':12,'code_generation':5},'execution_exit_power_junit_idle_evidence':'pass','recorded_sleep_intersecting_gates':[],'human_review_code_strings_hashes_syntax':'five exact saved drafts; syntax parsed, never executed','secret_pattern_scan':'pass','previous_raw_evidence_unchanged':'pass','new_human_review':'pending','deployed_demo':'still failed; not rerun'}
assert len(json.loads((base/'conversation.json').read_text())['calls'])==18
assert len(snippets['calls'])==12 and snippets['generation_calls']==5
(base/'evidence-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
