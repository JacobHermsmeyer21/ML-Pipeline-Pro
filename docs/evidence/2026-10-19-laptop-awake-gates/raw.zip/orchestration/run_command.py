"""Record one existing command's exit, elapsed time and power state; never retry."""
import argparse
import ctypes
import hashlib
import json
import subprocess
import time
from datetime import UTC, datetime
from pathlib import Path


def power():
    class Status(ctypes.Structure):
        _fields_ = [("ac", ctypes.c_ubyte), ("flag", ctypes.c_ubyte),
                    ("percent", ctypes.c_ubyte), ("reserved", ctypes.c_ubyte),
                    ("life", ctypes.c_ulong), ("full", ctypes.c_ulong)]
    state = Status()
    ok = bool(ctypes.windll.kernel32.GetSystemPowerStatus(ctypes.byref(state)))
    return {"read_ok": ok, "ac_line_status": state.ac, "battery_percent": state.percent}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--phase', required=True)
    parser.add_argument('--timeout', type=int, required=True)
    parser.add_argument('--output', type=Path, default=Path('artifacts/laptop-five-minute-validation'))
    parser.add_argument('command', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    command = args.command[1:] if args.command[0] == '--' else args.command
    args.output.mkdir(parents=True, exist_ok=True)
    report = {'argv': command, 'started_utc': datetime.now(UTC).isoformat(),
              'power_before': power(), 'outer_safety_timeout_seconds': args.timeout,
              'source_revision': subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
              'working_tree': subprocess.check_output(['git','status','--porcelain'],text=True),
              'orchestrator_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'retries': 0, 'generated_code_execution': False}
    started = time.monotonic()
    try:
        with (args.output / (args.phase + '.log')).open('wb') as log:
            result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT,
                                    timeout=args.timeout, creationflags=subprocess.CREATE_NO_WINDOW)
        report['exit_code'] = result.returncode
    except subprocess.TimeoutExpired:
        report['exit_code'] = 124
        report['outer_timeout'] = True
    finally:
        report.update(elapsed_seconds=time.monotonic()-started, power_after=power(),
                      ended_utc=datetime.now(UTC).isoformat())
        (args.output / (args.phase + '-execution.json')).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:report[k] for k in ['exit_code','elapsed_seconds','power_before','power_after']}))
    raise SystemExit(report['exit_code'])


if __name__ == '__main__':
    main()
