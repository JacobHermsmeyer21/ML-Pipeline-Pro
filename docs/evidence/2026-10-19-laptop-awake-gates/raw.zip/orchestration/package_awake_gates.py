"""Retain the original awake model-gate runs and exact source/provenance without secrets."""
import ast
import hashlib
import json
import re
import subprocess
import unicodedata
import zipfile
from datetime import datetime
from pathlib import Path

ROOT=Path.cwd()
BASE=ROOT/'artifacts/laptop-five-minute-awake-gates'
TARGET=ROOT/'docs/evidence/2026-10-19-laptop-awake-gates'


def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))


def scenarios(path,variable):
    module=ast.parse(path.read_text())
    return next(ast.literal_eval(node.value) for node in module.body if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id==variable for t in node.targets))


def gate(name):
    data=read(BASE/(name+'.json'))
    execution=read(BASE/(name+'-execution.json'))
    observation=read(BASE/(name+'-observation.json'))
    ordered=scenarios(ROOT/('evaluations/test_conversation_model.py' if name=='conversation' else 'evaluations/test_snippet_model.py'),'PROMPTS' if name=='conversation' else 'CASES')
    cases=[]
    for item in data['cases']:
        turn=item.get('turn',{})
        cases.append({'scenario':item['scenario'],'passed':item.get('status')=='passed' or item.get('passed') is True,'elapsed_seconds':item['elapsed_seconds'],'failure_type':item.get('error_type',item.get('failure_type')),'turn_status':turn.get('status'),'snippet_status':turn.get('snippet',{}).get('status') if turn.get('snippet') else None})
    actual={item['scenario'] for item in cases}
    passed=len(cases)==len(ordered) and actual==set(ordered) and all(item['passed'] and item['elapsed_seconds']<=300 for item in cases) and execution['exit_code']==0
    intervals=[]
    for event in read(BASE/'power-events.json'):
        message=''.join(c for c in event['message'] if unicodedata.category(c)!='Cf')
        sleep=re.search(r'Sleep Time:\s*([0-9TZ:.\-]+)',message)
        wake=re.search(r'Wake Time:\s*([0-9TZ:.\-]+)',message)
        if sleep and wake:
            start=datetime.fromisoformat(sleep[1])
            end=datetime.fromisoformat(wake[1])
            if start<datetime.fromisoformat(execution['ended_utc']) and end>datetime.fromisoformat(execution['started_utc']):
                intervals.append({'sleep_utc':sleep[1],'wake_utc':wake[1]})
    return {'status':'passed' if passed else 'failed','expected_cases':len(ordered),'passed_cases':sum(item['passed'] for item in cases),'unrun_scenarios':[name for name in ordered if name not in actual],'cases':cases,'max_complete_reply_seconds':max((item['elapsed_seconds'] for item in cases),default=None),'budget':data['budget'],'pytest_test_count_note':'One pytest test contains every required semantic scenario; scenario counts come from raw report.','execution':execution,'runner_state_before':observation['runner_state_before'],'runner_idle_after':observation['runner_idle_after'],'recorded_sleep_intersecting_execution':intervals,'power_evidence_limits':'Power status measured before/after, not continuously; Power-Troubleshooter intervals checked against recorded phase windows.','model_provenance':data['model_provenance'],'source_revision':data['source_revision'],'automatic_retries':0,'human_quality_review_required':True,'generated_code_execution':False}


def main():
    TARGET.mkdir(parents=True,exist_ok=True)
    result={'date':'2026-10-19','scope':'User requested remaining model checks after reconnecting AC and keeping laptop awake. Fresh entire dialogue gate, then independent snippet gate; original interrupted evidence retained unchanged.','source_revision':read(BASE/'conversation-preflight.json')['source_revision'],'application_implementation_revision':'533a2ed0ef7cc70205c06ad218fabe2f9365dfb0','timing_profile':'laptop-five-minute','fixture_values_are_synthetic':True,'new_deployment_demo_execution':False,'existing_deployed_demo_status':'failed: gateway liveness-triggered delivery break; no health changes made or approved.','prior_evidence':'../2026-10-19-laptop-five-minute/README.md','gates':{name:gate(name) for name in ['conversation','snippets']},'new_generated_outputs_require_human_review':True,'no_generated_python_executed':True,'application_harness_changes':'None; application, evaluation harness, prompts, budgets, model/runtime and lockfile match preceding run. No automatic retries or output repair.'}
    previous=read(ROOT/'artifacts/laptop-five-minute-validation/implementation-verification.json')['source_sha256']
    observed=read(BASE/'conversation-preflight.json')['source_sha256']
    common={key:value for key,value in observed.items() if key in previous}
    assert all(value==previous[key] for key,value in common.items())
    result['matching_source_hashes_vs_previous_run']=len(common)
    result['separate_evidence_review']=read(BASE/'evidence-review.json')
    payload={}
    def add(path,name):payload[name]=path.read_bytes()
    for path in BASE.iterdir():
        if path.is_file() and path.suffix in {'.log','.json','.xml'}:add(path,'runs/'+path.name)
    for path in [ROOT/'artifacts/laptop-five-minute-validation/run_awake_gate.py',ROOT/'artifacts/laptop-five-minute-validation/run_command.py',ROOT/'artifacts/laptop-five-minute-validation/render_awake_review.py',ROOT/'artifacts/laptop-five-minute-validation/validate_awake_evidence.py',Path(__file__)]:add(path,'orchestration/'+path.name)
    for directory in ['src/ml_pipeline_pro','evaluations']:
        for path in (ROOT/directory).glob('*.py'):add(path,'source/'+path.relative_to(ROOT).as_posix())
    for path in [ROOT/'uv.lock',ROOT/'examples/warm_local_model.py']:add(path,'source/'+path.relative_to(ROOT).as_posix())
    manifest={name:{'sha256':hashlib.sha256(data).hexdigest(),'size_bytes':len(data)} for name,data in sorted(payload.items())}
    payload['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
    archive=TARGET/'raw.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as bundle:
        for name,data in sorted(payload.items()):bundle.writestr(name,data)
    with zipfile.ZipFile(archive) as bundle:
        assert bundle.testzip() is None
        assert set(bundle.namelist())==set(manifest)|{'manifest.json'}
        for name,item in manifest.items():
            data=bundle.read(name)
            assert hashlib.sha256(data).hexdigest()==item['sha256'] and len(data)==item['size_bytes']
    result['archive_sha256']=hashlib.sha256(archive.read_bytes()).hexdigest()
    (TARGET/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    (TARGET/'verification.json').write_text(json.dumps({'payload_files':len(manifest),'archive_crc_manifest_hashes_sizes':'pass','credentials_environment_dump_kubeconfig_weights':'excluded','source_hashes_match_previous_run':len(common)},indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'source_revision':result['source_revision'],'gates':{name:{key:gate[key] for key in ['status','passed_cases','expected_cases','unrun_scenarios','max_complete_reply_seconds','runner_idle_after']} for name,gate in result['gates'].items()},'payload_files':len(manifest),'archive_sha256':result['archive_sha256']},indent=2))


if __name__=='__main__':main()
