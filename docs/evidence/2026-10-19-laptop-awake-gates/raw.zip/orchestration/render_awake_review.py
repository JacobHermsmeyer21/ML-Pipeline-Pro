"""Render exact saved outputs for pending human review; never execute generated code."""
import hashlib
import json
from pathlib import Path

base=Path('artifacts/laptop-five-minute-awake-gates')
target=Path('docs/evidence/2026-10-19-laptop-awake-gates/human-review.md')
conversation=json.loads((base/'conversation.json').read_text())
snippets=json.loads((base/'snippets.json').read_text())
lines=['# New laptop outputs awaiting human review','','Status: **pending human review**. Automated original ten/seven gates pass; this','document does not record human approval. Values below use synthetic fixture records,','not measured model quality. Generated Python is saved exactly and has never been','executed. See [run evidence](README.md) and [raw outputs](raw.zip).','','## Conversation examples','']
for case in conversation['cases']:
    turn=case['turn']
    lines.extend(['### '+case['scenario'],'','Saved status: `'+turn['status']+'`.','','```text',turn['message'],'```',''])
    if turn.get('facts'):
        lines.extend(['Verified fixture facts:','','```json',json.dumps(turn['facts'],indent=2),'```',''])
    if turn.get('pending_action'):
        lines.extend(['Model-proposed tool/arguments; no submission occurred:','','```json',json.dumps(turn['pending_action']['tool'],indent=2),'```',''])
lines.extend(['## Generated drafts','','Review API calls, supplied arguments, error handling and clarity before any use.','The missing-input and unsupported-profile cases correctly save no draft.',''])
for case in snippets['cases']:
    snippet=case['turn'].get('snippet')
    if not snippet:continue
    code=snippet['code']
    assert '```' not in code,'Choose a safe enclosing Markdown fence before rendering'
    lines.extend(['### '+case['scenario'],'','Saved status: `'+snippet['status']+'`; review required. Code SHA-256:','`'+hashlib.sha256(code.encode()).hexdigest()+'`.','','```python',code,'```',''])
lines.extend(['## Human decision','','- [ ] The fixture replies are clear and reflect the supplied facts/status.','- [ ] The proposed tuning arguments and explicit-confirmation boundary are clear.','- [ ] The generated drafts are understandable and appropriate for their stated profiles.','- [ ] Missing-input, hostile-record and unsupported-operation behavior is acceptable.','','Reviewer/date/decision: pending.',''])
target.write_text('\n'.join(lines),encoding='utf-8')
print('Rendered exact saved outputs for pending human review; no generated code executed.')
